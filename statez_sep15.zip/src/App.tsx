import SampleForm from "./sample/SampleForm";
import SampleForm2 from "./sample/SampleForm2";
import SampleForm3 from "./sample/SampleForm3";
import SampleLifecycleHooks from "./sample/SampleLifecycleHooks";
import { SampleQuery } from "./sample/SampleQuery";

const App = () => {
  // return <SampleLifecycleHooks />;
  return <SampleQuery />;
};

export default App;
