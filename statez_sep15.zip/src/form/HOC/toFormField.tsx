import { useStore } from "../../store";

export const toFormField = (Component: any, store: any, name: string) => {
  console.log('to form field render', name)
  return (props) => {
    const _formData = useStore(store, [name]);
    console.log("change render", name);

    const handleChange = (e) => {
      if (_formData?.[name]) {
        _formData[name] = e.target.value;
      }
    };
    return (
      <Component
        {...props}
        name={name}
        value={_formData?.[name]}
        onChange={handleChange}
      />
    );
  };
};
