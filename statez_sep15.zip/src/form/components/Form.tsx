import { cloneElement, createContext, useContext, useEffect } from "react";
import { useStore } from "../../store";

export const FormStoreContext = createContext<any>(undefined);

const useFormStoreContext = (Formors?: string[]) => {
  const store = useContext(FormStoreContext);

  return useStore(store, Formors);
};

const FormRoot = (props: any) => {
  const _formStore = props.zStore;

  return (
    <FormStoreContext.Provider value={_formStore}>
      {props.children}
    </FormStoreContext.Provider>
  );
};

const FormControl = (props: any) => {
  const _formStore = useFormStoreContext(props.name ? [props.name] : undefined);

  console.log("reder", props);
  
  const newChildren = cloneElement(props.children, {
    value: _formStore[props.name]
  });

  return newChildren;
};

export const Form = {
  Root: FormRoot,
  Control: FormControl,
};
