import { cloneElement, createContext, useContext } from "react";
import { useStore } from "../../store";
import { useCreateStore } from "../../store/hooks/useCreateStore";
import { useMountEffect } from "../../hooks";

export const FormStoreContext = createContext(null);

const useFormStoreContext = (Formors?: string[]) => {
  const store = useContext(FormStoreContext);

  return useStore(store, Formors);
};

const FormRoot = (props: any) => {
  const _formStore = useCreateStore(props.initialValue);

  useMountEffect(() => {
    if (props.zRef) {
      props.zRef.current = _formStore;
    }
  });

  return (
    <FormStoreContext.Provider value={_formStore}>
      {props.children}
    </FormStoreContext.Provider>
  );
};

const FormControl = (props: any) => {
  const _formStore = useFormStoreContext(props.name ? [props.name] : undefined);

  console.log("reder", props.name);

  const newChildren = cloneElement(props.children, {
    value: _formStore[props.name],
    onChange: (e) => (_formStore[props.name] = e.target.value),
  });

  return newChildren;
};

export const Form = {
  Root: FormRoot,
  Control: FormControl,
};
