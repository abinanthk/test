import { useCreateStore } from "../../store/hooks/useCreateStore";

export const useForm = <TState extends {}>(initialState: TState) => {
  return useCreateStore<TState>(initialState);
};
