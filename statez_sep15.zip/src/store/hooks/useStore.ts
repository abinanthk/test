import { useMountEffect, useForceUpdate } from "../../hooks";

export const useStore = <TState>(store: any, subscribeTo?: string[]) => {
  const forceUpdate = useForceUpdate();

  useMountEffect(() => {
    subscribeTo?.forEach((sub) => {
      store.__proto__.subjects?.[sub]?.subscribe(() => {
        forceUpdate();
      });
    });
  });

  return store as TState;
};
