import { useRef } from "react";
import { createStore, useStore } from "..";

export const useCreateStore = <TState extends {}>(
  initialState: TState,
  subscribeTo?: string[]
) => {
  const storeRef = useRef<any>(null);

  if (!storeRef.current) {
    storeRef.current = createStore<TState>(initialState);
  }

  return useStore<TState>(storeRef.current, subscribeTo);
};
