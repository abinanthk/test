import { useMountEffect } from "../../hooks";

export const useStoreEffect = (
    callback: (state: any, label: string) => void,
    stores: any[],
    labels: string[]
  ) => {
    useMountEffect(() => {
      stores?.forEach((store, index) => {
        store.__proto__.subjects.$?.subscribe((state: any) => {
          callback?.(state, labels?.[index]);
        });
      });
    });
  };