import { toFormField, useForm } from "../form";

type TLoginForm = {
  username: string;
  password: string;
};

const SampleForm = () => {
  const formZ = useForm<TLoginForm>({
    username: "admin",
    password: "admin123",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("submitted values: ", e);
    console.log("submitted username: ", e.target["username"].value);
    console.log("submitted password: ", e.target["password"].value);
  };

  const UsernameInput = toFormField(
    (props) => <input {...props} style={{ height: 25 }} />,
    formZ,
    "username"
  );
  const PasswordInput = toFormField(
    (props) => <input {...props} style={{ height: 25 }} />,
    formZ,
    "password"
  );

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        display: "flex",
        flexDirection: "column",
        width: 300,
        gap: 20,
        margin: "auto",
        paddingTop: 50,
      }}
    >
      <UsernameInput />
      <PasswordInput />
      <button style={{ padding: 10 }}>Login</button>
    </form>
  );
};

export default SampleForm;
