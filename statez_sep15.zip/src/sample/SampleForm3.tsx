import { useRef } from "react";
import { Form, useForm } from "../form";

type TLoginForm = {
  username: string;
  password: string;
};
const SampleForm3 = () => {
  const zFormStore = useForm<TLoginForm>({
    username: "admin",
    password: "admin123",
  });

  const handleSubmit = () => {
    console.log("submitted ", zFormStore);
  };

  return (
    <Form.Root zStore={zFormStore}>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          width: 300,
          gap: 20,
          margin: "auto",
          paddingTop: 50,
        }}
      >
        <Form.Control name={"username"}>
          <input
            name={"username"}
            style={{ height: 25 }}
            value={zFormStore.username}
            onChange={(e) => (zFormStore.username = e.target.value)}
          />
        </Form.Control>

        <Form.Control name={"password"}>
          <input
            name={"password"}
            style={{ height: 25 }}
            value={zFormStore.password}
            onChange={(e) => (zFormStore.password = e.target.value)}
          />
        </Form.Control>

        <button onClick={handleSubmit} style={{ padding: 10 }}>
          Login
        </button>
      </div>
    </Form.Root>
  );
};

export default SampleForm3;
