import { Select, useSelectRef } from "../ui/Select";

const SampleSelect = () => {
  const zRef = useSelectRef();

  const handleClick = () => {
    zRef.current?.addValue("hello");
    console.log("submitted vaues : ", zRef.current);
  };

  console.log("rendered");

  return (
    <div className="m-5">
      <Select.Root
        zRef={zRef}
        defaultValue={["male"]}
        name="gender"
        onChange={(values: string[]) => {
          console.log("select value", values);
        }}
      >
        <Select.Trigger>
          <Select.Label>select</Select.Label>
          <br />
          <Select.Placeholder>value</Select.Placeholder>
        </Select.Trigger>

        <Select.Content>
          <Select.Option value="male">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>male</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>male</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="male">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>male</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>male</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="female">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>female</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>female</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="others">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>others</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>others</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>
        </Select.Content>
      </Select.Root>
      <button onClick={handleClick}>submit</button>
    </div>
  );
};

export default SampleSelect;
