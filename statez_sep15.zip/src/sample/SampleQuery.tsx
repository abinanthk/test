import { useState } from "react";
import { useQuery } from "../query";

const getPostData = () => {
  console.log("fetching data");
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          name: "Title 1",
          description: "This is post 1",
        },
        {
          name: "Title 2",
          description: "This is post 2",
        },
      ]);
    }, 3000);
  });
};

const usePostsQuery = () => {
  return useQuery({
    queryKey: "postsData",
    queryFn: getPostData,
  });
};

const Posts = ({ title }) => {
  const [count, setCount] = useState(0);
  const { status, isFetching, error, data } = usePostsQuery();

  console.log('postes  render---------------------')


  console.log("status : ", status);
  console.log("isFetching : ", isFetching);
  console.log("error : ", error);
  console.log("data : ", data);

  if (status === "pending") return "Loading...";

  if (error) return "An error has occurred: " + error;

  return (
    <div style={{ padding: 20 }}>
      <button onClick={() => setCount((prev) => prev + 1)}>
        count: {count}
      </button>
      <h1>{title}</h1>
      {isFetching && <p>Refetching...</p>}
      {data?.map((item) => (
        <div key={item.name}>
          <h3>{item.name}</h3>
          <p>{item.description}</p>
        </div>
      ))}
    </div>
  );
};

export const SampleQuery = () => {
  const [showPosts1, setShowPosts1] = useState(true);
  const [showPosts2, setShowPosts2] = useState(true);

  console.log('sampleQuery render------------------------')

  return (
    <>
      <button onClick={() => setShowPosts1(!showPosts1)}>Toggle Posts 1</button>
      <button onClick={() => setShowPosts2(!showPosts2)}>Toggle Posts 2</button>
      <div style={{ display: "flex" }}>
        {showPosts1 && <Posts title="Posts 1" />}
        {showPosts2 && <Posts title="Posts 2" />}
      </div>
    </>
  );
};
