import { useRef } from "react";
import { Form } from "../form";

const SampleForm2 = () => {
  const zFormRef = useRef();

  const handleSubmit = () => {
    console.log("submitted ", zFormRef);
  };

  return (
    <Form.Root
      zRef={zFormRef}
      initialValue={{
        username: "admin",
        password: "admin123",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          width: 300,
          gap: 20,
          margin: "auto",
          paddingTop: 50,
        }}
      >
        <Form.Control name={"username"}>
          <input style={{ height: 25 }} />
        </Form.Control>

        <Form.Control name={"password"}>
          <input style={{ height: 25 }} />
        </Form.Control>

        <button onClick={handleSubmit} style={{ padding: 10 }}>
          Login
        </button>
      </div>
    </Form.Root>
  );
};

export default SampleForm2;
