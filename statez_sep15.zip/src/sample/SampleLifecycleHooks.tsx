import { useState } from "react";
import { useMountEffect, useUnMountEffect, useUpdateEffect } from "../hooks";

const Child = () => {
  const [count, setCount] = useState(0);

  useMountEffect(() => {
    console.log("mounted");
  });

  useMountEffect(() => {
    console.log("mounted 2");
  });

  useUpdateEffect(() => {
    console.log("updated");
  }, [count]);

  useUpdateEffect(() => {
    console.log("updated 2");
  }, [count]);

  useUnMountEffect(() => {
    console.log("un mounted");
  });

  useUnMountEffect(() => {
    console.log("un mounted 2");
  });

  console.log("re rendered");

  const handleClick = () => [setCount((prev) => prev + 1)];

  return (
    <div>
      <span>{count}</span>
      <button onClick={handleClick}>click</button>
    </div>
  );
};

const SampleLifecycleHooks = () => {
  const [show, setShow] = useState(true);
  return (
    <div>
      <button onClick={() => setShow((prev) => !prev)}>change</button>
      {show && <Child />}
    </div>
  );
};

export default SampleLifecycleHooks;
