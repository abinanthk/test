import { createStore } from "../../store";

type TQueryStoreConfig = {
  queryKey: string;
  queryFn: Function;
};

export type TQueryStore = {
  queryKey: string;
  status: "idle" | "pending" | "resolved" | "rejected";
  isFetching: boolean;
  data: any;
  error: any;
  fetch: () => void;
};

export const createQueryStore = (config: TQueryStoreConfig) => {
  return createStore<TQueryStore>({
    queryKey: config.queryKey,
    status: "idle",
    isFetching: false,
    data: undefined,
    error: undefined,
    async fetch() {
      if (this.isFetching) {
        return;
      }
      this.isFetching = true;
      this.status = "pending";

      try {
        const response = await config.queryFn();
        console.log("fetching in async");
        this.data = response;
        this.status = "resolved";
      } catch (err) {
        this.error = err;
        this.data = undefined;
        this.status = "rejected";
      } finally {
        this.isFetching = false;
      }
    },
  });
};
