import { useMountEffect } from "../../hooks";
import { useQueryCache } from "./useQueryCache";

type TQueryStoreConfig = {
  queryKey: string;
  queryFn: Function;
};

export const useQuery = (config: TQueryStoreConfig) => {
  const _queryStore = useQueryCache(
    {
      queryKey: config.queryKey,
      queryFn: config.queryFn,
    },
    ["status", "isFetching", "data", "error"]
  );

  useMountEffect(() => {
    _queryStore.fetch();
  });

  console.log("config: ", config);
  console.log("_queryStore: ", _queryStore);

  return _queryStore;
};
