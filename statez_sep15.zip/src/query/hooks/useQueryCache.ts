import { useRef } from "react";
import { GLOBAL_QUERY_CACHE_STORE } from "../apis/createQueryCacheStore";
import { TQueryStore, createQueryStore } from "../apis/createQueryStore";
import { useStore } from "../../store";

type TQueryCacheStoreConfig = {
  queryKey: string;
  queryFn: Function;
};

export const useQueryCache = (
  config: TQueryCacheStoreConfig,
  subscribeTo?: string[]
) => {
  const _queryStore = useRef<any>(null);

  if (!_queryStore.current) {
    if (GLOBAL_QUERY_CACHE_STORE.queries[config.queryKey]) {
      _queryStore.current = GLOBAL_QUERY_CACHE_STORE.queries[config.queryKey];
    } else {
      _queryStore.current = createQueryStore(config);
      GLOBAL_QUERY_CACHE_STORE.addQuery(config.queryKey, _queryStore.current);
    }
  }

  return useStore(_queryStore.current, subscribeTo) as TQueryStore;
};
