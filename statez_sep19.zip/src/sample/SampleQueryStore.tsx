import { useEffect } from "react";
import { useQuery } from "../react";

type Props = {};

const getMyData = () => {
  console.log("fetching data");
  // throw new Error("error occured");
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // reject({message: 'Something went wrong...'});
      resolve([
        {
          name: "Title 1",
          description: "This is post 1",
        },
        {
          name: "Title 2",
          description: "This is post 2",
        },
      ]);
    }, 1000);
  });
};

const SampleQueryStore = (props: Props) => {
  const queryStore = useQuery({ queryKey: "myQuery", queryFn: getMyData });

  useEffect(() => {
    // queryStore.subscribe(s => {
    //   console.log('s', s)
    // })

    queryStore.fetch();
  }, []);

  console.log("render", queryStore.state);

  if (queryStore.state.isFetching) {
    return <div>Fetching...</div>;
  }

  if (queryStore.state.error) {
    return <div>Error: {queryStore.state.error?.message}</div>;
  }

  return (
    <div>
      {queryStore.state.data?.map((d: any, i: any) => {
        return <p key={i}>{d.name}</p>;
      })}
    </div>
  );
};

export default SampleQueryStore;
