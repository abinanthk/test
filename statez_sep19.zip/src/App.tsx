import SampleQueryStore from "./sample/SampleQueryStore";

const App = () => {
  return <SampleQueryStore />;
};

export default App;
