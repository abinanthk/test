export type TSync = (string | symbol);

export type TNoti<TState> = {
  state: TState;
  prevState: TState;
  change: TSync;
};

export type TListener<TState> = (noti: TNoti<TState>) => void;

export type TStore<TState> = {
  state: TState;
  initState: TState;
  prevState: TState;
  reset: () => void;
  subscribe: (listener: TListener<TState>) => { unsubscribe: () => void };
};

export interface IStore<TState> {
  initState: TState;
  prevState: TState;
  reset: () => void;
  subscribe: (listener: TListener<TState>) => { unsubscribe: () => void };
  notify: (noti: TNoti<TState>) => void;
}
