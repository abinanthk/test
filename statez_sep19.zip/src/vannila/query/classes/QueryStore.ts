import type { TQuery, TQueryStore, TQueryState } from "../types";
import { Store } from "../../store";

export class QueryStore extends Store<TQueryState> implements TQueryStore {
  readonly queryKey: string;
  readonly queryFn: Function;

  constructor(query: TQuery) {
    const initState: TQueryState = {
      status: "idle",
      isFetching: false,
      data: undefined,
      error: undefined,
    };
    super(initState);

    this.queryKey = query?.queryKey;
    this.queryFn = query?.queryFn ? query.queryFn : () => {};
  }

  async fetch() {
    if (this.state.isFetching) {
      return;
    }
    this.state.isFetching = true;
    this.state.status = "pending";

    try {
      const response = await this.queryFn();
      this.state.data = response;
      this.state.status = "resolved";
    } catch (err) {
      this.state.error = err;
      this.state.data = undefined;
      this.state.status = "rejected";
    } finally {
      this.state.isFetching = false;
    }
  }
}
