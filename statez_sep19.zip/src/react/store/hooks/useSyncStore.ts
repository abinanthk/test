import { useStoreEffect } from "..";
import { useForceUpdate } from "../../utils/hooks";
import type { TSync, TStore } from "..";

export const useSyncStore = <T extends TStore<TState>, TState>(
  store: T,
  sync?: TSync[]
) => {
  const forceUpdate = useForceUpdate();

  useStoreEffect<T, TState>(store, () => forceUpdate(), sync);

  return store;
};
