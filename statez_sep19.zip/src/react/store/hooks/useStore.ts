import { useRef } from "react";
import { Store, useSyncStore } from "..";
import type { TSync, TStore } from "..";

export const useStore = <TState extends {}>(
  initState: TState,
  sync?: TSync[]
) => {
  const storeRef = useRef<any>(null);

  if (!storeRef.current) {
    storeRef.current = new Store<TState>(initState);
  }

  return useSyncStore<TStore<TState>, TState>(storeRef.current, sync);
};
