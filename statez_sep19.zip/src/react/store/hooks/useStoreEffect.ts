import { useEffect } from "react";
import type { TSync, TStore, TNoti } from "..";

export const useStoreEffect = <T extends TStore<TState>, TState>(
  store: T,
  fn: (noti: TNoti<TState>) => void,
  sync?: TSync[]
) => {
  useEffect(() => {
    const _sync = sync || Reflect.ownKeys(store.state as object);

    const subscription = store.subscribe((noti: TNoti<TState>) => {
      if (_sync?.includes(noti.change)) {
        fn(noti);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);
};
