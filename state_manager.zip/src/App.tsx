import { createStore, useStore } from "./stores/store";

type TCountStore = {
  value: string;
  count: number;
  incTen: () => void;
};

const countStore = createStore<TCountStore>({
  value: "",
  count: 0,
  incTen() {
    this.count += 10;
  },
});

console.log("counterStore", countStore);

function View() {
  const value = useStore<TCountStore>(countStore, (state) => state.value);

  return (
    <div>
      <p>{value}</p>
    </div>
  );
}

function View2() {
  const count = useStore<TCountStore>(countStore, (state) => state.count);

  return (
    <div>
      <p>{count}</p>
    </div>
  );
}

function Control() {
  const handleChange = (e: any) => {
    countStore.state.value = e.target.value;
  };

  const handleClick = () => {
    countStore.state.count++;
  };

  const handleClick2 = () => {
    countStore.state.incTen();
  };
  const handleReset = () => {
    countStore.reset();
  };
  return (
    <div>
      <input onChange={handleChange} />
      <button onClick={handleClick}>click</button>
      <button onClick={handleClick2}>inc 10</button>
      <button onClick={handleReset}>reset</button>
    </div>
  );
}

export default function App() {
  return (
    <div>
      <View />
      <View2 />
      <Control />
    </div>
  );
}
