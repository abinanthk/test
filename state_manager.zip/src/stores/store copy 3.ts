import { useSyncExternalStore } from "react";

// initState

// state

// proxiedState (this.state) (Copy of state for getting and setting the state)

// handlers

// store -> proxiedState + handlers

export const createStore = <TState>(initState: any) => {
  type TListener = (state: TState) => void;
  type TStore = {
    state: any;
    subscribe: (listener: TListener) => any;
    reset: () => void;
  };

  const listeners: Set<TListener> = new Set();

  
  let _state: any = { ...initState };

  let _store: TStore = {
    state: new Proxy(_state, {
      get(target, prop) {
        return Reflect.get(target, prop);
      },
      set(target, prop, value) {
        if (!Reflect.set(target, prop, value)) {
          return false;
        }
        listeners.forEach((listener) => listener(_state[prop]));
        return true;
      },
    }),

    subscribe(listener: TListener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },

    reset() {
      Object.keys(this.state).forEach((key) => {
        this.state[key] = initState[key];
      });
    },
  };

  return _store;
};

// export const useStore = (store: any, sub: string) => {
//   const getSnapshot = () => store.state[sub];

//   return useSyncExternalStore(store.subscribe, getSnapshot);
// };

type TSelector<TState> = (state: TState) => any;

export const useStore = <TState>(store: any, selector: TSelector<TState>) => {
  const getSnapshot = () => {
    return selector(store.state);
  };

  return useSyncExternalStore(store.subscribe, getSnapshot);
};
