import { useSyncExternalStore } from "react";

// initState
// state
// proxiedState (this.state) (Copy of state for getting and setting the state)
// handlers
// store -> proxiedState + handlers

type TListener = (state: any) => void;
type TStore = {
  state: any;
  subscribe: (listener: TListener) => any;
  reset: () => void;
};

export const createStore = <TState extends {}>(initState: TState) => {
  const listeners: Set<TListener> = new Set();
  const _state: any = { ...initState };
  const _store: TStore = {
    state: new Proxy(_state, {
      get(target, prop) {
        return Reflect.get(target, prop);
      },
      set(target, prop, value) {
        if (!Reflect.set(target, prop, value)) {
          return false;
        }
        listeners.forEach((listener) => listener(_state[prop]));
        return true;
      },
    }),

    subscribe(listener: TListener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },

    reset() {
      Object.entries(initState).forEach(([key, value]) => {
        this.state[key] = value;
      });
    },
  };

  return _store;
};

type TSelector<TState> = (state: TState) => any;

export const useStore = <TState>(
  store: TStore,
  selector: TSelector<TState>
) => {
  const getSnapshot = () => {
    return selector(store.state);
  };

  return useSyncExternalStore(store.subscribe, getSnapshot);
};
