import { useSyncExternalStore } from "react";

export const createStore = (initState: any) => {
  type TState = typeof initState;
  type TListener = (state: TState) => void;
  type TStore = TState & { subscribe: (listener: TListener) => any };

  const _state: TState = initState;
  const listeners: Set<TListener> = new Set();

  const subscribe = (listener: TListener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };

  const _store: TStore = {
    subscribe,
  };

  Object.keys(_state).forEach((k) => {
    if (typeof _state[k] === "function") {
      _store[k] = _state[k];
      return;
    }

    Object.defineProperty(_store, k, {
      set(nextState) {
        _state[k] = nextState;
        listeners.forEach((listener) => listener(_state[k]));
      },
      get() {
        return _state[k];
      },
    });
  });

  return _store;
};

export const useStore = (store: any, sub: string) => {
  const getSnapshot = () => store[sub];

  return useSyncExternalStore(store.subscribe, getSnapshot);
};
