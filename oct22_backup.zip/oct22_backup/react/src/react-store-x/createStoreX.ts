import { StoreX, TDeps, TStoreXConfig } from "../../../vannila";
import { useVannilaStoreX } from "./useVannilaStoreX";

export const createStoreX = <TState extends {}, TReducer extends {}>(
  config: TStoreXConfig<TState, TReducer>
) => {
  const storeX = new StoreX(config);

  const hook = (deps?: TDeps<TState>) =>
    useVannilaStoreX<TState, TReducer>(storeX, deps);

  hook.storeX = storeX;

  return hook;
};
