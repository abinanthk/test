import { StoreX } from "../../../vannila";
import type { TDeps } from "../../../vannila";
import { useSubscription } from "../react-core";

export const useVannilaStoreX = <TState extends {}, TReducer extends {}>(
  storeX: StoreX<TState, TReducer>,
  deps?: TDeps<TState>
) => {
  useSubscription<TState, StoreX<TState, TReducer>>(storeX, deps);
  return storeX;
};
