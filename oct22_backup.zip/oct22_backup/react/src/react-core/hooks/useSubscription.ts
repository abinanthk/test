import { TDeps } from "../../../../vannila";
import { useForceUpdate } from "../../react-utils";
import { TTargetBase } from "./types";
import { useSubscriptionEffect } from "./useSubscriptionEffect";

export const useSubscription = <TState, TTarget extends TTargetBase<TState>>(
  target: TTarget,
  deps?: TDeps<TState>
) => {
  const forceUpdate = useForceUpdate();
  useSubscriptionEffect(target, () => forceUpdate(), deps);
};
