import { ReactNode } from "react";

export type FormRootProps = {
  children: ReactNode;
  form: any;
};

export type FormSubscribeProps = {
  children: any;
  valueDeps?: string[];
  errorDeps?: string[];
};

export type FormFieldProps = {
  children: any;
  name: string;
};
