import { Form, TDeps, TFormConfig } from "../../../vannila";
import { useSingleton } from "../react-utils";
import { useVannilaForm } from "./useVannilaForm";

export const useForm = <
  TValue extends {},
  TError extends {},
  THandler extends {}
>(
  config: TFormConfig<TValue, TError, THandler>,
  valueDeps?: TDeps<TValue>,
  errorDeps?: TDeps<TError>
) => {
  const form = useSingleton<Form<TValue, TError, THandler>>(
    () => new Form<TValue, TError, THandler>(config)
  );

  return useVannilaForm<TValue, TError, THandler>(form, valueDeps, errorDeps);
};
