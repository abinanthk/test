import { Form, IStore, TDeps } from "../../../vannila";
import { useSubscription } from "../react-core";

export const useVannilaForm = <
  TValue extends {},
  TError extends {},
  THandler extends {}
>(
  form: Form<TValue, TError, THandler>,
  valueDeps?: TDeps<TValue>,
  errorDeps?: TDeps<TError>
) => {
  useSubscription<TValue, IStore<TValue, {}>>(form.valueStore, valueDeps);
  useSubscription<TError, IStore<TError, {}>>(form.errorStore, errorDeps);
  return form;
};
