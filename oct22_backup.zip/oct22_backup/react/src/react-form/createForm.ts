import { Form, TDeps, TFormConfig } from "../../../vannila";
import { useVannilaForm } from "./useVannilaForm";

export const createForm = <
  TValue extends {},
  TError extends {},
  THandler extends {}
>(
  config: TFormConfig<TValue, TError, THandler>
) => {
  const form = new Form<TValue, TError, THandler>(config);

  const hook = (valueDeps?: TDeps<TValue>, errorDeps?: TDeps<TError>) =>
    useVannilaForm<TValue, TError, THandler>(form, valueDeps, errorDeps);

  hook.form = form;

  return hook;
};
