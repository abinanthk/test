import { Store, TDeps, TStoreConfig } from "../../../vannila";
import { useVannilaStore } from "./useVannilaStore";

export const createStore = <TState extends {}, TReducer extends {}>(
  config: TStoreConfig<TState, TReducer>
) => {
  const store = new Store(config);

  const hook = (deps?: TDeps<TState>) =>
    useVannilaStore<TState, TReducer>(store, deps);

  hook.store = store;

  return hook;
};
