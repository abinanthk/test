import { Store, TStoreConfig } from "../../../vannila/src/vannila-store";
import { TDeps } from "../../../vannila";
import { useSingleton } from "../react-utils";
import { useVannilaStore } from "./useVannilaStore";

export const useStore = <TState extends {}, TReducer extends {}>(
  config: TStoreConfig<TState, TReducer>,
  deps?: TDeps<TState>
) => {
  const store = useSingleton(() => new Store<TState, TReducer>(config));

  return useVannilaStore<TState, TReducer>(store, deps);
};
