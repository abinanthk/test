import { Store } from "../../../vannila/src/vannila-store";
import { TDeps } from "../../../vannila";
import { useSubscription } from "../react-core";

export const useVannilaStore = <TState extends {}, TReducer extends {}>(
  store: Store<TState, TReducer>,
  deps?: TDeps<TState>
) => {
  useSubscription<TState, Store<TState, TReducer>>(store, deps);
  return store;
};
