import {
  Store,
  StoreCache,
  TDeps,
  TStoreCacheConfig,
} from "../../../vannila";
import { useSubscription } from "../react-core";
import { useMountEffect, useUnMountEffect } from "../react-utils";

export const useStoreCache = <TState extends {}, TReducer extends {}>(
  config: TStoreCacheConfig<TState, TReducer>,
  deps?: TDeps<TState>
) => {
  StoreCache.setStore<TState, TReducer>(config);

  useMountEffect(() => {
    StoreCache.subscribe(config.key);
  });

  useUnMountEffect(() => {
    StoreCache.unsubscribe(config.key);
  });

  useSubscription<TState, Store<TState, TReducer>>(
    StoreCache.getStore(config.key),
    deps
  );

  return StoreCache.getStore(config.key);
};
