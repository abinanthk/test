import { Form } from "../vannila-form";

export interface IFormDevTool {
  register: <TValue extends {}, TypeError extends {}, THandler extends {}>(
    form: Form<TValue, TypeError, THandler>
  ) => void;
}
