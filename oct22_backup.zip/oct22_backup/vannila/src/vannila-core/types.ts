export type TNoti<TTarget> = {
  target: TTarget;
  prop: any;
  value: any;
  prevValue: any;
};

export type TEffect<TTarget> = (noti: TNoti<TTarget>) => void;

export type TDevTools = {
  name: string;
};
