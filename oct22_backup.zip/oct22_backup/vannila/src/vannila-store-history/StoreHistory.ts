import type { IStoreHistory, TStoreHistoryConfig } from "./types";
import { TDeps } from "../vannila-store-x";
import { IStore, TSubscription } from "../vannila-store/types";
import { History } from "../vannila-utils";
import { Subject } from "rxjs";

export class StoreHistory<TState extends {}, TReducer extends {}>
  implements IStoreHistory<TState>
{
  private readonly _store: IStore<TState, TReducer>;
  private readonly _history: History<TState>;
  private historySubscription: TSubscription;
  private _subject$: Subject<any>;

  constructor(config: TStoreHistoryConfig<TState, TReducer>) {
    this._store = config.store;

    this._history = new History({ ...config.store?.config.state } as TState);

    this.historySubscription = config.store.subscribe((noti) => {
      this._history.add({ [noti.prop]: noti.value } as TState);
    });

    this._subject$ = new Subject();
  }

  subscribe(listener: (history: any) => void) {
    return this._subject$.subscribe(listener);
  }

  clear() {
    this._history.clear();
    this._subject$.next({});
  }

  get store() {
    return this._store;
  }

  getUndoList() {
    return this._history.getUndos();
  }

  getRedoList() {
    return this._history.getRedos();
  }

  current() {
    return this._history.current();
  }

  private mutate(snapshot?: TState) {
    if (!snapshot) {
      return;
    }

    this.historySubscription?.unsubscribe();
    const _deps = Reflect.ownKeys(snapshot as object) as TDeps<TState>;

    _deps?.forEach((key) => {
      if (!Reflect.has(this._store.state, key)) {
        return;
      }

      this._store.state[key] = snapshot[key];
    });

    this.historySubscription = this._store.subscribe((noti) => {
      this._history.add({ [noti.prop]: noti.value } as TState);
    });
  }

  undo() {
    const prevSnapshot = this._history.undo();
    const snapshot = this._history.current();

    console.log("prevSnapshot undo : ", prevSnapshot);
    console.log("snapshot undo : ", snapshot);

    this.mutate(snapshot);
    this._subject$.next({});
  }

  redo() {
    const snapshot = this._history.redo();

    console.log("snapshot redo : ", snapshot);

    this.mutate(snapshot);
    this._subject$.next({});
  }
}
