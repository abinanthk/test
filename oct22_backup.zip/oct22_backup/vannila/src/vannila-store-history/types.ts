import { IStore } from "../vannila-store/types";

export type IStoreHistory<TState extends {}> = {
  getUndoList(): TState[] | undefined;
  getRedoList(): TState[] | undefined;
  current(): TState | undefined;
  undo(): void;
  redo(): void;
};

export type TStoreHistoryConfig<TState extends {}, TReducer extends {}> = {
  store: IStore<TState, TReducer>;
};
