import { Subject } from "rxjs";
import { proxy } from "../vannila-core";
import type { TNoti } from "../vannila-core/types";
import type { IStore, TListener, TStoreConfig } from "./types";
import { TDeps } from "../vannila-store-x";
import { DevTools } from "../vannila-devtools";

export class Store<TState extends {}, TReducer extends {}>
  implements IStore<TState, TReducer>
{
  private readonly _config: TStoreConfig<TState, TReducer>;
  protected readonly _subject$: Subject<TNoti<TState>>;
  private readonly _state: TState;
  private readonly _reducer: TReducer;

  constructor(config: TStoreConfig<TState, TReducer>) {
    this._config = config;

    this._subject$ = new Subject<TNoti<TState>>();

    this._state = proxy({ ...config.state }, (noti) => {
      this._subject$.next(noti);
    });

    this._reducer = config?.reducer
      ? config?.reducer(this._state)
      : ({} as TReducer);

      DevTools.register(this)
  }

  get config() {
    return this._config;
  }

  get state() {
    return this._state;
  }
  get reducer() {
    return this._reducer;
  }

  get isObserved() {
    return this._subject$.observed;
  }

  subscribe(listener?: TListener<TState>) {
    return this._subject$.subscribe(listener);
  }

  reset(deps?: TDeps<TState>) {
    const _deps =
      deps || (Reflect.ownKeys(this._config.state as object) as TDeps<TState>);

    _deps?.forEach((key) => {
      if (!Reflect.has(this._config.state, key)) {
        return;
      }

      this.state[key] = this._config.state[key];
    });
  }
}
