import { Subscription } from "rxjs";
import { TNoti } from "../vannila-core/types";

export type TListener<TState> = (noti: TNoti<TState>) => void;
export type TSubscribe<T> = (listener?: TListener<T>) => TSubscription;

export type TSubscription = Subscription | undefined;

export type IStore<TState extends {}, TReducer extends {}> = {
  config: TStoreConfig<TState, TReducer>;
  state: TState;
  reducer: TReducer;
  isObserved: boolean;
  subscribe: TSubscribe<TState>;
};

export type TStoreConfig<TState extends {}, TReducer extends {}> = {
  name?: string;
  state: TState;
  reducer?: (state: TState) => TReducer;
  effect?: (store?: IStore<TState, TReducer>, noti?: TNoti<TState>) => void;
};
