import { Store } from "../vannila-store";
import { IStore } from "../vannila-store/types";
import type { IForm, TFormConfig } from "./types";

export class Form<TValue extends {}, TError extends {}, THandler extends {}>
  implements IForm<TValue, TError, THandler>
{
  private readonly _valueStore: IStore<TValue, {}>;
  private readonly _errorStore: IStore<TError, {}>;
  private readonly _handler?: THandler;
  private readonly _config: TFormConfig<TValue, TError, THandler>;

  constructor({
    value,
    error,
    handler,
    ...config
  }: TFormConfig<TValue, TError, THandler>) {
    this._config = {
      ...config,
      value: { ...value },
      error: { ...error },
    };

    this._valueStore = new Store({
      name: `${config.name}-value`,
      devtools: config.devtools,
      state: value,
    });
    this._errorStore = new Store({
      name: `${config.name}-error`,
      devtools: config.devtools,
      state: error,
    });

    this._handler = handler
      ? handler({ value: this.value, error: this.error })
      : ({} as any);
  }

  get valueStore() {
    return this._valueStore;
  }

  get errorStore() {
    return this._errorStore;
  }

  get value() {
    return this._valueStore.state;
  }

  get error() {
    return this._errorStore.state;
  }

  get handler() {
    return this._handler;
  }

  getConfig() {
    return { ...this._config };
  }

  load() {
    this._config.onLoad?.({ value: this.value, error: this.error });
  }

  submit() {
    this._config.onSubmit?.({ value: this.value, error: this.error });
  }
}
