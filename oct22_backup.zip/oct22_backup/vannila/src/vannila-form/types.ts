import { TDevTools } from "../vannila-core/types";
import { IStore } from "../vannila-store";

export type THandlerFn<TValue, TError, THandler> = ({
  value,
  error,
}: {
  value: TValue;
  error: TError;
}) => THandler;

export type TFormConfig<TValue, TError, THandler> = {
  value: TValue;
  error: TError;
  handler?: THandlerFn<TValue, TError, THandler>;
  onLoad?: THandlerFn<TValue, TError, void>;
  onSubmit?: THandlerFn<TValue, TError, void>;

  // devtools
  name?: string;
  devtools?: boolean;
};

export type IForm<TValue extends {}, TError extends {}, THandler extends {}> = {
  valueStore: IStore<TValue, {}>;
  errorStore: IStore<TError, {}>;
  value: TValue;
  error: TError;
  handler?: THandler;
  getConfig: () => TFormConfig<TValue, TError, THandler>;
  load: () => void;
  submit: () => void;
};
