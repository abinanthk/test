import { Stack } from "../vannila-stack";
import type { IHistory } from "./types";

export class History<TItem> implements IHistory {
  private readonly undos: Stack<TItem>;
  private readonly redos: Stack<TItem>;
  private initItem?: TItem;

  constructor(initItem: TItem) {
    this.undos = new Stack<TItem>();
    this.redos = new Stack<TItem>();

    this.initItem = initItem;
    this.undos.push(initItem);
  }

  clear() {
    this.undos.clear();
    this.redos.clear();
  }

  getAll() {
    return [...this.undos.getAll(), ...this.redos.getAll()];
  }

  getUndos() {
    return this.undos.getAll();
  }

  getRedos() {
    return this.redos.getAll();
  }

  add(item: TItem) {
    this.undos.push(item);
    this.redos.clear();
  }

  current() {
    return this.undos.peek();
  }

  undo() {
    if (this.undos.size < 2) {
      return this.initItem;
    }
    const item = this.undos.pop();

    if (item) {
      this.redos.push(item);
    }

    return item;
  }

  redo() {
    const item = this.redos.pop();

    if (item) {
      this.undos.push(item);
    }

    return item;
  }
}
