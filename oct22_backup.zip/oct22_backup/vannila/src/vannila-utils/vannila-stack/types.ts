export interface IStack<T> {
  push(item: T): void;
  pop(): T | undefined;
  peek(): T | undefined;
  getAll(): T[];
  clear(): void;
  size: number;
  isEmpty: boolean;
  isFull: boolean;
}
