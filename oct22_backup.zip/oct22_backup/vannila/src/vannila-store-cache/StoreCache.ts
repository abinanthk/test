import { StoreX } from "../vannila-store-x";
import { Cache } from "../vannila-utils/vannila-cache";
import { interval, timer } from "rxjs";
import { TStoreCacheConfig } from "./types";

const DEFAULT_STORE_CACHE_CONFIG = {
  cacheTime: 5000,
};

export class StoreCache {
  static cache = new Cache<string, any>();

  static setStore<TState extends {}, TReducer extends {}>(
    config: TStoreCacheConfig<TState, TReducer>
  ) {
    if (config.key && !StoreCache.cache.has(config.key)) {
      const _store = new StoreX<TState, TReducer>(config);
      const _cacheInterval$ = interval(1000);
      const _cacheTimer$ = timer(
        config.cacheTime || DEFAULT_STORE_CACHE_CONFIG.cacheTime
      );
      const _intervalSubscription = null;
      const _timerSubscription = null;

      StoreCache.cache.set(config.key, {
        store: _store,
        cacheInterval$: _cacheInterval$,
        cacheTimer$: _cacheTimer$,
        intervalSubscription: _intervalSubscription,
        timerSubscription: _timerSubscription,
      });
    }
  }

  static getStore(key: string) {
    return StoreCache.cache.get(key).store;
  }

  static subscribe(key: string) {
    const storeCache = StoreCache.cache.get(key);
    storeCache.store.init();

    if (
      !!(
        storeCache.intervalSubscription &&
        !storeCache.intervalSubscription.closed
      )
    ) {
      return;
    }

    storeCache.intervalSubscription = storeCache.cacheInterval$.subscribe(
      (e: any) => {
        if (storeCache.store.isObserved) {
          if (
            !!(
              storeCache.timerSubscription &&
              !storeCache.timerSubscription.closed
            )
          ) {
            storeCache.timerSubscription.unsubscribe();
          }

          return;
        }

        if (
          !!(
            storeCache.timerSubscription && !storeCache.timerSubscription.closed
          )
        ) {
          return;
        }

        storeCache.timerSubscription = storeCache.cacheTimer$.subscribe(() => {
          StoreCache.unsubscribe(key);
          StoreCache.cache.remove(key);
        });
      }
    );
  }

  static unsubscribe(key: string) {
    const storeCache = StoreCache.cache.get(key);

    if (storeCache.store.isObserved) {
      return;
    }

    storeCache.store?.unsubscribe();
    storeCache.intervalSubscription?.unsubscribe();
    storeCache.timerSubscription?.unsubscribe();
  }
}
