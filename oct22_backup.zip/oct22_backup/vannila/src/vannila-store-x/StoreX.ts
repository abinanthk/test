import { Observable, timer } from "rxjs";
import { Store, TSubscription } from "../vannila-store";
import { IStore, TListener } from "../vannila-store/types";
import type { IStoreX, TStoreXConfig, TDeps } from "./types";

const DEFAULT_STORE_CONFIG = {
  initTime: 0,
  staleTime: 60000,
};

export class StoreX<TState extends {}, TReducer extends {}>
  implements IStoreX<TState, TReducer>
{
  private readonly _store: IStore<TState, TReducer>;
  private readonly _config: TStoreXConfig<TState, TReducer>;
  private _staleTimer$: Observable<number>;
  private _subscription: TSubscription;

  constructor({
    initTime = DEFAULT_STORE_CONFIG.initTime,
    staleTime = DEFAULT_STORE_CONFIG.staleTime,
    onLoad,
    onSave,
    ...config
  }: TStoreXConfig<TState, TReducer>) {
    this._config = {
      onLoad,
      onSave,
      ...config,
    };

    this._store = new Store(config);

    this._staleTimer$ = timer(initTime, staleTime);
  }

  get state() {
    return this._store.state;
  }

  get reducer() {
    return this._store.reducer;
  }

  get isObserved() {
    return this._store.isObserved;
  }

  init() {
    if (this._subscription && !this._subscription.closed) {
      return;
    }

    this._subscription = this._staleTimer$.subscribe(() => {
      if (this.isObserved) {
        this._config.onLoad?.(this.state);
        return;
      }
      this._subscription?.unsubscribe();
    });
  }

  unsubscribe() {
    if (this.isObserved) {
      return;
    }

    this._subscription?.unsubscribe();
  }

  subscribe(listener?: TListener<TState>) {
    const subscription = this._store.subscribe(listener);
    this.init();
    return subscription;
  }

  getConfig() {
    return { ...this._config };
  }

  reset(deps?: TDeps<TState>) {
    const _deps =
      deps || (Reflect.ownKeys(this._config.state as object) as TDeps<TState>);

    _deps?.forEach((key) => {
      if (!Reflect.has(this._config.state, key)) {
        return;
      }

      this.state[key] = this._config.state[key];
    });
  }

  load() {
    this._config.onLoad?.(this.state);
  }

  save() {
    this._config.onSave?.(this.state);
  }
}
