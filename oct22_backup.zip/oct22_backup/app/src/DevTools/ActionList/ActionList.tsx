import { useDevToolsActions } from "../../../../../packages/react";
import { Store } from "../../../../../packages/vannila";

export type ActionItemProps = {
  store: Store<any, any>;
};
const ActionItem = ({ store }: ActionItemProps) => {
  console.log("store : ", store);

  const fields = Object.entries(store.state).map(([key, value]) => {
    return (
      <div key={key}>
        <p>
          {key} : {JSON.stringify(value)}
        </p>
      </div>
    );
  });

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          fontWeight: "bold",
          padding: 5,
          margin: 5,
          backgroundColor: "#333",
          color: "#eee",
        }}
      >
        {store.config?.name}
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        {fields}
      </div>
    </div>
  );
};

export const ActionList = () => {
  const action = useDevToolsActions();

  console.log("action : ", action);

  const prop = action.noti.prop;
  const prevValue = action.noti.prevValue || "";
  const currValue = action.noti.target?.[prop] || "";

  return (
    <div>
      <p>--- Actions ---</p>
      <div>
        <p>{prop}</p>
        <p>{`${prevValue} ==> ${currValue}`}</p>
      </div>
    </div>
  );
};
