import { useEffect } from "react";
import { useDevToolsHistory } from "../../../../../packages/react";
import { StoreHistory } from "../../../../../packages/vannila";
import { useForceUpdate } from "../../../../../packages/react/src/react-utils";

const useHistoryEffect = (history: StoreHistory<any, any>) => {
  const forceUpdate = useForceUpdate();

  useEffect(() => {
    const subscription = history.subscribe((e) => {
      console.log("mutation history : ", e);
      forceUpdate();
    });

    return () => subscription.unsubscribe();
  }, []);
};

export type HistoryItemProps = {
  history: StoreHistory<any, any>;
};
const HistoryItem = ({ history }: HistoryItemProps) => {
  useHistoryEffect(history);

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          backgroundColor: "#333",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div
          style={{
            fontWeight: "bold",
            padding: 5,
            margin: 5,
            color: "#eee",
          }}
        >
          {history.store?.config?.name}
        </div>

        <div style={{ display: "flex", gap: 5 }}>
          <button onClick={() => history.undo()}>undo</button>
          <button onClick={() => history.redo()}>redo</button>
          <button onClick={() => history.clear()}>clear</button>
        </div>
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        <div
          style={{ display: "flex", gap: 10, height: 200, overflow: "auto" }}
        >
          <div>
            <span>--- undo list ---</span>
            {history.getUndoList().map((s, i) => {
              return <div key={i}>{JSON.stringify(s)}</div>;
            })}
          </div>
          <div>
            <span>--- redo list ---</span>
            {history.getRedoList().map((s, i) => {
              return <div key={i}>{JSON.stringify(s)}</div>;
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export const HistoryList = () => {
  const history = useDevToolsHistory();

  console.log("history : ", history);

  return (
    <div>
      <p>--- History ---</p>
      <div>
        {history.map((historyItem, i) => (
          <div key={i}>
            <HistoryItem history={historyItem} />
          </div>
        ))}
      </div>
    </div>
  );
};
