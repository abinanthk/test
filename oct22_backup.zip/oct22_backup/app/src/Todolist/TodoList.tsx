import { TaskForm, TaskForm2 } from "./TaskForm";
import { TaskList } from "./TaskList";

export const TodoList = () => {
  return (
    <div>
      <TaskForm2 />
      <TaskList />
    </div>
  );
};
