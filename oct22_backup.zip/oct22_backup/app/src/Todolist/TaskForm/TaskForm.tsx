import { TTaskPriority, useTaskForm } from "../store";

export const TaskForm = () => {
  const form = useTaskForm();
  return (
    <div>
      <div
        style={{ display: "flex", flexDirection: "column", width: 200, gap: 5 }}
      >
        <span>Title</span>
        <input
          value={form.value.title}
          onChange={(e) => (form.value.title = e.target.value)}
        />
        <span>{form.error.title}</span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          width: 200,
          gap: 5,
          marginTop: 10,
          marginBottom: 10,
        }}
      >
        <span>Description</span>
        <input
          value={form.value.description}
          onChange={(e) => (form.value.description = e.target.value)}
        />
        <span>{form.error.description}</span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          width: 200,
          gap: 5,
          marginTop: 10,
          marginBottom: 10,
        }}
      >
        <span>Priority</span>
        <select
          value={form.value.priority}
          onChange={(e) =>
            (form.value.priority = e.target.value as TTaskPriority)
          }
        >
          <option value={"low"}>Low</option>
          <option value={"medium"}>Medium</option>
          <option value={"high"}>High</option>
        </select>
        <span>{form.error.description}</span>
      </div>

      <button onClick={() => form.submit()}>Add</button>
    </div>
  );
};
