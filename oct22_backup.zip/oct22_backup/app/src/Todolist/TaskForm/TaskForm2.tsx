import { Form } from "../../../../../packages/react";
import { useMountEffect } from "../../../../../packages/react/src/react-utils";
import { TTaskPriority, useTaskForm } from "../store";

export const TaskForm2 = () => {
  const formStore = useTaskForm([], []);
  console.log("render");

  useMountEffect(() => {
    formStore.load();
  });

  return (
    <Form.Root form={formStore}>
      <div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            width: 200,
            gap: 5,
          }}
        >
          <span>Title</span>
          <Form.Subscribe
            valueDeps={["title"]}
            children={({ value }: { value: typeof formStore.value }) => (
              <input
                value={value.title}
                onChange={(e) => formStore.handler?.title(e.target.value)}
              />
            )}
          />

          <Form.Subscribe
            errorDeps={["title"]}
            children={({ error }: { error: typeof formStore.error }) => (
              <span>{error.title}</span>
            )}
          />
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            width: 200,
            gap: 5,
            marginTop: 10,
            marginBottom: 10,
          }}
        >
          <span>Description</span>
          <Form.Subscribe
            valueDeps={["title", "description"]}
            children={({ value }: { value: typeof formStore.value }) => (
              <input
                value={value.description}
                onChange={(e) => formStore.handler?.description(e.target.value)}
              />
            )}
          />
          <Form.Subscribe
            errorDeps={["description"]}
            children={({ error }: { error: typeof formStore.error }) => (
              <span>{error.description}</span>
            )}
          />
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            width: 200,
            gap: 5,
            marginTop: 10,
            marginBottom: 10,
          }}
        >
          <span>Priority</span>
          <Form.Subscribe
            valueDeps={["priority"]}
            children={({ value }: { value: typeof formStore.value }) => (
              <select
                value={value.priority}
                onChange={(e) =>
                  (value.priority = e.target.value as TTaskPriority)
                }
              >
                <option value={"low"}>Low</option>
                <option value={"medium"}>Medium</option>
                <option value={"high"}>High</option>
              </select>
            )}
          />
        </div>

        <button onClick={() => formStore.submit()}>Add</button>
      </div>
    </Form.Root>
  );
};
