import { useState } from "react";
import SampleApi from "./sample/SampleApi";
import SampleForm from "./sample/SampleForm";
import SampleTodoList from "./sample/SampleTodoList";
import SampleCache from "./sample/SampleCache";
import SampleForm2 from "./sample/SampleForm2";
import { TodoList } from "./Todolist";
import { MainLayout } from "./DevTools";

const App = () => {
  const [show, setShow] = useState(true);
  const [show2, setShow2] = useState(true);
  // return (
  //   <div style={{ display: "flex", gap: 30 }}>
  //     <div>
  //       <button onClick={() => setShow((prev) => !prev)}>show</button>
  //       {show && <SampleCache />}
  //     </div>

  //     <div>
  //       <button onClick={() => setShow2((prev) => !prev)}>show2</button>
  //       {show2 && <SampleCache />}
  //     </div>
  //   </div>
  // );
  // return (
  //   <div>
  //     <button onClick={() => setShow((prev) => !prev)}>show</button>
  //     {show && (
  //       <div style={{ display: "flex", gap: 10 }}>
  //         <SampleTodoList />
  //         <SampleTodoList />
  //       </div>
  //     )}
  //   </div>
  // );
  // return <SampleForm />;
  // return (
  //   <div>
  //     <button onClick={() => setShow((prev) => !prev)}>show</button>
  //     {show && <SampleApi />}
  //   </div>
  // );
  // return (
  //   <div>
  //     <button onClick={() => setShow((prev) => !prev)}>show</button>
  //     {show && <SampleForm2 />}
  //   </div>
  // );
  // return (
  //   <div>
  //     <button onClick={() => setShow((prev) => !prev)}>show</button>
  //     <div style={{ margin: 20 }} />
  //     {show && <SampleForm />}
  //     <div style={{ margin: 20 }} />
  //     {show && <SampleForm2 />}
  //   </div>
  // );
  return (
    <div style={{display: 'flex', gap: 10}}>
      <TodoList />
      <MainLayout />
    </div>
  );
};

export default App;
