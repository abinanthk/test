import { StoreCache } from "../../../../packages/vannila";
import { useStoreCache } from "../../../../packages/react";

const reducer = (state: {
  count: number;
}): {
  increment: () => void;
  decrement: () => void;
  clear: () => void;
} => ({
  increment: () => {
    state.count++;
  },
  decrement: () => {
    state.count--;
  },
  clear: () => {
    state.count = 0;
  },
});

setInterval(() => {
  console.log("StoreCache", StoreCache.cache);
}, 1000);

const SampleCache = () => {
  const myStore = useStoreCache<
    {
      count: number;
    },
    {
      increment: () => void;
      decrement: () => void;
      clear: () => void;
    }
  >(
    {
      state: {
        count: 0,
      },
      reducer,
      onLoad: (state) => {
        console.log("loading...");

        state.count++;
      },
      key: "myStore",
      autoLoad: false,
    },
    ["count"]
  );


  return (
    <div>
      <p>chache</p>
      <div>
        <p>{myStore.state.count}</p>
        <button onClick={() => myStore.reducer.increment()}>click</button>
      </div>
    </div>
  );
};

export default SampleCache;
