import { useRef } from "react";

import { useStoreCache } from "../../../../packages/react";

type Props = {};

type TTodoList = {
  tasks: string[];
  addTask: (task: string) => void;
  removeTask: (task: string) => void;
};

const SampleTodoList = (props: Props) => {
  const todoStoreCache = useStoreCache<TTodoList, {}>(
    {
      state: {
        tasks: [],
        addTask(task) {
          if (this.tasks.includes(task)) {
            return;
          }

          this.tasks = [...this.tasks, task];
        },
        removeTask(task) {
          this.tasks = this.tasks.filter((t) => t !== task);
        },
      },

      key: "todoList",
      onLoad: (state) => {
        console.log("loader", state);
        const tasks = localStorage.getItem("todo");

        if (tasks) {
          state.tasks = JSON.parse(tasks);
        }
      },
      onSave: (state) => {
        localStorage.setItem("todo", JSON.stringify(state.tasks));
      },
      initTime: 1000,
      staleTime: 2000,
      // cacheTime: 10000,
    },
    ["tasks"]
  );

  const inpRef = useRef<any>();

  const handleAdd = () => {
    todoStoreCache.store.state.addTask(inpRef.current.value);
    inpRef.current.value = "";
  };

  return (
    <div>
      <div>
        <input ref={inpRef} />
        <button onClick={handleAdd}>add</button>
        <button onClick={() => todoStoreCache.store.load()}>load</button>
        <button onClick={() => todoStoreCache.store.save()}>save</button>
      </div>
      <div>
        <button onClick={() => todoStoreCache.store.reset()}>reset</button>
      </div>
      <div>
        {todoStoreCache.store.state.tasks?.map((task: any) => {
          return <div key={task}>{task}</div>;
        })}
      </div>
    </div>
  );
};

export default SampleTodoList;
