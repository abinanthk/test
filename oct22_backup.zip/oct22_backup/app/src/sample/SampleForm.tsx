import { Form, useForm } from "../../../../packages/react";

const SampleForm = () => {
  const formStore = useForm(
    {
      state: {
        username: "",
        password: "",
      },
      onSubmit: (state) => {
        console.log("save", state);
      },
    },
    []
  );

  console.log("reder");
  return (
    <Form.Root form={formStore}>
      <Form.Field
        name={"username"}
        children={(state: typeof formStore.state) => (
          <div>
            <span>Username</span>
            <input
              value={state.username}
              onChange={(e) => (state.username = e.target.value)}
            />
          </div>
        )}
      />

      <Form.Field
        name={"password"}
        children={(state: typeof formStore.state) => (
          <div>
            <span>Password</span>
            <input
              value={state.password}
              onChange={(e) => (state.password = e.target.value)}
            />
          </div>
        )}
      />
      <button onClick={() => formStore.submit()}>login</button>
    </Form.Root>
  );
};

export default SampleForm;
