import { useForm } from "../../../../packages/react";

const SampleForm2 = () => {
  const form = useForm({
    state: {
      username: "",
      password: "",
    },
    onLoad: (state) => {
      console.log("loading...", state);
    },
    onSubmit: (state) => {
      console.log("submitting...", state);
    },
  });

  console.log("render--", form);

  return (
    <div>
      <div>
        <span>Username</span>
        <input
          value={form.state.username}
          onChange={(e) => (form.state.username = e.target.value)}
        />
      </div>

      <div>
        <span>Password</span>
        <input
          value={form.state.password}
          onChange={(e) => (form.state.password = e.target.value)}
        />
      </div>
      <button onClick={() => form.submit()}>login</button>
    </div>
  );
};

export default SampleForm2;
