import { useRef, useEffect } from "react";
import { createStore, useStore, StoreApi } from "zustand";

// store types
export type ListStoreTypes<T> = {
  data: T[];
  insert: (value: T) => void;
  delete: (value: T) => void;
  reset: () => void;
};
export type ListStoreApiTypes<T> = StoreApi<ListStoreTypes<T>>;
export type ListStoreSelectorTypes<T, S> = (state: ListStoreTypes<T>) => S;

export const useList = <T>() => {
  const storeRef = useRef<any>();

  if (!storeRef.current) {
    storeRef.current = createStore<ListStoreTypes<T>>((set) => ({
      data: [],
      insert: (value: T) => {
        set((state) => ({ data: [...state.data, value] }));
      },
      delete: (value: T) => {
        set((state) => {
          const newData = state.data.filter((val) => {
            val !== value;
          });
          return { data: newData };
        });
      },
      reset: () => {},
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

export const useListStore = <T, S>(
  store: ListStoreApiTypes<T>,
  selector?: ListStoreSelectorTypes<T, S>
) => {
  return useStore(store, selector);
};
