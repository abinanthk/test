import { Select } from "../components/Select";

type Props = {};

const PageSelect = (props: Props) => {
  return (
    <div className="m-5">
      <Select
        defaultValue={"male"}
        name="gender"
        onChange={(value) => {
          console.log("select value", value);
        }}
      >
        <Select.Trigger>
          <Select.Label>select</Select.Label>
        </Select.Trigger>
        
        <Select.Content>
          <Select.Option value="male">
            <Select.Toggle className="flex items-center gap-2">
              <Select.Selected className="bg-green-400 ">
                <Select.Label>male</Select.Label>
              </Select.Selected>
              <Select.UnSelected className="bg-red-400  ">
                <Select.Label>male</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="female">
            <Select.Toggle className="flex items-center gap-2">
              <Select.Selected className="bg-green-400 ">
                <Select.Label>female</Select.Label>
              </Select.Selected>
              <Select.UnSelected className="bg-red-400  ">
                <Select.Label>female</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="others">
            <Select.Toggle className="flex items-center gap-2">
              <Select.Selected className="bg-green-400 ">
                <Select.Label>others</Select.Label>
              </Select.Selected>
              <Select.UnSelected className="bg-red-400  ">
                <Select.Label>others</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>
        </Select.Content>
      </Select>
    </div>
  );
};

export default PageSelect;
