import { create } from "zustand";

type StoreType = {
  count: number;
  count2: number;
  setCount: (c: number) => void;
  increment: () => void;
  decrement: () => void;
  increment2: () => void;
  decrement2: () => void;
};

const useStore = create<StoreType>((set) => ({
  count: 0,
  count2: 0,
  setCount: (c: number) => {
    set(() => ({ count: c }));
  },
  increment: () => {
    set((state) => ({ count: state.count + 1 }));
  },
  decrement: () => {
    set((state) => ({ count: state.count - 1 }));
  },
  increment2: () => {
    set((state) => ({ count2: state.count2 + 1 }));
  },
  decrement2: () => {
    set((state) => ({ count2: state.count2 - 1 }));
  },
}));

const useStore2 = () => create<StoreType>((set) => ({
    count: 0,
    count2: 0,
    setCount: (c: number) => {
      set(() => ({ count: c }));
    },
    increment: () => {
      set((state) => ({ count: state.count + 1 }));
    },
    decrement: () => {
      set((state) => ({ count: state.count - 1 }));
    },
    increment2: () => {
      set((state) => ({ count2: state.count2 + 1 }));
    },
    decrement2: () => {
      set((state) => ({ count2: state.count2 - 1 }));
    },
  }))();

const Display = () => {
  const { count } = useStore2();

  console.log("Display");

  return (
    <div className="m-10 inline-flex flex-col gap-10">
      <span> count : {count}</span>
    </div>
  );
};

const Modify = () => {
  //   const increment = useStore((state) => state.increment);
  const decrement = useStore((state) => state.decrement);

  const { increment } = useStore((state) => ({
    increment: state.increment,
  }));

  console.log("Modify");

  return (
    <div className="m-5 inline-flex flex-col gap-10">
      <button
        className="bg-green-400 p-2 text-white rounded-md"
        onClick={increment}
      >
        increment1
      </button>
      <button
        className="bg-red-400 p-2 text-white rounded-md"
        onClick={decrement}
      >
        decrement1
      </button>
    </div>
  );
};

const Modify2 = () => {
  const mod = useStore.getState();

  console.log("Modify2");

  return (
    <div className="m-5 inline-flex flex-col gap-10">
      <button
        className="bg-green-400 p-2 text-white rounded-md"
        onClick={mod.increment2}
      >
        increment2
      </button>
      <button
        className="bg-red-400 p-2 text-white rounded-md"
        onClick={mod.decrement2}
      >
        decrement2
      </button>
    </div>
  );
};

const Page2 = () => {
  const count2 = useStore((state) => state.count2);
  const inc = useStore((state) => state.increment);
  // const {count, count2} = useStore((state) => ({count: -100, increment2: state.increment2, count2: state.count2}));
  //   const {count2} = useStore();

  const count = -100;

  console.log("page2 render", count2);

  return (
    <div className="m-10 inline-flex flex-col">
      count1 : {count}
      &nbsp; &nbsp; &nbsp; count2 : {count2}
      <Display />
      <Modify />
      <Modify2 />
    </div>
  );
};

export default Page2;
