import {
  PropsWithChildren,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import { Portal } from "../Portal";

type UseModalTypes = {
  modalRef: React.Ref<any>;
  init?: boolean;
};

export const useModal = ({ modalRef, init = false }: UseModalTypes) => {
  const [visible, setVisible] = useState<boolean>(init);

  useImperativeHandle(
    modalRef,
    () => {
      return {
        visible,
        open: () => setVisible(true),
        close: () => setVisible(false),
        toggle: () => setVisible((prev) => !prev),
      };
    },
    []
  );
  return { visible };
};

const Modal = ({ children, modalRef, modalRef2, ele }: PropsWithChildren) => {
  const { visible } = useModal({ modalRef });

  return <div ref={modalRef2}>{visible && <Portal ele={ele}>{children}</Portal>}</div>;
};

export default Modal;
