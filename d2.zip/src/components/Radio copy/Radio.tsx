import {
  RadioProps,
  RadioSelectedProps,
  RadioUnSelectedProps,
  RadioTriggerProps,
  RadioLabelProps,
} from "./Radio.types";
import {
  RadioContext,
  useRadio,
  useRadioStoreInContext,
  useRadioContext,
  RadioGroupContext,
  useRadioGroup,
  useRadioGroupStoreInContext,
} from "./Radio.hooks";

// Radio provider for using multiple instance
export function Radio({ store, value, ...props }: RadioProps) {
  const _store = useRadio({ store, init: { value } });

  return (
    <RadioContext.Provider value={_store}>
      <div {...props} />
    </RadioContext.Provider>
  );
}

Radio.Selected = (props: RadioSelectedProps) => {
  const isSelected = useRadioStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? <div {...props} /> : null;
};

Radio.UnSelected = (props: RadioUnSelectedProps) => {
  const isSelected = useRadioStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? null : <div {...props} />;
};

Radio.Trigger = (props: RadioTriggerProps) => {
  const toggle = useRadioStoreInContext<() => void>((state) => state.toggle);
  const radioCtx = useRadioContext()?.getState();

  const select = useRadioGroupStoreInContext((state) => state.select);

  console.log('radioCtx', radioCtx)

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        // if()
        props.onClick?.(e);
      }}
    />
  );
};

Radio.Label = (props: RadioLabelProps) => {
  return <label {...props} />;
};

Radio.Group = ({ store, ...props }: RadioProps) => {
  const _store = useRadioGroup();

  return (
    <RadioGroupContext.Provider value={_store}>
      <div {...props} />
    </RadioGroupContext.Provider>
  );
};
