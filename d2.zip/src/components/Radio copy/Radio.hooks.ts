import { createContext, useContext, useEffect, useRef } from "react";
import {
  RadioStoreTypes,
  RadioStoreApiTypes,
  RadioStoreSelectorTypes,
  RadioGroupStoreTypes,
  RadioGroupStoreApiTypes,
  RadioGroupStoreSelectorTypes,
} from "./Radio.types";
import { createStore, useStore } from "zustand";


// creates a Radio store | internal & external use
export const useRadio = ({
  store,
  init,
}: {
  store?: any;
  init?: { value?: string; isSelected?: boolean };
}) => {
  const storeRef = useRef<RadioStoreApiTypes>(store);

  if (!storeRef.current) {
    storeRef.current = createStore<RadioStoreTypes>((set) => ({
      value: init?.value || "",
      isSelected: init?.isSelected || false,
      select: () => {
        set(() => ({ isSelected: true }));
      },
      unselect: () => {
        set(() => ({ isSelected: false }));
      },
      toggle: () => {
        set((state) => ({ isSelected: !state.isSelected }));
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// use the Radio store (controlled/uncontrolled) | external use
export const useRadioStore = <T>(
  store: RadioStoreApiTypes,
  selector: RadioStoreSelectorTypes<T>
) => {
  return useStore(store, selector);
};

// context to avoid prop drilling | internal use
export const RadioContext = createContext<RadioStoreApiTypes | null>(null);

// use the Radio store in the context (controlled/uncontrolled) | internal use
export const useRadioContext = () => {
  return useContext(RadioContext);
};

// use the Radio store in the context (controlled/uncontrolled) | internal use
export const useRadioStoreInContext = <T>(
  selector: RadioStoreSelectorTypes<T>
) => {
  const store = useContext(RadioContext);
  if (!store) {
    throw new Error("Missing Radio.Provider");
  }

  return useStore(store, selector);
};

export const useRadioGroup = ({
  store,
  init,
}: {
  store?: any;
  init?: { value?: string; name?: boolean };
}) => {
  const storeRef = useRef<RadioGroupStoreApiTypes>(store);

  if (!storeRef.current) {
    storeRef.current = createStore<RadioGroupStoreTypes>((set) => ({
      value: init?.value || "",
      select: (value: string) => {
        set(() => ({ value }));
      },
      unselect: () => {
        set(() => ({ value: "" }));
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const RadioGroupContext = createContext<RadioGroupStoreApiTypes | null>(
  null
);

// use the Radio store in the context (controlled/uncontrolled) | internal use
export const useRadioGroupContext = () => {
  return useContext(RadioGroupContext);
};

export const useRadioGroupStoreInContext = <T>(
  selector: RadioGroupStoreSelectorTypes<T>
) => {
  const store = useContext(RadioGroupContext);
  if (!store) {
    throw new Error("Missing Radio.Provider");
  }

  return useStore(store, selector);
};
