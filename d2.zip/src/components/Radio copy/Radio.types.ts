import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// store types
export type RadioStoreTypes = {
  value: string;
  isSelected: boolean;
  select: () => void;
  unselect: () => void;
  toggle: () => void;
};
export type RadioStoreApiTypes = StoreApi<RadioStoreTypes>;
export type RadioStoreSelectorTypes<T> = (state: RadioStoreTypes) => T;

// component types
export type RadioProps = ComponentProps<"div"> & {
  store?: RadioStoreApiTypes;
  value?: string;
};
export type RadioSelectedProps = ComponentProps<"div">;
export type RadioUnSelectedProps = ComponentProps<"div">;
export type RadioTriggerProps = ComponentProps<"div">;
export type RadioLabelProps = ComponentProps<"label">;

// store types
export type RadioGroupStoreTypes = {
  value: string;
  select: (value: string) => void;
  unselect: () => void;
};
export type RadioGroupStoreApiTypes = StoreApi<RadioGroupStoreTypes>;
export type RadioGroupStoreSelectorTypes<T> = (
  state: RadioGroupStoreTypes
) => T;

// component types
export type RadioGroupProps = ComponentProps<"div"> & {
  store?: RadioGroupStoreApiTypes;
};
