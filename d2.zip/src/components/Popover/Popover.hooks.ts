import { createContext, useContext, useEffect, useRef } from "react";
import {
  PopoverStoreTypes,
  PopoverStoreApiTypes,
  PopoverStoreSelectorTypes,
} from "./Popover.types";
import { createStore, useStore } from "zustand";

// creates a Popover store | internal & external use
export const usePopover = (store?: any) => {
  const storeRef = useRef<PopoverStoreApiTypes>(store);

  if (!storeRef.current) {
    storeRef.current = createStore<PopoverStoreTypes>((set) => ({
      visible: false,
      show: () => {
        set(() => ({ visible: true }));
      },
      hide: () => {
        set(() => ({ visible: false }));
      },
      toggle: () => {
        set((state) => ({ visible: !state.visible }));
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// use the Popover store (controlled/uncontrolled) | external use
export const usePopoverStore = <T>(
  store: PopoverStoreApiTypes,
  selector: PopoverStoreSelectorTypes<T>
) => {
  return useStore(store, selector);
};

// context to avoid prop drilling | internal use
export const PopoverContext = createContext<PopoverStoreApiTypes | null>(null);

export const usePopoverContext = () => {
  return useContext(PopoverContext);
};

// use the Popover store in the context (controlled/uncontrolled) | internal use
export const usePopoverStoreInContext = <T>(
  selector: PopoverStoreSelectorTypes<T>
) => {
  const store = usePopoverContext();
  if (!store) {
    throw new Error("Missing Popover.Provider");
  }

  return useStore(store, selector);
};

export const useBodyEvent = (handler: () => void) => {
  useEffect(() => {
    document.body.addEventListener("click", handler);
    return () => document.body.removeEventListener("click", handler);
  }, []);
};
