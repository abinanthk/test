import { ComponentProps } from "react";

export type HeaderProps = ComponentProps<"header">;
