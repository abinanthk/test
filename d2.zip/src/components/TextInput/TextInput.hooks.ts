import { createContext, useContext, useEffect, useRef } from "react";
import {
  TextInputStoreTypes,
  TextInputStoreApiTypes,
  TextInputStoreSelectorTypes,
} from "./TextInput.types";
import { createStore, useStore } from "zustand";

// creates a TextInput store | internal & external use
export const useTextInput = (store?: any) => {
  const storeRef = useRef<TextInputStoreApiTypes>(store);

  if (!storeRef.current) {
    storeRef.current = createStore<TextInputStoreTypes>((set) => ({
      isOn: false,
      on: () => {
        set(() => ({ isOn: true }));
      },
      off: () => {
        set(() => ({ isOn: false }));
      },
      toggle: () => {
        set((state) => ({ isOn: !state.isOn }));
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// use the TextInput store (controlled/uncontrolled) | external use
export const useTextInputStore = <T>(
  store: TextInputStoreApiTypes,
  selector: TextInputStoreSelectorTypes<T>
) => {
  return useStore(store, selector);
};

// context to avoid prop drilling | internal use
export const TextInputContext = createContext<TextInputStoreApiTypes | null>(null);

// use the TextInput store in the context (controlled/uncontrolled) | internal use
export const useTextInputStoreInContext = <T>(
  selector: TextInputStoreSelectorTypes<T>
) => {
  const store = useContext(TextInputContext);
  if (!store) {
    throw new Error("Missing TextInput.Provider");
  }

  return useStore(store, selector);
};
