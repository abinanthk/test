import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// store types
export type TextInputStoreTypes = {
  isOn: boolean;
  on: () => void;
  off: () => void;
  toggle: () => void;
};
export type TextInputStoreApiTypes = StoreApi<TextInputStoreTypes>;
export type TextInputStoreSelectorTypes<T> = (state: TextInputStoreTypes) => T;

// component types
export type TextInputProps = ComponentProps<"input"> & {
  store?: TextInputStoreApiTypes;
};
export type TextInputOnProps = ComponentProps<"div">;
export type TextInputOffProps = ComponentProps<"div">;
export type TextInputTriggerProps = ComponentProps<"div">;
