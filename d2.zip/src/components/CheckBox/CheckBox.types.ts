import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// hook types
export type CheckBoxHookTypes = {
  value?: string;
  isSelected?: boolean;
  onChange?: (isSelected: boolean) => void;
};

// store types
export type CheckBoxStoreTypes = {
  value: string;
  isSelected: boolean;
  select: () => void;
  unselect: () => void;
  toggle: () => void;
};
export type CheckBoxStoreApiTypes = StoreApi<CheckBoxStoreTypes>;
export type CheckBoxStoreSelectorTypes<T> = (state: CheckBoxStoreTypes) => T;

// component types
export type CheckBoxProps = ComponentProps<"div"> & {
  store?: CheckBoxStoreApiTypes;
  name?: string;
  value?: string;
  defaultChecked?: boolean;
  onChange?: (isSelected: boolean) => void;
};
export type CheckBoxSelectedProps = ComponentProps<"div">;
export type CheckBoxUnSelectedProps = ComponentProps<"div">;
export type CheckBoxToggleProps = ComponentProps<"div">;
export type CheckBoxLabelProps = ComponentProps<"label">;

// hook types
// hook types
export type CheckBoxGroupHookTypes = {
  defaultValue?: string[];
  onChange?: (value: string[]) => void;
};

// store types
export type CheckBoxGroupStoreTypes = {
  value: string[];
  checkBoxStores: CheckBoxStoreApiTypes[];
  add: (checkBoxStore: CheckBoxStoreApiTypes) => void;
  refresh: () => void;
};
export type CheckBoxGroupStoreApiTypes = StoreApi<CheckBoxGroupStoreTypes>;

// component types
export type CheckBoxGroupProps = ComponentProps<"div"> & {
  store?: CheckBoxGroupStoreApiTypes;
  name?: string;
  defaultValue?: string[];
  onChange?: (value: string[]) => void;
};
