import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// hook types
export type SelectOptionHookTypes = {
  value?: string;
  isSelected?: boolean;
  onChange?: (isSelected: boolean) => void;
};

// store types
export type SelectOptionStoreTypes = {
  value: string;
  isSelected: boolean;
  select: () => void;
  unselect: () => void;
  toggle: () => void;
};
export type SelectOptionStoreApiTypes = StoreApi<SelectOptionStoreTypes>;
export type SelectOptionStoreSelectorTypes<T> = (
  state: SelectOptionStoreTypes
) => T;

// component types
export type SelectOptionProps = ComponentProps<"div"> & {
  store?: SelectOptionStoreApiTypes;
  name?: string;
  value?: string;
  defaultChecked?: boolean;
  onChange?: (isSelected: boolean) => void;
};
export type SelectSelectedProps = ComponentProps<"div">;
export type SelectUnSelectedProps = ComponentProps<"div">;
export type SelectToggleProps = ComponentProps<"div">;
export type SelectLabelProps = ComponentProps<"label">;

export type SelectTriggerProps = ComponentProps<"div">;
export type SelectContentProps = ComponentProps<"div">;

// hook types
// hook types
export type SelectHookTypes = {
  defaultValue?: string;
  onChange?: (value: string) => void;
};

// store types
export type SelectStoreTypes = {
  value: string;
  select: (value: string) => void;
  unselect: () => void;

  isOpen: boolean;
  toggle: () => void;

  selectStores: SelectOptionStoreApiTypes[];
  add: (selectStore: SelectOptionStoreApiTypes) => void;
  refresh: () => void;
};
export type SelectStoreApiTypes = StoreApi<SelectStoreTypes>;
export type SelectStoreSelectorTypes<T> = (state: SelectStoreTypes) => T;

// component types
export type SelectProps = ComponentProps<"div"> & {
  store?: SelectStoreApiTypes;
  name?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
};
