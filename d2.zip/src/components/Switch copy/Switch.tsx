import { createContext, useContext } from "react";
import { create, createStore, useStore } from "zustand";
import { SwitchProps } from "./Switch.types";

type SwitchStoreTypes = {
  isOn: boolean;
  toggle: () => void;
};

// const useSwitch = create<SwitchStoreTypes>((set, get) => ({
//   isOn: false,
//   toggle: () => {
//     set((state) => ({ isOn: !state.isOn }));
//   },
// }));

const SwitchContext = createContext<SwitchStoreTypes | null>(null);

const useSwitch = (selector) => {
  const store = useContext(SwitchContext);

  if (!store) {
    return null;
  }

  return useStore(store, selector);
};

export function Switch(props: SwitchProps) {
  return <div {...props} />;
}

Switch.Provider = (props: SwitchProps) => {
  const store = createStore<SwitchStoreTypes>((set, get) => ({
    isOn: false,
    toggle: () => {
      set((state) => ({ isOn: !state.isOn }));
    },
  }));

  console.log("Provider");

  return (
    <SwitchContext.Provider value={store}>
      {props.children}
    </SwitchContext.Provider>
  );
};

Switch.On = (props: SwitchProps) => {
  const isOn = useSwitch((state) => state.isOn);

  console.log("On");
  if (!isOn) {
    return null;
  }
  return <div {...props} />;
};

Switch.Off = (props: SwitchProps) => {
  const isOn = useSwitch((state) => state.isOn);
  console.log("Off");
  if (isOn) {
    return null;
  }
  return <div {...props} />;
};

Switch.Trigger = (props: SwitchProps) => {
  const toggle = useSwitch((state) => state.toggle);

  console.log("Trigger");
  return <div {...props} onClick={toggle} />;
};
