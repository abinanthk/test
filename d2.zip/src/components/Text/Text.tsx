import React from "react";
import { cn } from "../../utils";
import { TextStyles } from "./Text.styles";
import { TextProps } from "./Text.types";

export function Text({
  variant,
  size,
  color,
  className,
  style,
  ...props
}: TextProps) {
  return (
    <span
      className={cn(TextStyles({ variant, size, className }))}
      style={{ color, ...style }}
      {...props}
    />
  );
}
