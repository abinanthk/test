import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// hook types
export type RadioHookTypes = {
  value?: string;
  isSelected?: boolean;
  onChange?: (isSelected: boolean) => void;
}

// store types
export type RadioStoreTypes = {
  value: string;
  isSelected: boolean;
  select: () => void;
  unselect: () => void;
  toggle: () => void;
};
export type RadioStoreApiTypes = StoreApi<RadioStoreTypes>;
export type RadioStoreSelectorTypes<T> = (state: RadioStoreTypes) => T;

// component types
export type RadioProps = ComponentProps<"div"> & {
  store?: RadioStoreApiTypes;
  name?: string;
  value?: string;
  defaultChecked?: boolean;
  onChange?: (isSelected: boolean) => void;
};
export type RadioSelectedProps = ComponentProps<"div">;
export type RadioUnSelectedProps = ComponentProps<"div">;
export type RadioToggleProps = ComponentProps<"div">;
export type RadioLabelProps = ComponentProps<"label">;


// hook types
// hook types
export type RadioGroupHookTypes = {
  defaultValue?: string;
  onChange?: (value: string) => void;
}

// store types
export type RadioGroupStoreTypes = {
  value: string;
  select: (value: string) => void;
  unselect: () => void;

  radioStores: RadioStoreApiTypes[];
  add: (radioStore: RadioStoreApiTypes) => void;
  refresh: () => void;
};
export type RadioGroupStoreApiTypes = StoreApi<RadioGroupStoreTypes>;

// component types
export type RadioGroupProps = ComponentProps<"div"> & {
  store?: RadioGroupStoreApiTypes;
  name?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
};
