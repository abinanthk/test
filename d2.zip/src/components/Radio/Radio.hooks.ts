import { createContext, useContext, useEffect, useRef } from "react";
import {
  RadioStoreTypes,
  RadioStoreApiTypes,
  RadioStoreSelectorTypes,
  RadioGroupStoreTypes,
  RadioGroupStoreApiTypes,
  RadioHookTypes,
  RadioGroupHookTypes,
} from "./Radio.types";
import { createStore, useStore } from "zustand";

// creates a Radio store | internal & external use
export const useRadio = ({ value, isSelected, onChange }: RadioHookTypes) => {
  const storeRef = useRef<RadioStoreApiTypes>();
  const _groupCtx = useRadioGroupContext();

  if (!storeRef.current) {
    storeRef.current = createStore<RadioStoreTypes>((set, get) => ({
      value: value || "",
      isSelected: isSelected || false,
      select: () => {
        set(() => ({ isSelected: true }));
        onChange?.(get().isSelected);

        // group
        if (!_groupCtx) {
          return;
        }
        _groupCtx.setState({ value: get().value });
        _groupCtx.getState().refresh();
      },
      unselect: () => {
        set(() => ({ isSelected: false }));
        onChange?.(get().isSelected);

        // group
        if (!_groupCtx) {
          return;
        }
        _groupCtx.setState({ value: "" });
        _groupCtx.getState().refresh();
      },
      toggle: () => {
        set((state) => ({ isSelected: !state.isSelected }));
        onChange?.(get().isSelected);

        // group
        if (!_groupCtx) {
          return;
        }
        _groupCtx.setState({ value: get().isSelected ? get().value : "" });
        _groupCtx.getState().refresh();
      },
    }));
    _groupCtx?.getState().add(storeRef.current);
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);

  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const RadioContext = createContext<RadioStoreApiTypes | null>(null);

// use the Radio store in the context (controlled/uncontrolled) | internal use
export const useRadioContext = () => {
  return useContext(RadioContext);
};

// use the Radio store in the context (controlled/uncontrolled) | internal use
export const useRadioStoreInContext = <T>(
  selector: RadioStoreSelectorTypes<T>
) => {
  const store = useContext(RadioContext);
  if (!store) {
    throw new Error("Missing Radio.Provider");
  }

  return useStore(store, selector);
};

export const useRadioGroup = ({
  defaultValue,
  onChange,
}: RadioGroupHookTypes) => {
  const storeRef = useRef<RadioGroupStoreApiTypes>();

  if (!storeRef.current) {
    storeRef.current = createStore<RadioGroupStoreTypes>((set, get) => ({
      value: defaultValue || "",
      radioStores: [],
      add: (radioStore) => {
        set((state) => ({ radioStores: [...state.radioStores, radioStore] }));
        if (radioStore.getState().value === get().value) {
          radioStore.setState({ isSelected: true });
        }
      },
      refresh: () => {
        get().radioStores.map((radioStore) => {
          if (radioStore.getState().value !== get().value) {
            radioStore.setState({ isSelected: false });
          }
        });
        onChange?.(get().value);
      },
      select: (value: string) => {
        set(() => ({ value }));
      },
      unselect: () => {
        set(() => ({ value: "" }));
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const RadioGroupContext = createContext<RadioGroupStoreApiTypes | null>(
  null
);

// use the Radio store in the context (controlled/uncontrolled) | internal use
export const useRadioGroupContext = () => {
  return useContext(RadioGroupContext);
};
