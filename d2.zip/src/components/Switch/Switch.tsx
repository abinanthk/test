import {
  SwitchProps,
  SwitchOnProps,
  SwitchOffProps,
  SwitchTriggerProps,
} from "./Switch.types";
import {
  SwitchContext,
  useSwitch,
  useSwitchStoreInContext,
} from "./Switch.hooks";

// Switch provider for using multiple instance
export function Switch({ store, ...props }: SwitchProps) {
  const _store = useSwitch(store);

  return (
    <SwitchContext.Provider value={_store}>
      <div {...props} />
    </SwitchContext.Provider>
  );
}

Switch.On = (props: SwitchOnProps) => {
  const isOn = useSwitchStoreInContext<boolean>((state) => state.isOn);

  return isOn ? <div {...props} /> : null;
};

Switch.Off = (props: SwitchOffProps) => {
  const isOn = useSwitchStoreInContext<boolean>((state) => state.isOn);

  return isOn ? null : <div {...props} />;
};

Switch.Trigger = (props: SwitchTriggerProps) => {
  const toggle = useSwitchStoreInContext<() => void>((state) => state.toggle);

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};
