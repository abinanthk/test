import { cva } from "class-variance-authority";

export const MenuStyles = cva([""], {
  variants: {},
  defaultVariants: {},
});
