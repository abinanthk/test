import "./App.css";
import Home from "./pages/Home";
import Page1 from "./pages/Page1";
import Page2 from "./pages/Page2";
import Page3 from "./pages/Page3";
import Page4 from "./pages/Page4";
import Page5 from "./pages/Page5";
import Page6 from "./pages/Page6";
import PageCheckBox from "./pages/PageCheckBox";
import PagePopover from "./pages/PagePopover";
import PageRadio from "./pages/PageRadio";
import PageSelect from "./pages/PageSelect";

function App() {
  return (
    // <Home
    //   // color="red"
    // />
    <>
      {/* <Page1/> */}
      {/* <Page2 /> */}
      {/* <Page3 /> */}
      {/* <Page4/> */}
      {/* <Page5/> */}
      {/* <Page6/> */}
      {/* <PagePopover /> */}
      {/* <PageRadio/> */}
      {/* <PageCheckBox /> */}
      <PageSelect/>
    </>
  );
}

export default App;
