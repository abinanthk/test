import { useHistoryPlugin, useHistoryPluginEffect } from './react/react-core/hooks/useHistoryPlugin';
import { useVannilaStore } from './react/react-store';
import { Store, HistoryPlugin } from './vannila'

// const historyPlugin = () => (store: any) => ({ name: 'history', plugin: new HistoryPlugin({ store }) })
const historyPlugin = () => (store: any) => new HistoryPlugin({ store })

const store = new Store<{ count: number; }, {}, { history: HistoryPlugin<{ count: number; }> }>({
  state: {
    count: 0,
    count2: 0,
  },

  plugins: {
    history: historyPlugin()
  }

});


console.log('store : ', store);


function App() {
  const history = store.plugins.history;

  const undos = history.getUndos();
  const redos = history.getRedos();

  useVannilaStore(store)
  useHistoryPlugin(history)
  useHistoryPluginEffect(history, (e) => {
    console.log('effect : ', e);

  })

  console.log('re render');


  const handleClick = () => {
    store.state.count++;
  }

  const handleUndo = () => {
    history.undo();
  }

  const handleRedo = () => {
    history.redo();
  }

  const handleClearHistory = () => {
    history.clear();
  }

  const handlePop = () => {
    history.pop();
  }

  const handleGoBack = () => {
    history.undo(2);
  }

  const handleGoForward = () => {
    history.redo(3);
  }


  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>Current state : {JSON.stringify(store.state)}</div>
      <div>
        <button onClick={handleClick}>click</button>
        <button onClick={handleUndo}>undo</button>
        <button onClick={handleRedo}>redo</button>
        <button onClick={handleClearHistory}>clear history</button>
        <button onClick={handlePop}>pop</button>
        <button onClick={handleGoBack}>undo 3</button>
        <button onClick={handleGoForward}>redo 3</button>
      </div>

      <div style={{ display: 'flex', gap: 20 }}>
        <div>
          <p>--- current ---</p>
          <div>
            {
              JSON.stringify(history.current)
            }
          </div>
        </div>

        <div>
          <p>--- undos ---</p>
          {
            undos.map((undo, index) => {
              return <div key={index}>{JSON.stringify(undo)}</div>
            })
          }
        </div>
        <div>
          <p>--- redos ---</p>
          {
            redos.map((redo, index) => {
              return <div key={index}>{JSON.stringify(redo)}</div>
            })
          }
        </div>
      </div>
    </div>
  )
}

export default App
