import type { IHistoryPlugin, THistoryPluginConfig } from "./types";
import { TDeps } from "../../vannila-store-x";
import { IStore, TSubscription } from "../../vannila-store/types";
import { History } from "../../vannila-utils";

export class HistoryPlugin<TState extends {}>
  extends History<TState>
  implements IHistoryPlugin<TState>
{
  private readonly _store: IStore<TState, any, any>;
  private historySubscription: TSubscription;

  constructor(config: THistoryPluginConfig<TState, any>) {
    super({ ...config.store.state });
    this._store = config.store;

    this.historySubscription = config.store.subscribe((noti: any) => {
      this.push({ [noti.prop]: noti.value } as TState);
    });
  }

  get store() {
    return this._store;
  }

  private update() {
    if (!this.current) {
      return;
    }

    this.historySubscription?.unsubscribe();
    const _deps = Reflect.ownKeys(this.current as object) as TDeps<TState>;

    _deps?.forEach((key) => {
      if (!Reflect.has(this._store.state, key)) {
        return;
      }

      this._store.state[key] = this.current![key];
    });

    this.historySubscription = this._store.subscribe((noti) => {
      this.push({ [noti.prop]: noti.value } as TState);
    });
  }

  pop() {
    super.pop();
    this.update();
  }

  undo(n?: number) {
    super.undo(n);
    this.update();
  }

  redo(n?: number) {
    super.redo(n);
    this.update();
  }
}
