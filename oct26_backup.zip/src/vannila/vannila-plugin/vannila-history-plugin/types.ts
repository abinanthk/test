import { IStore } from "../../vannila-store/types";

export type IHistoryPlugin<TState extends {}> = {
  // getUndoList(): (TState | undefined)[] | undefined;
  // getRedoList(): (TState | undefined)[] | undefined;
  // current: TState | undefined;
  undo(): void;
  redo(): void;
};

export type THistoryPluginConfig<TState extends {}, TReducer extends {}> = {
  store: IStore<TState, TReducer, any>;
};
