import { Subject } from "rxjs";
import type { IHistory } from "./types";
import { HistoryBase } from "./HistoryBase";

export class History<TItem> extends HistoryBase<TItem> implements IHistory {
  private readonly _subject$: Subject<any>;

  constructor(current: TItem) {
    super(current);
    this._subject$ = new Subject();
  }

  private notify() {
    this._subject$.next({
      undos: this.getUndos(),
      redos: this.getRedos(),
      current: this.current,
    });
  }

  push(currItem: TItem) {
    super.push(currItem);
    this.notify();
  }

  pop() {
    super.pop();
    this.notify();
  }

  undo(n?: number) {
    super.undo(n);
    this.notify();
  }

  redo(n?: number) {
    super.redo(n);
    this.notify();
  }

  clear() {
    super.clear();
    this.notify();
  }

  subscribe(listener: (history: any) => void) {
    return this._subject$.subscribe(listener);
  }
}
