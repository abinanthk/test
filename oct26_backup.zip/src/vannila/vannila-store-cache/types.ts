import { TStoreXConfig } from "../vannila-store-x/types";

export type TStoreCacheConfig<
  TState extends {},
  TReducer extends {}
> = TStoreXConfig<TState, TReducer> & {
  key: string;
  cacheTime?: number;
};
