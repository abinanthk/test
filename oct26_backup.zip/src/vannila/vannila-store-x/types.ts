import { TStoreConfig } from "../vannila-store";

export type TDep<T> = keyof T;
export type TDeps<T> = TDep<T>[];
export type TOptions<T> = (options?: TDeps<T>) => void;

export type TStoreXConfig<
  TState extends {},
  TReducer extends {}
> = TStoreConfig<TState, TReducer, any> & {
  onLoad?: (state: TState) => void;
  onSave?: (state: TState) => void;
  initTime?: number;
  staleTime?: number;
};

export type IStoreX<TState extends {}, TReducer extends {}> = {
  getConfig: () => TStoreXConfig<TState, TReducer>;
  reset: TOptions<TState>;
  load: () => void;
  save: () => void;
  unsubscribe: () => void;
};
