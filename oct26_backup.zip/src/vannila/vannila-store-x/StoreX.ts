import { Observable, timer } from "rxjs";
import { Store, TSubscription } from "../vannila-store";
import { TListener } from "../vannila-store/types";
import type { IStoreX, TStoreXConfig } from "./types";

const DEFAULT_STORE_CONFIG = {
  initTime: 0,
  staleTime: 60000,
};

export class StoreX<TState extends {}, TReducer extends {}>
  extends Store<TState, TReducer, any>
  implements IStoreX<TState, TReducer>
{
  private readonly _configX: TStoreXConfig<TState, TReducer>;
  private _staleTimer$: Observable<number>;
  private _subscription: TSubscription;

  constructor({
    initTime = DEFAULT_STORE_CONFIG.initTime,
    staleTime = DEFAULT_STORE_CONFIG.staleTime,
    onLoad,
    onSave,
    ...config
  }: TStoreXConfig<TState, TReducer>) {
    super(config);

    this._configX = {
      onLoad,
      onSave,
      ...config,
    };

    this._staleTimer$ = timer(initTime, staleTime);
  }

  init() {
    if (this._subscription && !this._subscription.closed) {
      return;
    }

    this._subscription = this._staleTimer$.subscribe(() => {
      if (this.isObserved) {
        this._configX.onLoad?.(this.state);
        return;
      }
      this._subscription?.unsubscribe();
    });
  }

  unsubscribe() {
    if (this.isObserved) {
      return;
    }

    this._subscription?.unsubscribe();
  }

  subscribe(listener?: TListener<TState>) {
    const subscription = super.subscribe(listener);
    this.init();
    return subscription;
  }

  getConfig() {
    return { ...this._configX };
  }

  load() {
    this._configX.onLoad?.(this.state);
  }

  save() {
    this._configX.onSave?.(this.state);
  }
}
