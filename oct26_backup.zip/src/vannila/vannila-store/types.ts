import { Subscription } from "rxjs";
import { TNoti } from "../vannila-core/types";

export type TListener<TState> = (noti: TNoti<TState>) => void;
export type TSubscribe<T> = (listener?: TListener<T>) => TSubscription;

export type TSubscription = Subscription | undefined;

export type IStore<
  TState extends {},
  TReducer extends {},
  TPlugins extends {}
> = {
  config: TStoreConfig<TState, TReducer, TPlugins>;
  state: TState;
  reducer: TReducer;
  isObserved: boolean;
  subscribe: TSubscribe<TState>;
};

export type TStoreConfig<
  TState extends {},
  TReducer extends {},
  TPlugins extends {}
> = {
  name?: string;
  state: TState;
  reducer?: (state: TState) => TReducer;
  effect?: (
    store?: IStore<TState, TReducer, TPlugins>,
    noti?: TNoti<TState>
  ) => void;
  plugins?: object;
};

export type IState<TState extends {}> = {
  state: TState;
  subscribe: TSubscribe<TState>;
};
