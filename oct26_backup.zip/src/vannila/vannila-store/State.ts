import { Subject } from "rxjs";
import { proxy } from "../vannila-core";
import type { TNoti } from "../vannila-core/types";
import type { IState, TListener } from "./types";

export class State<TState extends {}> implements IState<TState> {
  private readonly _subject$: Subject<TNoti<TState>>;
  private readonly _state: TState;

  constructor(state: TState) {
    this._subject$ = new Subject<TNoti<TState>>();

    this._state = proxy({ ...state }, (noti) => {
      this._subject$.next(noti);
    });
  }

  get state() {
    return this._state;
  }

  get isObserved() {
    return this._subject$.observed;
  }

  subscribe(listener?: TListener<TState>) {
    return this._subject$.subscribe(listener);
  }
}
