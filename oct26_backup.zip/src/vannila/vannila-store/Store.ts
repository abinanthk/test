import type { IStore, TStoreConfig } from "./types";
import { TDeps } from "../vannila-store-x";
import { State } from "./State";

export class Store<TState extends {}, TReducer extends {}, TPlugins extends {}>
  extends State<TState>
  implements IStore<TState, TReducer, TPlugins>
{
  private readonly _config: TStoreConfig<TState, TReducer, TPlugins>;
  private readonly _reducer: TReducer;
  private readonly _plugins: TPlugins;

  constructor(config: TStoreConfig<TState, TReducer, TPlugins>) {
    super({ ...config.state });
    this._config = config;

    this._reducer = config?.reducer
      ? config?.reducer(this.state)
      : ({} as TReducer);

    const plugins: any = {};
    if (config.plugins) {
      Object.entries(config.plugins).map<any>(([key, value]) => {
        plugins[key] = value(this);
      });
    }
    this._plugins = plugins;
  }

  get config() {
    return this._config;
  }

  get reducer() {
    return this._reducer;
  }

  get plugins() {
    return this._plugins;
  }

  reset(deps?: TDeps<TState>) {
    const _deps =
      deps || (Reflect.ownKeys(this._config.state as object) as TDeps<TState>);

    _deps?.forEach((key) => {
      if (!Reflect.has(this._config.state, key)) {
        return;
      }

      this.state[key] = this._config.state[key];
    });
  }
}
