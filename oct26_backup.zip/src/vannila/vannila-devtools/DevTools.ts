import { Subject } from "rxjs";
import { IStore, TSubscription } from "../vannila-store";
import { StoreHistory } from "../vannila-plugin/vannila-history-plugin";

export class DevTools {
  private static _subject$: Subject<any> = new Subject();
  private static _subscriptions: TSubscription[] = [];
  private static _map = new Map();
  private static _history = new Map();

  static getAllHistory() {
    return DevTools._history.entries();
  }

  static getAllStore() {
    return DevTools._map.entries();
  }

  static getStore(key: string) {
    return DevTools._map.get(key);
  }

  static register<TState extends {}, TReducer extends {}>(
    store: IStore<TState, TReducer>
  ) {
    console.log("register store : ", store.config.name);

    if (!store.config.name) {
      return;
    }

    DevTools._map.set(store.config.name, store);

    DevTools._history.set(store.config.name, new StoreHistory({store}))

    const subscription = store.subscribe((noti) => {
      console.log("register store subscribe : ", noti);

      DevTools._subject$.next({ store, noti });
    });

    DevTools._subscriptions.push(subscription);
  }

  static subscribe(listener: (action: any) => void) {
    return DevTools._subject$.subscribe(listener);
  }

  static destroy() {
    DevTools._subscriptions.forEach((subscription) => {
      subscription?.unsubscribe();
    });
  }
}
