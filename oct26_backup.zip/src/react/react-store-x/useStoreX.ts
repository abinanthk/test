import { StoreX } from "../../../vannila";
import type { TDeps, TStoreXConfig } from "../../../vannila";
import { useSingleton } from "../react-utils";
import { useVannilaStoreX } from "./useVannilaStoreX";

export const useStoreX = <TState extends {}, TReducer extends {}>(
  config: TStoreXConfig<TState, TReducer>,
  deps?: TDeps<TState>
) => {
  const storeX = useSingleton<StoreX<TState, TReducer>>(
    () => new StoreX<TState, TReducer>(config)
  );

  return useVannilaStoreX<TState, TReducer>(storeX, deps);
};
