import { Store, TDeps, TStoreConfig } from "../../vannila";
import { useVannilaStore } from "./useVannilaStore";

export const createStore = <TState extends {}, TReducer extends {}, TPlugins extends {}>(
  config: TStoreConfig<TState, TReducer, TPlugins>
) => {
  const store = new Store(config);

  const hook = (deps?: TDeps<TState>) =>
    useVannilaStore<TState, TReducer, TPlugins>(store, deps);

  hook.store = store;

  return hook;
};
