import { Store, TStoreConfig } from "../../vannila";
import { useSingleton } from "../react-utils";
import { useVannilaStore } from "./useVannilaStore";

export const useStore = <TState extends {}, TReducer extends {}, TPlugins extends {}>(
  config: TStoreConfig<TState, TReducer, TPlugins>,
  deps?: TDeps<TState>
) => {
  const store = useSingleton(() => new Store<TState, TReducer, TPlugins>(config));

  return useVannilaStore<TState, TReducer, TPlugins>(store, deps);
};
