import { Store } from "../../vannila";
import { TDeps } from "../../vannila";
import { useSubscription } from "../react-core";

export const useVannilaStore = <
  TState extends {},
  TReducer extends {},
  TPlugins extends {}
>(
  store: Store<TState, TReducer, TPlugins>,
  deps?: TDeps<TState>
) => {
  useSubscription<TState, Store<TState, TReducer, TPlugins>>(store, deps);
  return store;
};
