import { useEffect } from "react";
import { TNoti } from "../../../../vannila/src/vannila-core/types";
import { TDeps } from "../../../../vannila";
import { TTargetBase } from "./types";

export const useSubscriptionEffect = <
  TState,
  TTarget extends TTargetBase<TState>
>(
  target: TTarget,
  effect?: (noti: TNoti<TState>) => void,
  deps?: TDeps<TState>
) => {
  useEffect(() => {
    const _deps =
      deps || (Reflect.ownKeys(target.state as object) as TDeps<TState>);

    const subscription = target.subscribe((noti: TNoti<TState>) => {
      if (_deps?.includes(noti.prop)) {
        effect?.(noti);
      }
    });

    return () => {
      subscription?.unsubscribe();
    };
  }, []);
};
