import { useEffect } from "react";
import { DevTools } from "../../../vannila";
import { createStore } from "../react-store";

const useActionStore = createStore({
  state: {
    action: {
      noti: {
        prop: "",
        prevValue: null,
        target: null,
      },
      store: null,
    },
  },
});

export const useDevToolsActions = () => {
  const actionStore = useActionStore();

  useEffect(() => {
    const subscription = DevTools.subscribe((e) => {
      actionStore.state.action = e;
    });

    return () => subscription.unsubscribe();
  }, []);

  return actionStore.state.action;
};
