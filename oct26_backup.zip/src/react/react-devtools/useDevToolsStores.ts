import { useEffect } from "react";
import { DevTools } from "../../../vannila";
import { createStore } from "../react-store";

const useStoresStore = createStore({
  state: {
    stores: [],
  },
});

export const useDevToolsStores = () => {
  const storesStore = useStoresStore();

  useEffect(() => {
    const subscription = DevTools.subscribe((e) => {
      const allStore = DevTools.getAllStore();
      storesStore.state.stores = Array.from(
        allStore,
        ([name, value]) => value
      ) as any;
    });

    return () => subscription.unsubscribe();
  }, []);

  return storesStore.state.stores;
};
