import { useEffect } from "react";
import { DevTools, IStore, StoreHistory } from "../../../vannila";
import { createStore } from "../react-store";

const useHistoryStore = createStore({
  state: {
    history: [],
  },
});

export const useDevToolsHistory = () => {
  const historyStore = useHistoryStore();

  useEffect(() => {
    const subscription = DevTools.subscribe((e) => {
      const allHistory = DevTools.getAllHistory();

      historyStore.state.history = Array.from(
        allHistory,
        ([name, value]) => value
      ) as any;
    });

    return () => subscription.unsubscribe();
  }, []);

  return historyStore.state.history;
};
