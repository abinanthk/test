import { Timeout } from "../vannila-timeout";
import { Interval } from "../vannila-interval";

export type TCacheItem<T> = {
  createItem: () => T;
  item: T;
  timeout: Timeout;
  interval: Interval;
};

export interface ICache<K, V> {
  size: number;
  set: (key: K, createItem: () => V, force?: boolean) => boolean;
  get: (key: K) => V | undefined;
  remove: (key: K) => void;
  has: (key: K) => boolean;
  clear: () => void;
}
