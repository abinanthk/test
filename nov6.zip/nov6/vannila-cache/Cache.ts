import type { ICache, TCacheItem } from "./types";
import { Timeout } from "../vannila-timeout";
import { Interval } from "../vannila-interval";

const DEFAULT_CACHE_MAX_SIZE = 50;

export class Cache<K, V> implements ICache<K, V> {
  private readonly _cache: Map<K, TCacheItem<V>>;
  private readonly _maxSize: number;

  constructor(maxSize: number = DEFAULT_CACHE_MAX_SIZE) {
    this._cache = new Map<K, TCacheItem<V>>();
    this._maxSize = maxSize;
  }

  set(key: K, createItem: () => V, force: boolean = false) {
    // if (this._cache.size >= this._maxSize) {
    //   console.warn("Cache is full.");
    //   return false;
    // }

    if (!force && this._cache.has(key)) {
      return false;
    }

    this._cache.set(key, {
      createItem,
      item: createItem(),
      timeout: new Timeout(),
      interval: new Interval(),
    });

    return true;
  }

  get(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    if (!cacheItem.item) {
      cacheItem.item = cacheItem.createItem();
    }

    return cacheItem.item;
  }

  remove(key: K) {
    return this._cache.delete(key);
  }

  has(key: K) {
    return this._cache.has(key);
  }

  get size() {
    return this._cache.size;
  }

  clear() {
    this._cache.clear();
  }

  setTimeout(key: K, callback: () => void, timeout: number) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    cacheItem.timeout.set(callback, timeout);
  }

  clearTimeout(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    cacheItem.timeout.clear();
  }

  setInterval(key: K, callback: () => void, timeout: number) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    cacheItem.interval.set(callback, timeout);
  }

  clearInterval(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    cacheItem.interval.clear();
  }
}
