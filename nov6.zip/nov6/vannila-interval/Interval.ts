import type { ITimer } from "./types";

export class Interval implements ITimer {
  private _id: number = -1;
  constructor() {}

  set(callback: () => void, timeout: number): void {
    if (this._id !== -1) {
      clearInterval(this._id);
    }
    this._id = setInterval(callback, timeout);
  }

  clear(): void {
    clearInterval(this._id);
    this._id = -1;
  }
}
