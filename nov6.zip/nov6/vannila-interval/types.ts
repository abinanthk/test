export interface ITimer {
  set(callback: () => void, timeout: number): void;
  clear(): void;
}
