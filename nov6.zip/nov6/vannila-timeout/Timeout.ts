import type { ITimer } from "./types";

export class Timeout implements ITimer {
  private _id: number = -1;
  constructor() {}

  set(callback: () => void, timeout: number): void {
    if (this._id !== -1) {
      clearTimeout(this._id);
    }
    this._id = setTimeout(callback, timeout);
  }

  clear(): void {
    clearTimeout(this._id);
    this._id = -1;
  }
}
