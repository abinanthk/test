import { ReactElement, ComponentProps } from "react";

import {
  Accordian as _Accordian,
  AccordianProps as _AccordianProps,
} from "../../components/Accordian";

type AccordianProps = _AccordianProps & {
  summary?: string;
  details?: string;
  expandIcon?: ReactElement;
};

export const Accordian = ({
  summary,
  details,
  expandIcon,
  ...props
}: AccordianProps) => {
  return (
    <_Accordian {...props} className="bg-accordian rounded-sm cursor-pointer animate-fromTop">
      <_Accordian.Summary className="flex items-center justify-between gap-2 p-2 animate-fromTop">
        <_Accordian.Text className="text-white">{summary}</_Accordian.Text>
        <_Accordian.Opened className="flex items-center justify-center text-white">
          {expandIcon}
        </_Accordian.Opened>
        <_Accordian.Closed className="flex items-center justify-center text-white rotate-180">
          {expandIcon}
        </_Accordian.Closed>
      </_Accordian.Summary>
      <_Accordian.Details className="p-2 mb-3 animate-fromTop" style={{transitionDuration: '222ms'}}>
        <_Accordian.Text className="text-white">{details}</_Accordian.Text>
      </_Accordian.Details>
    </_Accordian>
  );
};
