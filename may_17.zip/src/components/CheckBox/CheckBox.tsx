import {
  CheckBoxProps,
  CheckBoxSelectedProps,
  CheckBoxUnSelectedProps,
  CheckBoxToggleProps,
  CheckBoxLabelProps,
  CheckBoxGroupProps,
} from "./CheckBox.types";
import {
  CheckBoxContext,
  useCheckBox,
  useCheckBoxStoreInContext,
  CheckBoxGroupContext,
  useCheckBoxGroup,
} from "./CheckBox.hooks";

// CheckBox provider for using multiple instance
export function CheckBox({
  defaultChecked,
  value,
  onChange,
  ...props
}: CheckBoxProps) {
  const checkBoxStore = useCheckBox({
    isSelected: defaultChecked,
    value,
    onChange: onChange,
  });

  return (
    <CheckBoxContext.Provider value={checkBoxStore}>
      <div {...props} />
    </CheckBoxContext.Provider>
  );
}

CheckBox.Selected = (props: CheckBoxSelectedProps) => {
  const isSelected = useCheckBoxStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? <div {...props} /> : null;
};

CheckBox.UnSelected = (props: CheckBoxUnSelectedProps) => {
  const isSelected = useCheckBoxStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? null : <div {...props} />;
};

CheckBox.Toggle = (props: CheckBoxToggleProps) => {
  const toggle = useCheckBoxStoreInContext<() => void>((state) => state.toggle);

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

CheckBox.Label = (props: CheckBoxLabelProps) => {
  return <label {...props} />;
};

CheckBox.Group = ({ defaultValue, onChange, ...props }: CheckBoxGroupProps) => {
  const checkBoxGroupStore = useCheckBoxGroup({
    defaultValue,
    onChange: onChange,
  });
  return (
    <CheckBoxGroupContext.Provider value={checkBoxGroupStore}>
      <div {...props} />
    </CheckBoxGroupContext.Provider>
  );
};
