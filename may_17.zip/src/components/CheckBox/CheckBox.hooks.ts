import { createContext, useContext, useEffect, useRef } from "react";
import {
  CheckBoxStoreTypes,
  CheckBoxStoreApiTypes,
  CheckBoxStoreSelectorTypes,
  CheckBoxGroupStoreTypes,
  CheckBoxGroupStoreApiTypes,
  CheckBoxHookTypes,
  CheckBoxGroupHookTypes,
} from "./CheckBox.types";
import { createStore, useStore } from "zustand";

// creates a CheckBox store | internal & external use
export const useCheckBox = ({
  value,
  isSelected,
  onChange,
}: CheckBoxHookTypes) => {
  const storeRef = useRef<CheckBoxStoreApiTypes>();
  const _groupCtx = useCheckBoxGroupContext();

  if (!storeRef.current) {
    storeRef.current = createStore<CheckBoxStoreTypes>((set, get) => ({
      value: value || "",
      isSelected: isSelected || false,
      select: () => {
        set(() => ({ isSelected: true }));
        onChange?.(get().isSelected);

        // group
        if (!_groupCtx) {
          return;
        }
        _groupCtx.setState((state) => ({
          value: [...state.value, get().value],
        }));
        _groupCtx.getState().refresh();
      },
      unselect: () => {
        set(() => ({ isSelected: false }));
        onChange?.(get().isSelected);

        // group
        if (!_groupCtx) {
          return;
        }

        _groupCtx.setState((state) => ({
          value: state.value.filter((val) => val !== get().value),
        }));
        _groupCtx.getState().refresh();
      },
      toggle: () => {
        set((state) => ({ isSelected: !state.isSelected }));
        onChange?.(get().isSelected);

        // group
        if (!_groupCtx) {
          return;
        }

        _groupCtx.setState((state) => ({
          value: get().isSelected
            ? [...state.value, get().value]
            : state.value.filter((val) => val !== get().value),
        }));
        _groupCtx.getState().refresh();
      },
    }));
    _groupCtx?.getState().add(storeRef.current);
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);

  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const CheckBoxContext = createContext<CheckBoxStoreApiTypes | null>(
  null
);

// use the CheckBox store in the context (controlled/uncontrolled) | internal use
export const useCheckBoxContext = () => {
  return useContext(CheckBoxContext);
};

// use the CheckBox store in the context (controlled/uncontrolled) | internal use
export const useCheckBoxStoreInContext = <T>(
  selector: CheckBoxStoreSelectorTypes<T>
) => {
  const store = useContext(CheckBoxContext);
  if (!store) {
    throw new Error("Missing CheckBox.Provider");
  }

  return useStore(store, selector);
};

export const useCheckBoxGroup = ({
  defaultValue,
  onChange,
}: CheckBoxGroupHookTypes) => {
  const storeRef = useRef<CheckBoxGroupStoreApiTypes>();

  if (!storeRef.current) {
    storeRef.current = createStore<CheckBoxGroupStoreTypes>((set, get) => ({
      value: defaultValue || [],
      checkBoxStores: [],
      add: (checkBoxStore) => {
        set((state) => ({
          checkBoxStores: [...state.checkBoxStores, checkBoxStore],
        }));
        if (get().value.includes(checkBoxStore.getState().value)) {
          checkBoxStore.setState({ isSelected: true });
        }
      },
      refresh: () => {
        get().checkBoxStores.map((checkBoxStore) => {
          if (!get().value.includes(checkBoxStore.getState().value)) {
            checkBoxStore.setState({ isSelected: false });
          }
        });
        onChange?.(get().value);
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const CheckBoxGroupContext =
  createContext<CheckBoxGroupStoreApiTypes | null>(null);

// use the CheckBox store in the context (controlled/uncontrolled) | internal use
export const useCheckBoxGroupContext = () => {
  return useContext(CheckBoxGroupContext);
};
