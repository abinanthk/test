export { Text } from "./Text";
export type { TextProps } from "./Text.types";
