import { createContext, useContext, useEffect, useRef } from "react";
import { createStore, useStore } from "zustand";
import type {
  AccordianStoreTypes,
  AccordianStoreApiTypes,
  AccordianHookTypes,
  AccordianStoreAccordianorTypes,
} from "./Accordian.types";

export const useAccordian = ({
  defaultOpen,
  onChange,
}: AccordianHookTypes) => {
  const storeRef = useRef<AccordianStoreApiTypes>();

  if (!storeRef.current) {
    storeRef.current = createStore<AccordianStoreTypes>()((set, get) => ({
      isOpen: defaultOpen || false,
      open: () => {
        set({ isOpen: true });
        onChange?.(get().isOpen);
      },
      close: () => {
        set({ isOpen: false });
        onChange?.(get().isOpen);
      },
      toggle: () => {
        set((state) => ({ isOpen: !state.isOpen }));
        onChange?.(get().isOpen);
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);

  return storeRef.current;
};

export const AccordianContext = createContext<AccordianStoreApiTypes | null>(
  null
);

export const useAccordianContext = () => {
  return useContext(AccordianContext);
};

export const useAccordianStoreInContext = <T>(
  Accordianor: AccordianStoreAccordianorTypes<T>
) => {
  const store = useContext(AccordianContext);
  if (!store) {
    throw new Error("Missing Accordian.Provider");
  }

  return useStore(store, Accordianor);
};
