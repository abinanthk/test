import {
  AccordianProps,
  AccordianSummaryProps,
  AccordianDetailsProps,
  AccordianOpenedProps,
  AccordianClosedProps,
} from "./Accordian.types";
import {
  AccordianContext,
  useAccordian,
  useAccordianStoreInContext,
} from "./Accordian.hooks";
import { Text } from "..";

export function Accordian({
  defaultOpen,
  onChange,
  ...props
}: AccordianProps) {
  const _store = useAccordian({
    defaultOpen,
    onChange,
  });
  return (
    <AccordianContext.Provider value={_store}>
      <div {...props} />
    </AccordianContext.Provider>
  );
}

Accordian.Summary = (props: AccordianSummaryProps) => {
  const toggle = useAccordianStoreInContext((state) => state.toggle);

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

Accordian.Details = (props: AccordianDetailsProps) => {
  const isOpen = useAccordianStoreInContext((state) => state.isOpen);

  return isOpen ? <div {...props} /> : null;
};

Accordian.Opened = (props: AccordianOpenedProps) => {
  const isOpen = useAccordianStoreInContext((state) => state.isOpen);

  return isOpen ? <div {...props} /> : null;
};
Accordian.Closed = (props: AccordianClosedProps) => {
  const isOpen = useAccordianStoreInContext((state) => state.isOpen);

  return isOpen ? null : <div {...props} />;
};

Accordian.Text = Text;
