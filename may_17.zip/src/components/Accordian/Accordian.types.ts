import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// hook types
export type AccordianHookTypes = {
  defaultOpen?: boolean;
  onChange?: (value: boolean) => void;
};

// store types
export type AccordianStoreTypes = {
  isOpen: boolean;
  open: () => void;
  close: () => void;
  toggle: () => void;
};
export type AccordianStoreApiTypes = StoreApi<AccordianStoreTypes>;
export type AccordianStoreAccordianorTypes<T> = (
  state: AccordianStoreTypes
) => T;

// component types
export type AccordianProps = ComponentProps<"div"> & {
  store?: AccordianStoreApiTypes;
  name?: string;
  defaultOpen?: boolean;
  onChange?: (value: boolean) => void;
};

export type AccordianDetailsProps = ComponentProps<"div">;
export type AccordianSummaryProps = ComponentProps<"div">;
export type AccordianOpenedProps = ComponentProps<"div">;
export type AccordianClosedProps = ComponentProps<"div">;
