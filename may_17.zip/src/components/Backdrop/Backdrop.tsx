import { ComponentProps } from "react";

const Backdrop = (props: ComponentProps<"div">) => {
  return (
    <div
      {...props}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        height: "100%",
        width: "100%",
      }}
    />
  );
};

export default Backdrop;
