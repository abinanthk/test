import { ComponentProps } from "react";

export type ContainerProps = ComponentProps<"div">;
