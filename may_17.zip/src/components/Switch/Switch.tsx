import {
  SwitchProps,
  SwitchOnProps,
  SwitchOffProps,
  SwitchTriggerProps,
} from "./Switch.types";
import {
  SwitchContext,
  useSwitch,
  useSwitchStoreInContext,
} from "./Switch.hooks";

import {
  useTransition,
  animated,
  AnimatedProps,
  useSpringRef,
} from "@react-spring/web";

// Switch provider for using multiple instance
export function Switch({ store, ...props }: SwitchProps) {
  const _store = useSwitch(store);

  return (
    <SwitchContext.Provider value={_store}>
      <div {...props} />
    </SwitchContext.Provider>
  );
}

Switch.On = (props: SwitchOnProps) => {
  const isOn = useSwitchStoreInContext<boolean>((state) => state.isOn);

  return isOn ? <div {...props} /> : null;
};

Switch.Off = (props: SwitchOffProps) => {
  const isOn = useSwitchStoreInContext<boolean>((state) => state.isOn);

  return isOn ? null : <div {...props} />;
};

Switch.Trigger = (props: SwitchTriggerProps) => {
  const toggle = useSwitchStoreInContext<() => void>((state) => state.toggle);

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

Switch.AnimatedOn = (props: any) => {
  const isOn = useSwitchStoreInContext<boolean>((state) => state.isOn);
  const transitions = useTransition(isOn, {
    from: { transform: "translateX(0%)" },
    enter: { transform: "translateX(100%)" },
  });
  return isOn
    ? transitions((style) => <animated.div style={style} {...props} />)
    : null;
};

Switch.AnimatedOff = (props: any) => {
  const isOn = useSwitchStoreInContext<boolean>((state) => state.isOn);
  const transitions = useTransition(isOn, {
    from: { transform: "translateX(100%)" },
    enter: { transform: "translateX(0%)" },
  });
  return isOn
    ? null
    : transitions((style) => <animated.div style={style} {...props} />);
};
