import { createContext, useContext, useEffect, useRef } from "react";
import {
  SwitchStoreTypes,
  SwitchStoreApiTypes,
  SwitchStoreSelectorTypes,
} from "./Switch.types";
import { createStore, useStore } from "zustand";

// creates a switch store | internal & external use
export const useSwitch = (store?: any) => {
  const storeRef = useRef<SwitchStoreApiTypes>(store);

  if (!storeRef.current) {
    storeRef.current = createStore<SwitchStoreTypes>((set) => ({
      isOn: false,
      on: () => {
        set(() => ({ isOn: true }));
      },
      off: () => {
        set(() => ({ isOn: false }));
      },
      toggle: () => {
        set((state) => ({ isOn: !state.isOn }));
      },
    }));
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
  }, []);
  return storeRef.current;
};

// use the switch store (controlled/uncontrolled) | external use
export const useSwitchStore = <T>(
  store: SwitchStoreApiTypes,
  selector: SwitchStoreSelectorTypes<T>
) => {
  return useStore(store, selector);
};

// context to avoid prop drilling | internal use
export const SwitchContext = createContext<SwitchStoreApiTypes | null>(null);

// use the switch store in the context (controlled/uncontrolled) | internal use
export const useSwitchStoreInContext = <T>(
  selector: SwitchStoreSelectorTypes<T>
) => {
  const store = useContext(SwitchContext);
  if (!store) {
    throw new Error("Missing Switch.Provider");
  }

  return useStore(store, selector);
};
