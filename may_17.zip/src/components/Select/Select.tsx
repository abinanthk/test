import {
  SelectProps,
  SelectSelectedProps,
  SelectUnSelectedProps,
  SelectToggleProps,
  SelectLabelProps,
  SelectOptionProps,
  SelectTriggerProps,
  SelectContentProps,
} from "./Select.types";
import {
  SelectContext,
  useSelect,
  useSelectOptionStoreInContext,
  SelectOptionContext,
  useSelectOption,
  useSelectStoreInContext,
} from "./Select.hooks";
import { useEffect, useState } from "react";

import { Portal } from "../Portal";
import { Backdrop } from "../Backdrop";

// Select provider for using multiple instance
export function Select({ defaultValue, onChange, ...props }: SelectProps) {
  const _store = useSelect({
    defaultValue,
    onChange: onChange,
  });
  return (
    <SelectContext.Provider value={_store}>
      <div {...props} />
    </SelectContext.Provider>
  );
}

Select.Option = ({
  defaultChecked,
  value,
  onChange,
  ...props
}: SelectOptionProps) => {
  const _store = useSelectOption({
    isSelected: defaultChecked,
    value,
    onChange: onChange,
  });

  return (
    <SelectOptionContext.Provider value={_store}>
      <div {...props} />
    </SelectOptionContext.Provider>
  );
};

Select.Selected = (props: SelectSelectedProps) => {
  const isSelected = useSelectOptionStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? <div {...props} /> : null;
};

Select.UnSelected = (props: SelectUnSelectedProps) => {
  const isSelected = useSelectOptionStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? null : <div {...props} />;
};

Select.Toggle = (props: SelectToggleProps) => {
  const toggle = useSelectOptionStoreInContext<() => void>(
    (state) => state.toggle
  );

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

Select.Label = (props: SelectLabelProps) => {
  return <label {...props} />;
};

Select.Value = () => {
  const value = useSelectStoreInContext((state) => state.value);
  return value;
};

Select.Placeholder = (props: SelectLabelProps) => {
  const value = useSelectStoreInContext((state) => state.value);
  return value ? null : <span {...props} />;
};

// /////////////////
Select.Trigger = (props: SelectTriggerProps) => {
  const toggle = useSelectStoreInContext((state) => state.toggle);
  const _ref = useSelectStoreInContext<any>((state) => state._ref);

  return (
    <div
      {...props}
      ref={_ref}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

Select.Content = (props: SelectContentProps) => {
  const isOpen = useSelectStoreInContext((state) => state.isOpen);
  const close = useSelectStoreInContext((state) => state.close);
  const _ref = useSelectStoreInContext((state) => state._ref);

  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!_ref || !_ref.current) {
      return;
    }

    setPos({
      x: _ref.current.getBoundingClientRect().x,
      y:
        _ref.current.getBoundingClientRect().y +
        _ref.current.getBoundingClientRect().height +
        1,
    });
  }, []);

  return isOpen ? (
    <Portal>
      <Backdrop onClick={close} />
      <div
        {...props}
        style={{ position: "absolute", top: pos.y, left: pos.x }}
      />
    </Portal>
  ) : null;
};
