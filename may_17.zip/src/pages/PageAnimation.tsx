import React, { useState, CSSProperties, useEffect } from "react";
import {
  useTransition,
  animated,
  AnimatedProps,
  useSpringRef,
} from "@react-spring/web";
import { Switch } from "../components/Switch";

const pages: ((
  props: AnimatedProps<{ style: CSSProperties }>
) => React.ReactElement)[] = [
  ({ style }) => (
    <animated.div style={{ ...style, background: "lightpink" }}>A</animated.div>
  ),
  ({ style }) => (
    <animated.div style={{ ...style, background: "lightblue" }}>B</animated.div>
  ),
  ({ style }) => (
    <animated.div style={{ ...style, background: "lightgreen" }}>
      C
    </animated.div>
  ),
];

export default function PageAnimation() {
  return (
    <Switch
      className={`flex items-center bg-slate-300 m-10 h-[10px] w-[40px] rounded-md`}
    >
      <Switch.Trigger>
        <Switch.AnimatedOn className="h-[20px] w-[20px] rounded-full bg-green-600" />
        <Switch.AnimatedOff className="h-[20px] w-[20px] rounded-full bg-red-600" />
      </Switch.Trigger>
    </Switch>
  );
}
