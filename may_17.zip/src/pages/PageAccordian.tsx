import { Accordian } from "../components/Accordian";

type Props = {};

const PageAccordian = (props: Props) => {
  return (
    <div className="m-5">
      <Accordian
        onChange={(value) => {
          console.log("Accordian value", value);
        }}
        className="bg-slate-600"
      >
        <Accordian.Summary className="mt-12  flex gap-2">
          <Accordian.Text>Accordian Summary</Accordian.Text>
          <Accordian.Opened>{"<"}</Accordian.Opened>
          <Accordian.Closed>{">"}</Accordian.Closed>
        </Accordian.Summary>

        <Accordian.Details>
          <Accordian.Text>Accordian Details</Accordian.Text>
        </Accordian.Details>
      </Accordian>

      <Accordian
        defaultOpen={true}
        onChange={(value) => {
          console.log("Accordian value", value);
        }}
      >
        <Accordian.Summary className="mt-12 bg-blue-400 flex gap-2">
          <Accordian.Text>Accordian Summary</Accordian.Text>
          <Accordian.Opened>Opened</Accordian.Opened>
          <Accordian.Closed>Closed</Accordian.Closed>
        </Accordian.Summary>

        <Accordian.Details>
          <Accordian.Text>Accordian Details</Accordian.Text>
        </Accordian.Details>
      </Accordian>
    </div>
  );
};

export default PageAccordian;
