import React, {
  useState,
  ComponentProps,
  createContext,
  useContext,
} from "react";
import { createPortal } from "react-dom";
import { FaBeer } from "react-icons/fa";
import {
  Button,
  ButtonGroup,
  Card,
  Divider,
  Grid,
  Input,
  Label,
  List,
  Select,
  Stack,
  Text,
} from "../components";
import { LuLoader2 } from "react-icons/lu";
import { cn } from "../utils";
import { Component } from "../componen ts/Semantic/Semantic";

const ParentCtx = createContext<any>(null);

const Group = ({ ...props }: ComponentProps<"div">) => {
  const newChildren = React.Children.map(props.children, (child) => {
    // console.log(child);
    return React.cloneElement(child, {
      ...props,
      ...child.props,
      className: cn(props.className, child.props.className),
    });
  });

  return <>{newChildren}</>;
};

const Parent = ({ children, ...props }: ComponentProps<"div">) => {
  // const newChildren = children;

  console.log("children", children);

  const newChildren1 = children?.map((child) => {
    console.log("child", child);

    return { ...child, className: "text-black" };
  });

  // const newChildren = React.Children.map(children, (child) => {
  //   // console.log(child);
  //   return React.cloneElement(child, {
  //     ...props,
  //     ...child.props,
  //   });
  // });

  // console.log(newChildren);
  console.log("newChildren1", newChildren1);

  return (
    <ParentCtx.Provider value={{ data: "hey", ...props }}>
      <div {...props} className={cn("h-52 bg-zinc-100", props.className)}>
        {newChildren1}
      </div>
    </ParentCtx.Provider>
  );
};

Parent.Group = Group;

const Child = ({ ...props }: ComponentProps<"div">) => {
  const ctx = useContext(ParentCtx);

  console.log("from child", ctx);

  return <div {...props} className={cn(props.className)} />;
};

const Page1 = () => {
  // return (
  //   <>
  //     {createPortal(
  //       <p>This child is placed in the document body.</p>,
  //       document.body
  //     )}
  //     <Parent name="parent1" className="text-white">
  //       <Child className="inline-flex items-center p-5 h-[50px] text-yellow-900 bg-red-300">
  //         box-1
  //       </Child>
  //       <Child className="inline-flex items-center p-5 h-[50px]  bg-green-300">
  //         box-2
  //       </Child>
  //       <Child className="inline-flex items-center p-5 h-[50px]">box-3</Child>
  //     </Parent>

  //     <Parent name="parent2" className="text-black">
  //       <Child className="inline-flex items-center p-5 h-[50px]  bg-red-300">
  //         box-1
  //       </Child>
  //       <Child className="inline-flex items-center p-5 h-[50px]  bg-green-300">
  //         box-2
  //       </Child>
  //       <Child className="inline-flex items-center p-5 h-[50px]  bg-blue-300">
  //         box-3
  //       </Child>
  //     </Parent>
  //   </>
  // );

  // const [isPressed, setIsPressed] = useState<boolean>(false);
  // const [value, setValue] = useState<string>("");

  // const handleChange = (e) => {
  //   const val = e.target.value;
  //   setValue(val);

  //   console.log(val);
  // };

  return (
    <>
      {/* <Card radius={"3xl"} shadow={"md"}>
        <Card.Header>Header Content</Card.Header>
        <Card.Main>Main Content</Card.Main>
        <Card.Footer>Footer Content</Card.Footer>
      </Card> */}
      {/* <Component as={'p'}>
        hello
        </Component> */}
      <Select
        onChange={(opt) => {
          console.log(opt);
        }}
      >
        <Select.Option value={"1"}>One</Select.Option>

        {/* <Select.Label>this is label</Select.Label> */}
        {/* <Select.PlaceHolder>this is place holder</Select.PlaceHolder> */}
      </Select>

      {/* <select defaultValue={"sOne"}>
        <option key={"s-one"} value={"sOne"}>
          one
        </option>
        <option key={"s-two"} className="bg-green-600" value={"sTwo"}>
          two
        </option>
        <option key={"s-two"} className="bg-amber-900" value={"sTwo"}>
          three
        </option>
      </select> */}

      <div className="">
        {/* <Grid>
        <Grid.Item>
          item-1
        </Grid.Item>
      </Grid> */}
        {/* <Stack variant={"row"} gap={"md"}>
        <Stack.Item>
          <p className="bg-red-500">box 1</p>
        </Stack.Item>
        <p className="bg-red-500">box 2</p>
        <p className="bg-red-500">box 3</p>
      </Stack>

      <Stack variant={"col"} gap={"md"}>
        <p className="bg-red-500">box 1</p>
        <p className="bg-red-500">box 2</p>
        <p className="bg-red-500">box 3</p>
      </Stack> */}

        {/* <List
        className="bg-red-200 gap-4 p-3 w-[100px]"
        data={["one", "two", "three", "four"]}
        renderItem={({ item, index }) => {
          return (
            <div key={index} className="bg-blue-200 border border-green-500">
              {item}
            </div>
          );
        }}
      /> */}

        {/* <Input value={value} onChange={handleChange} start={<FaBeer />} end={<p>end</p>} /> */}

        {/* <Label text="hello" size={"md"} />
      <Divider size={"lg"} variant={"double"} axis={"x"} />
      <Text size={"md"} color="red">
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatem
        repellat impedit blanditiis pariatur numquam temporibus nesciunt dolor
        dolorum, placeat delectus optio? Voluptates sit obcaecati illo voluptas
        nisi animi, consequuntur nobis.
      </Text>
      <Divider size={"md"} variant={"dashed"} axis={"x"} />
      <Text size={"md"} color="blue">
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatem
        repellat impedit blanditiis pariatur numquam temporibus nesciunt dolor
        dolorum, placeat delectus optio? Voluptates sit obcaecati illo voluptas
        nisi animi, consequuntur nobis.
      </Text> */}

        {/* 
      <ButtonGroup
        // className="flex flex-col"
        variant={"solid"}
        divider={"sm"}
        // dividerColor="red"
        buttons={[
          {
            text: "one",
          },
          {
            text: "two",
            onClick: () => console.log("two clicked"),
          },
          {
            text: "three",
            onClick: () => console.log("two clicked"),
          },
        ]}
      />
      <ButtonGroup
        variant={"outline"}
        // divider={"md"}
        buttons={[
          {
            text: "one",
            // className: 'text-red-400'
          },
          {
            text: "two",
            onClick: () => console.log("two clicked"),
          },
          {
            text: "three",
            onClick: () => console.log("two clicked"),
          },
        ]}
      />
      <ButtonGroup
        variant={"ghost"}
        buttons={[
          {
            text: "one",
          },
          {
            text: "two",
            onClick: () => console.log("two clicked"),
          },
          {
            text: "three",
            onClick: () => console.log("two clicked"),
          },
        ]}
      />

      <Button
        variant={"outline"}
        text="login"
        start={<FaBeer />}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
        // radius={"none"}
        size={"sm"}
      />
      <Button
        variant={"solid"}
        text="login"
        start={<FaBeer />}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
        // radius={"sm"}
        size={"md"}
      />
      <Button
        variant={"solid"}
        text="login"
        start={<FaBeer />}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
        radius={"md"}
        size={"lg"}
      />
      <Button
        variant={"solid"}
        text="login"
        // start={<p>start</p>}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
        radius={"lg"}
      />
      <Button
        variant={"solid"}
        text="login"
        // start={<p>start</p>}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
        radius={"xl"}
      />
      <Button
        variant={"solid"}
        text="login"
        // start={<p>start</p>}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
        radius={"full"}
      />

      <Button
        variant={"solid"}
        text="login"
        // start={<p>start</p>}
        onClick={() => setIsPressed((prev) => !prev)}
        disabled={isPressed}
      /> */}
        {/* <div className="m-5 flex gap-5">
        <div className="h-5 w-5">
          <Button
            variant={"solid"}
            text="1"
            // start={<p>start</p>}
            // end={<FaBeer />}
            disabled
            
          />
        </div>
        <Button
          variant={"solid"}
          size={"md"}
          text="hello"
          start={<FaBeer />}
          disabled
          className="rounded"
        />
        <Button
          variant={"solid"}
          size={"md"}
          text="hello"
          start={<FaBeer />}
          className="rounded-md"

        />
        <Button
          variant={"solid"}
          size={"md"}
          text="hello"
          start={<FaBeer />}
        />
        <Button variant={"solid"} size={"lg"} text="hello" />
      </div>
      <div className="m-5 flex gap-5">
        <Button
          variant={"outline"}
          text="hello"
          start={<FaBeer />}
        />
        <Button variant={"outline"} size={"md"} text="hello" disabled />

        <Button variant={"outline"} size={"lg"} text="hello" />
      </div>
      <div className="m-5 flex gap-5">
        <Button variant={"ghos text="hello" />
        <Button variant={"ghost"} size={"md"} text="hello" />
        <Button variant={"ghost"} size={"lg"} text="hello" disabled />
      </div> */}
      </div>
    </>
  );
};

export default Page1;
