import React, { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Portal } from "../components/Portal";
import { Modal } from "../components/Modal";

const Page4 = () => {
  // const Portal = createPortal(<div className='h-[80vh] w-[80vw] bg-red-400 m-10 '>hello</div>, document.body)

  const modalRef = useRef(null);
  const modalRef2 = useRef(null);
  const ref = useRef(null);

  console.log("renderrr", modalRef);

  // const [count, setCount] = useState(0)
  const [value, setValue] = useState("Select");

  const handleSelect = (e: any) => {
    console.log("selected", e);
    setValue(e);
    modalRef?.current?.close();
  };

  const handleClick = (e) => {
    console.log("click", e);
    console.log("x", e.screenX);
    console.log("y", e.screenY);

    modalRef?.current?.toggle();

    console.log("ref", ref);
    console.log("ref l", ref.current.offsetLeft);
    console.log("ref t", ref.current.offsetTop);
    console.log("modalRef", modalRef);

    setTimeout(() => {
      if (modalRef2.current) {
        console.log("modalRef2.current", modalRef2.current);

        modalRef2.current.className =
          modalRef2.current.className + " text-blue-500";
      }
    }, 500);
  };

  return (
    <>
      {/* <h1>page4 {count}</h1> */}
      <h1
        className="bg-blue-500 text-white w-[100px] m-10"
        onClick={handleClick}
        ref={ref}
      >
        {value}
      </h1>
      <Modal modalRef={modalRef}>
        <div
          ref={modalRef2}
          className="inline-flex flex-col absolute"
          // ref={(el) => {
          //   if (!el) {
          //     return;
          //   }
          //   console.log("ell", el);
          //   el.className = "text-blue-600";
          //   el.offsetLeft = ref.current?.offsetLeft
          //   el.offsetTop = ref.current?.offsetTop
          // }}
        >
          <div
            className=" py-1 px-2 bg-red-500 "
            onClick={() => handleSelect("1")}
          >
            one
          </div>
          <div
            className=" py-1 px-2 bg-red-500 text-white"
            onClick={() => handleSelect("2")}
          >
            two
          </div>
          <div
            className=" py-1 px-2 bg-red-500 text-white"
            onClick={() => handleSelect("3")}
          >
            three
          </div>
        </div>
        {/* <div>
          <button onClick={() => modalRef?.current?.close()}>close</button>
          <button onClick={() => setCount(count + 1)}>inc</button>
          <div className="h-[40vh] w-[40vw] bg-red-400 m-10 ">hello</div>
        </div> */}
      </Modal>
      {/* <button onClick={() => modalRef?.current?.open()}>open</button>
      <button onClick={() => modal2Ref?.current?.open()}>open2</button> */}
      {/* <button onClick={() => modalRef?.current?.open()}>open</button>
      <button onClick={() => modal2Ref?.current?.open()}>open2</button>
      <Modal modalRef={modalRef}>
        <div>
          <button onClick={() => modalRef?.current?.close()}>close</button>
          <button onClick={() => setCount(count + 1)}>inc</button>
          <div className="h-[40vh] w-[40vw] bg-red-400 m-10 ">hello</div>
        </div>
      </Modal>
      <Modal modalRef={modal2Ref}>
        <div>
          <button onClick={() => modal2Ref?.current?.close()}>close2</button>
          <div className="h-[40vh] w-[40vw] bg-blue-400 m-20 ">hello2</div>
        </div>
      </Modal> */}

      {/* <Modal modalRef={modalRef}>
        <div>
          <button onClick={() => modalRef?.current?.close()}>
            close
          </button>
          <div className="h-[40vh] w-[40vw] bg-red-400 m-10 ">hello</div>
        </div>
      </Modal>
      <Modal modalRef={modal2Ref}>
        <div>
          <button onClick={() => modal2Ref?.current?.close()}>
            close2
          </button>
          <div className="h-[40vh] w-[40vw] bg-blue-400 m-20 ">hello2</div>
        </div>
      </Modal> */}
    </>
  );
};

export default Page4;
