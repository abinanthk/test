import React, { useEffect, useRef, useState } from "react";

const Page5 = () => {
  const divRef = useRef();
  const [pos, setPos] = useState({ x: -1, y: -1 });
  const [show, setShow] = useState(false);

  useEffect(() => {
    const p = divRef.current?.getBoundingClientRect?.();

    setInterval(() => {
      //   setPos(prev => ({ x: prev.x+5, y: prev.y + 5 }));
    }, 1000);

    if (p) {
      setPos({ x: p.x, y: p.y + p.height });
    }

    console.log("divRef", divRef);
    console.log("p", p);
  }, []);

  console.log("pos", pos);

  return (
    <>
      <div className="h-96 w-96 mt-30 ml-10 bg-slate-300">
        <p
          ref={divRef}
          className="bg-red-300 ml-[-10px]"
        //   style={{  top: 200, left: 100 }}
          // onClick={() => setShow((prev) => !prev)}
          onMouseEnter={() => setShow(true)}
          onMouseLeave={() => setShow(false)}
        >
          hello
        </p>
        {/* <p>x: {pos.x}</p>
      <p>y: {pos.y}</p> */}
      </div>
      {show && (
        <div
          className="p-10 bg-blue-400"
          style={{ position: "absolute", top: pos.y, left: pos.x }}
        >
          content
        </div>
      )}
    </>
  );
};

export default Page5;
