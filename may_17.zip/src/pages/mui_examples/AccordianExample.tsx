import React from "react";
import { Accordian } from "../../mui/Accordian";
import { MdKeyboardArrowUp } from "react-icons/md";

type Props = {};

export const AccordianExample = (props: Props) => {
  return (
    <div className="m-10 w-[300px]">
      <Accordian
        summary="This is summary"
        details="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Hic reprehenderit eos ipsa quam quos officiis voluptate non laudantium quidem accusamus."
        expandIcon={<MdKeyboardArrowUp />}
      />
      <Accordian
        summary="This is summary 2"
        details="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Hic reprehenderit eos ipsa quam quos officiis voluptate non laudantium quidem accusamus."
        expandIcon={<MdKeyboardArrowUp />}
      />
    </div>
  );
};
