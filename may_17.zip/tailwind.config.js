import colors from "tailwindcss/colors";

/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: colors.zinc,
        accordian: 'rgb(30, 30, 30)'
      },
      animation: {
        fromTop: 'height 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms'
      }
    },
  },
  plugins: [],
};
