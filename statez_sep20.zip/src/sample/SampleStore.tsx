import { useStore, useStoreEffect } from "../react";
import type { TStore } from "../vannila/types";

type Props = {};

type TCount = {
  count: number;
  increment10: () => void;
};

const SampleStore = (props: Props) => {
  const _count2StoreState = useStore<TCount>(
    {
      count: 0,
      increment10() {
        this.count = this.count + 10;
      },
    },
    ["count"]
  );

  useStoreEffect<TCount>(_count2StoreState, (s) => {
    console.log("s", s);
  });

  const handleClick = () => {
    _count2StoreState.state.count++;
  };

  const handleClick10 = () => {
    _count2StoreState.state.increment10();
  };

  return (
    <div>
      <div>Count: {_count2StoreState.state.count}</div>
      <button onClick={handleClick}>click</button>
      <button onClick={handleClick10}>inc 10</button>
      <button onClick={() => _count2StoreState.reset()}>reset</button>
    </div>
  );
};

export default SampleStore;
