import { useStoreEffect } from "..";
import { useForceUpdate } from "../../utils/hooks";
import type { TSync, TStore } from "..";

export const useSyncStore = <TState>(
  store: TStore<TState>,
  sync?: TSync<TState>[]
) => {
  const forceUpdate = useForceUpdate();

  useStoreEffect<TState>(store, () => forceUpdate(), sync);

  return store;
};
