import { useRef } from "react";
import { Store, useSyncStore } from "..";
import type { TSync } from "..";

export const useStore = <TState extends {}>(
  initState: TState,
  sync?: TSync<TState>[]
) => {
  const storeRef = useRef<any>(null);

  if (!storeRef.current) {
    storeRef.current = new Store<TState>(initState);
  }

  return useSyncStore<TState>(storeRef.current, sync);
};
