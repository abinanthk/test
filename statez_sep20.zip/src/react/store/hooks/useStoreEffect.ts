import { useEffect } from "react";
import type { TSync, TStore, TNoti } from "..";

export const useStoreEffect = <TState>(
  store: TStore<TState>,
  fn: (noti: TNoti<TState>) => void,
  sync?: TSync<TState>[]
) => {
  useEffect(() => {
    const _sync =
      sync || (Reflect.ownKeys(store.state as object) as TSync<TState>[]);

    const subscription = store.subscribe((noti: TNoti<TState>) => {
      if (_sync?.includes(noti.change)) {
        fn(noti);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);
};
