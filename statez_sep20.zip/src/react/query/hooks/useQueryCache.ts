import { useRef } from "react";
import { QueryStore, GLOBAL_QUERY_CACHE, useSyncStore } from "..";
import type { TQuery, TQueryStore, TQueryState, TSync } from "..";

export const useQueryCache = (config: TQuery, sync?: TSync<TQueryState>[]) => {
  const _queryCache = useRef<any>(null);

  if (!_queryCache.current) {
    if (GLOBAL_QUERY_CACHE.queries[config.queryKey]) {
      _queryCache.current = GLOBAL_QUERY_CACHE.queries[config.queryKey];
    } else {
      _queryCache.current = new QueryStore(config);
      GLOBAL_QUERY_CACHE.addQuery(config.queryKey, _queryCache.current);
    }
  }

  return useSyncStore<TQueryState>(_queryCache.current, sync) as TQueryStore;
};
