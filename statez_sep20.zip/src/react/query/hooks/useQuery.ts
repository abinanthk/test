import { useRef } from "react";
import { QueryStore, useSyncStore } from "..";
import type { TQuery, TQueryStore, TQueryState } from "..";
import { useQueryCache } from "./useQueryCache";

// export const useQuery = (config: TQuery) => {
//   const storeRef = useRef<any>(null);

//   if (!storeRef.current) {
//     storeRef.current = new QueryStore(config);
//   }

//   return useSyncStore<TQueryState>(storeRef.current);
// };

export const useQuery = (config: TQuery) => {
  return useQueryCache(config);
};
