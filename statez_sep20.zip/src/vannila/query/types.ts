import type { TStore } from "../store/types";

export type TQuery = {
  queryKey: string;
  queryFn: Function;
};

export type TQueryState = {
  status: "idle" | "pending" | "resolved" | "rejected";
  isFetching: boolean;
  data: any;
  error: any;
};

export type TQueryStore = TQuery &
  TStore<TQueryState> & {
    fetch: Function;
  };

export type TQueryCache = {
  queries: any;
  addQuery: (queryKey: string, queryStore: any) => void;
};
