import type { TQuery, TQueryStore, TQueryState } from "../types";
import { Store } from "../../store";

export class QueryStore extends Store<TQueryState> implements TQueryStore {
  private readonly _queryKey: string;
  private readonly _queryFn: Function;

  constructor(query: TQuery) {
    const initState: TQueryState = {
      status: "idle",
      isFetching: false,
      data: undefined,
      error: undefined,
    };
    super(initState);

    this._queryKey = query?.queryKey;
    this._queryFn = query?.queryFn ? query.queryFn : () => {};
  }

  get queryKey() {
    return this._queryKey;
  }

  get queryFn() {
    return this._queryFn;
  }

  async fetch() {
    if (this.state.isFetching) {
      return;
    }
    this.state.isFetching = true;
    this.state.status = "pending";

    try {
      const response = await this.queryFn();
      this.state.data = response;
      this.state.status = "resolved";
    } catch (err) {
      this.state.error = err;
      this.state.data = undefined;
      this.state.status = "rejected";
    } finally {
      this.state.isFetching = false;
    }
  }
}
