import type { TQueryCache } from "../types";

export class QueryCache implements TQueryCache {
  queries: any;

  constructor() {
    this.queries = {};
  }

  addQuery(queryKey: string, queryStore: any) {
    if (this.queries[queryKey]) {
      console.log("query already found", this.queries[queryKey]);
      return;
    }

    this.queries[queryKey] = queryStore;
    console.log("queries : ", this.queries);
  }
}

export const GLOBAL_QUERY_CACHE = new QueryCache();
