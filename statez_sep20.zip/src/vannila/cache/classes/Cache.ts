import type {  } from "../types";

export class Cache{
 
}
