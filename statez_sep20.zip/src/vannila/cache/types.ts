export type TCache = {
  caches: object;
  get: () => any;
  set: () => boolean;
  clear: () => void;
};
