import SampleQueryStore from "./sample/SampleQueryStore";
import SampleStore from "./sample/SampleStore";

const App = () => {
  return <SampleStore />;
};

export default App;
