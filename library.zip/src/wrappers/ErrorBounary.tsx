import { Component, ErrorInfo, ReactNode } from "react";

export interface IErrorBoundary {
  name?: string;
  fallback?: ReactNode;
  onError?: (err: {
    name?: string;
    error?: Error;
    errorInfo?: ErrorInfo;
  }) => void;
}

interface Props extends IErrorBoundary {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(_: Error) {
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.props.onError &&
      this.props.onError({ name: this.props.name, error, errorInfo });
  }

  render() {
    return this.state.hasError ? this.props.fallback : this.props.children;
  }
}

export default ErrorBoundary;
