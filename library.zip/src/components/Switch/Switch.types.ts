import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// store types
export type SwitchStoreTypes = {
  isOn: boolean;
  on: () => void;
  off: () => void;
  toggle: () => void;
};
export type SwitchStoreApiTypes = StoreApi<SwitchStoreTypes>;
export type SwitchStoreSelectorTypes<T> = (state: SwitchStoreTypes) => T;

// component types
export type SwitchProps = ComponentProps<"div"> & {
  store?: SwitchStoreApiTypes;
};
export type SwitchOnProps = ComponentProps<"div">;
export type SwitchOffProps = ComponentProps<"div">;
export type SwitchTriggerProps = ComponentProps<"div">;
