import { ComponentProps } from "react";

export type SwitchProps = ComponentProps<"div">;
