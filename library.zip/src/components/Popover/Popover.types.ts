import { ComponentProps } from "react";
import { StoreApi } from "zustand";

// store types
export type PopoverStoreTypes = {
  visible: boolean;
  show: () => void;
  hide: () => void;
  toggle: () => void;
};
export type PopoverStoreApiTypes = StoreApi<PopoverStoreTypes>;
export type PopoverStoreSelectorTypes<T> = (state: PopoverStoreTypes) => T;

// component types
export type PopoverProps = ComponentProps<"div"> & {
  store?: PopoverStoreApiTypes;
};
export type PopoverContentProps = ComponentProps<"div">;
export type PopoverTriggerProps = ComponentProps<"div">;
