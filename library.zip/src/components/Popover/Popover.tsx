import {
  PopoverProps,
  PopoverContentProps,
  PopoverTriggerProps,
} from "./Popover.types";
import {
  PopoverContext,
  useBodyEvent,
  usePopover,
  usePopoverContext,
  usePopoverStoreInContext,
} from "./Popover.hooks";
import { Portal } from "../Portal";

// Popover provider for using multiple instance
export function Popover({ store, ...props }: PopoverProps) {
  const _store = usePopover(store);

  return (
    <PopoverContext.Provider value={_store}>
      <div {...props} />
    </PopoverContext.Provider>
  );
}

Popover.Content = (props: PopoverContentProps) => {
  const visible = usePopoverStoreInContext<boolean>((state) => state.visible);

  return visible ? (
    <Portal>
      <div {...props} />
    </Portal>
  ) : null;
};

Popover.Trigger = (props: PopoverTriggerProps) => {
  const toggle = usePopoverStoreInContext<() => void>((state) => state.toggle);

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

Popover.Hide = (props: PopoverTriggerProps) => {
  const hide = usePopoverStoreInContext<() => void>((state) => state.hide);

  return (
    <div
      {...props}
      onClick={(e) => {
        hide();
        props.onClick?.(e);
      }}
    />
  );
};

Popover.Show = (props: PopoverTriggerProps) => {
  const show = usePopoverStoreInContext<() => void>((state) => state.show);

  return (
    <div
      {...props}
      onClick={(e) => {
        show();
        props.onClick?.(e);
      }}
    />
  );
};

Popover.HideOnBg = (props: PopoverTriggerProps) => {
  const hide = usePopoverStoreInContext<() => void>((state) => state.hide);
  const store = usePopoverContext()?.getState();

  document.addEventListener("click", () => {
    console.log("document clicked", store);
    if (store?.visible) {
      console.log("document clicked hide");

      hide();
    }
  });

  return null;
};
