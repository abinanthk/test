import { ComponentProps } from "react";

export type MainProps = ComponentProps<"main">;
