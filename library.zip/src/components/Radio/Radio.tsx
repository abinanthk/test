import {
  RadioProps,
  RadioSelectedProps,
  RadioUnSelectedProps,
  RadioToggleProps,
  RadioLabelProps,
  RadioGroupProps,
} from "./Radio.types";
import {
  RadioContext,
  useRadio,
  useRadioStoreInContext,
  RadioGroupContext,
  useRadioGroup,
} from "./Radio.hooks";

// Radio provider for using multiple instance
export function Radio({
  defaultChecked,
  value,
  onChange,
  ...props
}: RadioProps) {
  const radioStore = useRadio({
    isSelected: defaultChecked,
    value,
    onChange: onChange,
  });

  return (
    <RadioContext.Provider value={radioStore}>
      <div {...props} />
    </RadioContext.Provider>
  );
}

Radio.Selected = (props: RadioSelectedProps) => {
  const isSelected = useRadioStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? <div {...props} /> : null;
};

Radio.UnSelected = (props: RadioUnSelectedProps) => {
  const isSelected = useRadioStoreInContext<boolean>(
    (state) => state.isSelected
  );

  return isSelected ? null : <div {...props} />;
};

Radio.Toggle = (props: RadioToggleProps) => {
  const toggle = useRadioStoreInContext<() => void>((state) => state.toggle);

  return (
    <div
      {...props}
      onClick={(e) => {
        toggle();
        props.onClick?.(e);
      }}
    />
  );
};

Radio.Label = (props: RadioLabelProps) => {
  return <label {...props} />;
};

Radio.Group = ({ defaultValue, onChange, ...props }: RadioGroupProps) => {
  const radioGroupStore = useRadioGroup({
    defaultValue,
    onChange: onChange,
  });
  return (
    <RadioGroupContext.Provider value={radioGroupStore}>
      <div {...props} />
    </RadioGroupContext.Provider>
  );
};
