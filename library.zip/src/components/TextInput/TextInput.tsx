import { TextInputProps } from "./TextInput.types";
import {
  TextInputContext,
  useTextInput,
  useTextInputStoreInContext,
} from "./TextInput.hooks";

// TextInput provider for using multiple instance
export function TextInput({ store, ...props }: TextInputProps) {
  const _store = useTextInput(store);

  return (
    <TextInputContext.Provider value={_store}>
      <div {...props} />
    </TextInputContext.Provider>
  );
}
