const Page3 = () => {
  return <div className="m-10 ">page3</div>;
};

export default Page3;
