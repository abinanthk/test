import React, { useState } from "react";
import withBox from "../../HOCs/withBox";
import withErrorBoundary from "../../HOCs/withErrorBoundary";
import withDelay from "../../HOCs/withDelay";
import withConditional from "../../HOCs/withConditional";
import withVisibility from "../../HOCs/withVisibility";
import withSuspense from "../../HOCs/withSuspense";

type HomeProps = {
  color?: string;
};

// const TextInput = (
//   props: React.DetailedHTMLProps<
//     React.InputHTMLAttributes<HTMLInputElement>,
//     HTMLInputElement
//   >
// ) => <input {...props} />;

// const TextInputBox =
//   withBox<
//     React.DetailedHTMLProps<
//       React.InputHTMLAttributes<HTMLInputElement>,
//       HTMLInputElement
//     >
//   >(TextInput);

function Home(props: HomeProps) {
  const [value, setValue] = useState("");
  const [error, setError] = useState("Required..!");

  const handleChange = (e: any) => {
    setValue(e.target.value);
    const val = e.target.value.trim();
    console.log(val);

    if (val === "") {
      setError("Required...!");
      return;
    }
    if (val === "abi") {
      setError("Hey abi ...!");
      return;
    }

    setError("");
  };

  const Comp = () => {
    // throw new Error("danger");
    return <h1>hey</h1>;
  };

  const CompErr = withErrorBoundary(Comp, {
    name: "Comp component",
    fallback: <div>error occured</div>,
    onError: (v) => {
      //   alert("Error on " + v.name);
      console.log("error occured", v);
    },
  });

  const CompDelay = withVisibility(withDelay(Comp, { duration: 1000 }));

  const CompConditional = withConditional<{ name1: string }, { name2: string }>(
    (props) => <div>comp1{props.name1}</div>,
    (props) => <div>comp2{props.name2}</div>
  );

  const CompSus = withSuspense(Comp, {
    fallback: <h1>Loading...</h1>,
  });

  return (
    <div style={{ color: props.color, rowGap: 10 }}>
      <CompSus />
      {/* <CompConditional
        condition={false}
        comp1Props={{ name1: "hey component 1" }}
        comp2Props={{ name2: "hey component 2" }}
      /> */}
      {/* <CompDelay visible={true} /> */}
      {/* <TextInputBox
        boxProps={{
          boxType: "h-v",
            boxLeft: (
              <span style={{ color: "#333", marginRight: 10 }}>Name : </span>
            ),
          //   boxRight: (
          //     <span style={{ color: "#333", marginRight: 10 }}>End : </span>
          //   ),
          boxBottom: error && (
            <p
              style={{
                // backgroundColor: "green",
                fontSize: 13,
                color: "red",
                margin: 0,
              }}
            >
              {error}
            </p>
          ),
        //   boxTop: <p style={{ margin: 0 }}>Name: </p>,
          //   boxHContainerProps: {
          //     // style: { backgroundColor: "green" },
          //   },
          //   boxVContainerProps: {
          //     // style: { backgroundColor: "blue" },
          //   },
        }}
        // style={{ backgroundColor: "red" }}
        value={value}
        onChange={handleChange}
      /> */}
    </div>
  );
}

export default Home;
