import { CheckBox } from "../components/CheckBox";

type Props = {};

const PageCheckBox = (props: Props) => {
  return (
    <div className="m-5">
      <CheckBox.Group
        defaultValue={["male"]}
        name="gender"
        onChange={(value) => {
          console.log("group value", value);
        }}
      >
        <CheckBox value="male">
          <CheckBox.Toggle className="flex items-center gap-2">
            <CheckBox.Selected className="bg-green-400 h-2 w-2"></CheckBox.Selected>
            <CheckBox.UnSelected className="bg-red-400 h-2 w-2"></CheckBox.UnSelected>
            <CheckBox.Label>male</CheckBox.Label>
          </CheckBox.Toggle>
        </CheckBox>
        <CheckBox value="female">
          <CheckBox.Toggle className="flex items-center gap-2">
            <CheckBox.Selected className="bg-green-400 h-2 w-2"></CheckBox.Selected>
            <CheckBox.UnSelected className="bg-red-400 h-2 w-2"></CheckBox.UnSelected>
            <CheckBox.Label>female</CheckBox.Label>
          </CheckBox.Toggle>
        </CheckBox>
        <CheckBox value="others">
          <CheckBox.Toggle className="flex items-center gap-2">
            <CheckBox.Selected className="bg-green-400 h-2 w-2"></CheckBox.Selected>
            <CheckBox.UnSelected className="bg-red-400 h-2 w-2"></CheckBox.UnSelected>
            <CheckBox.Label>others</CheckBox.Label>
          </CheckBox.Toggle>
        </CheckBox>
      </CheckBox.Group>
    </div>
  );
};

export default PageCheckBox;
