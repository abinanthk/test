import { TextInput } from "../components/TextInput";
import {
  useTextInput,
  useTextInputStore,
} from "../components/TextInput/TextInput.hooks";

type Props = {};

const PageTextInput = (props: Props) => {
  return (
    <div className="m-5">
      <TextInput>df</TextInput>
    </div>
  );
};

export default PageTextInput;
