import { Radio } from "../components/Radio";

type Props = {};

const PageRadio = (props: Props) => {
  return (
    <div className="m-5">
      <Radio.Group
        defaultValue={"male"}
        name="gender"
        onChange={(value) => {
          console.log("group value", value);
        }}
      >
        <Radio value="male">
          <Radio.Toggle className="flex items-center gap-2">
            <Radio.Selected className="bg-green-400 h-2 w-2 rounded"></Radio.Selected>
            <Radio.UnSelected className="bg-red-400 h-2 w-2 rounded"></Radio.UnSelected>
            <Radio.Label>male</Radio.Label>
          </Radio.Toggle>
        </Radio>
        <Radio value="female">
          <Radio.Toggle className="flex items-center gap-2">
            <Radio.Selected className="bg-green-400 h-2 w-2 rounded"></Radio.Selected>
            <Radio.UnSelected className="bg-red-400 h-2 w-2 rounded"></Radio.UnSelected>
            <Radio.Label>female</Radio.Label>
          </Radio.Toggle>
        </Radio>
        <Radio value="others">
          <Radio.Toggle className="flex items-center gap-2">
            <Radio.Selected className="bg-green-400 h-2 w-2 rounded"></Radio.Selected>
            <Radio.UnSelected className="bg-red-400 h-2 w-2 rounded"></Radio.UnSelected>
            <Radio.Label>others</Radio.Label>
          </Radio.Toggle>
        </Radio>
      </Radio.Group>
    </div>
  );
};

export default PageRadio;
