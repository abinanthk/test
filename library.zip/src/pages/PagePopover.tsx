import { Popover } from "../components/Popover";
import {
  usePopover,
  usePopoverStore,
} from "../components/Popover/Popover.hooks";

type Props = {};

const PagePopover = (props: Props) => {
  const store = usePopover();

  console.log("store", store);

  // const toggle = usePopoverStore(store, (state) => state.toggle);
  // const visible = usePopoverStore(store, (state) => state.visible);
  // // const { visible } = store.getState();

  // console.log("ss", visible);

  return (
    <div className="m-5 inline-flex flex-col gap-3">
      {/* <button onClick={() => toggle()}>external button</button> */}

      <Popover>
        <Popover.Content className="inline-flex bg-green-200 px-1">
          content1
        </Popover.Content>

        <Popover.Trigger className="inline-flex bg-green-400 px-1">
          <button>trigger1</button>
        </Popover.Trigger>
      </Popover>

      <Popover>
        <Popover.HideOnBg />
        <Popover.Content className="inline-flex bg-red-200 px-1">
          content2
        </Popover.Content>
        <Popover.Trigger className="inline-flex bg-red-400 px-1">
          <button>trigger2</button>
        </Popover.Trigger>
      </Popover>
    </div>
  );
};

export default PagePopover;
