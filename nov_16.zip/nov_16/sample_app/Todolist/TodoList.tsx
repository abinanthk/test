import Reatc from "react";
import {
  useStore,
  useVannilaApiStore,
  useVannilaStore,
} from "../../../../packages/react";
import {
  useMountEffect,
  useUnMountEffect,
} from "../../../../packages/react/src/react-utils";

import { Store, ApiStore } from "../../../../packages/vannila";
import { TaskForm } from "./TaskForm";
import { TaskList } from "./TaskList";

type TUserData = {
  name: string;
  age: number;
};

type TApiError = {
  message: string;
};

const userData: TUserData = {
  name: "abi",
  age: 22,
};

type TUserStoreState = {
  data: TUserData;
  error: TApiError;
};

const getUser = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(userData);
    }, 1000);
  });
};

const apiuserStore = new ApiStore<TUserStoreState>(
  new Store({
    data: {
      name: "",
      age: 0,
    },
    error: {
      message: "",
    },
  }),
  async (state) => {
    console.log("fetching...");

    try {
      const data_ = (await getUser()) as TUserData;

      state.data = data_;
    } catch (err) {
      state.error = { message: "Something went wrong" };
    }
  },
  {
    prefetch: true,
    staleTime: 10000,
    // cacheTime: 10000,
    // pollInterval: 2000,
  }
);

const Child = () => {
  const dataStore = useVannilaApiStore(apiuserStore).store;

  // console.log("data source : ", dataStore);

  return (
    <div>
      <div>{dataStore.state.data.name}</div>
      <div>{dataStore.state.data.age}</div>
    </div>
  );
};

export const TodoList = () => {
  // return (
  //   <div>
  //     <TaskForm />
  //     <TaskList />
  //   </div>
  // );

  const showStore1 = useStore({ show: false });
  const showStore2 = useStore({ show: false });

  return (
    <div>
      <div>
        <button
          onClick={() => (showStore1.state.show = !showStore1.state.show)}
        >
          show
        </button>
        {showStore1.state.show && <Child />}
      </div>
      <div>
        <button
          onClick={() => (showStore2.state.show = !showStore2.state.show)}
        >
          show2
        </button>
        {showStore2.state.show && <Child />}
      </div>
    </div>
  );
};
