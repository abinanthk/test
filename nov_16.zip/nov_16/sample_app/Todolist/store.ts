import { createFormStore, createStore } from "../../../../packages/react";
import { Store } from "../../../../packages/vannila";

export type TTaskPriority = "low" | "medium" | "high";

export type TTask = {
  id: number;
  title: string;
  description: string;
  priority: TTaskPriority;
};

export type TTaskFormState = TTask;
export type TTaskFormError = {
  title: string;
  description: string;
};

export type TTaskFormHandler = {
  title: (value: string) => void;
  description: (value: string) => void;
};

export const useTaskForm = createFormStore<
  TTaskFormState,
  TTaskFormError,
  TTaskFormHandler
>(
  {
    value: new Store<TTaskFormState>({
      id: 0,
      title: "",
      description: "",
      priority: "low",
    }),
    error: new Store<TTaskFormError>({
      title: "",
      description: "",
    }),
  },
  {
    handler: ({ value, error }) => ({
      title: (v) => {
        value.title = v;

        if (value.title === "") {
          error.title = "Title Required..!";
        } else {
          error.title = "";
        }
      },
      description: (v) => {
        value.description = v;

        if (value.description === "") {
          error.description = "Description Required..!";
        } else {
          error.description = "";
        }
      },
    }),
    onLoad: ({ value, error }) => {
      console.log("loading");

      value.title = "default";
    },
    onSubmit: ({ value, error }) => {
      let hasError = false;

      if (value.title === "") {
        error.title = "Title Required..!";
        hasError = true;
      } else {
        error.title = "";
      }
      if (value.description === "") {
        error.description = "Description Required..!";
        hasError = true;
      } else {
        error.description = "";
      }

      if (hasError) {
        return;
      }

      useTaskList.store.reducer.addTask({ ...value, id: ++value.id });
      value.title = "";
      value.description = "";
      value.priority = "low";
    },
  }
);

export type TTaskListState = {
  tasks: TTask[];
};
export type TTaskListReducer = {
  addTask: (task: TTask) => void;
  editTask: (task: TTask) => void;
  removeTask: (task: TTask) => void;
};

export const useTaskList = createStore<TTaskListState, TTaskListReducer>(
  {
    tasks: [],
  },
  {
    reducer: (state) => ({
      addTask(task) {
        state.tasks = [...state.tasks, task];
      },
      editTask(task) {
        state.tasks = [...state.tasks, task];
      },
      removeTask(task) {
        state.tasks = state.tasks.filter((t) => t.id !== task.id);
      },
    }),
  }
);


