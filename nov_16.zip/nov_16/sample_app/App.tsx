import { TodoList } from "./Todolist";
// import { DevTools } from "./DevTools";
import { Root } from "./Ecommerce/routes/Root";

const App = () => {
  // return <Root />;

  return (
    <div style={{ display: "flex", gap: 10 }}>
      <div style={{ marginTop: 40 }}>
        <TodoList />
      </div>
      {/* <DevTools /> */}
    </div>
  );
};

export default App;
