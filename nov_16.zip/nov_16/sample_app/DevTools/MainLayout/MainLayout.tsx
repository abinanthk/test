import { useState } from "react";
import { StoreList } from "../StoreList";
import { HistoryList } from "../HistoryList";

export const MainLayout = () => {
  const [tab, setTab] = useState(0);
  return (
    <div>
      <div>
        <button onClick={() => setTab(0)}>History</button>
        <button onClick={() => setTab(1)}>Stores</button>
      </div>
      <div>{tab === 0 ? <HistoryList /> : <StoreList />}</div>
    </div>
  );
};
