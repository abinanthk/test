import { useDevToolsPlugin } from "../../../../../packages/react";
import { Store } from "../../../../../packages/vannila";

export type StoreItemProps = {
  store: Store<any, any>;
};
const StoreItem = ({ store }: StoreItemProps) => {
  console.log("store : ", store);

  const fields = Object.entries(store.state).map(([key, value]) => {
    return (
      <div key={key}>
        <p>
          {key} : {JSON.stringify(value)}
        </p>
      </div>
    );
  });

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          fontWeight: "bold",
          padding: 5,
          margin: 5,
          backgroundColor: "#333",
          color: "#eee",
        }}
      >
        {store.config?.name}
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        {fields}
      </div>
    </div>
  );
};

export const StoreList = () => {
  const stores = useDevToolsPlugin();

  console.log("stores : ", stores);

  return (
    <div>
      <p>--- Dev Tools ---</p>
      <div>
        {stores.map((store, i) => (
          <div key={i}>
            <StoreItem store={store} />
          </div>
        ))}
      </div>
    </div>
  );
};
