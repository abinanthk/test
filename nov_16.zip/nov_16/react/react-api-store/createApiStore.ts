import { ApiStore, TDeps,  TApiStoreOptions, TApiStoreFetch, Store } from "../../../vannila/index.ts";
import { useVannilaApiStore } from "./useVannilaApiStore.ts";

export const createApiStore = <
  TState extends {} = {},
>(
  store: Store<TState>,
  fetch: TApiStoreFetch<TState>,
  options?: TApiStoreOptions
) => {
  const Apistore = new ApiStore(store, fetch, options);

  const hook = (deps?: TDeps<TState>) =>
    useVannilaApiStore<TState>(Apistore, deps);

  hook.apistore = Apistore;

  return hook;
};
