import { ApiStore } from "../../../vannila";
import type { TDeps } from "../../../vannila";
import { useVannilaStore } from "../react-store";
import { useMountEffect, useUnMountEffect } from "../react-utils";

export const useVannilaApiStore = <TState extends {}>(
  apiStore: ApiStore<TState>,
  deps?: TDeps<TState>
) => {
  useVannilaStore<TState, ApiStore<TState>>(apiStore.store as any, deps);

  useMountEffect(() => {
    apiStore.subscribe();
  });

  useUnMountEffect(() => {
    apiStore.unsubscribe();
  });

  return apiStore;
};
