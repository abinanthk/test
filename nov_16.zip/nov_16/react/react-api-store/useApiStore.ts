import {
  ApiStore,
  Store,
  TApiStoreFetch,
  TApiStoreOptions,
  TDeps,
} from "../../../vannila/index.ts";
import { useSingleton } from "../react-utils/index.ts";
import { useVannilaApiStore } from "./useVannilaApiStore.ts";

export const useApiStore = <TState extends {}>(
  store: Store<TState>,
  fetch: TApiStoreFetch<TState>,
  options?: TApiStoreOptions,
  deps?: TDeps<TState>
) => {
  const apiStore = useSingleton(
    () => new ApiStore<TState>(store, fetch, options)
  );

  return useVannilaApiStore<TState>(apiStore, deps);
};
