import { Store } from "../../../../packages/vannila";
import { TDeps } from "../../../../packages/vannila";
import { useForceUpdate } from "../react-utils";
import { useVannilaStoreEffect } from "./useVannilaStoreEffect";

export const useVannilaStore = <
  TState extends {} = {},
  TReducer extends {} = {},
  TPlugins extends {} = {}
>(
  store: Store<TState, TReducer, TPlugins>,
  deps?: TDeps<TState>
) => {
  const forceUpdate = useForceUpdate();
  useVannilaStoreEffect(store, () => forceUpdate(), deps);

  return store;
};
