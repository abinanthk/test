import { useEffect } from "react";
import { Store, TNoti } from "../../../vannila";
import { TDeps } from "../../../vannila";

export const useVannilaStoreEffect = <
  TState extends {} = {},
  TReducer extends {} = {},
  TPlugins extends {} = {}
>(
  store: Store<TState, TReducer, TPlugins>,
  effect: (noti: TNoti<TState>) => void,
  deps?: TDeps<TState>
) => {
  useEffect(() => {
    const _deps =
      deps || (Reflect.ownKeys(store.state as object) as TDeps<TState>);

    const subscription = store.subscribe((noti: TNoti<TState>) => {
      if (_deps?.includes(noti.prop)) {
        effect(noti);
      }
    });

    return () => {
      subscription?.unsubscribe();
    };
  }, []);
};
