import { useEffect } from "react";
import { DevToolsPlugin } from "../../../vannila";
import { createStore } from "../react-store";

const useStoresStore = createStore({
  stores: [],
});

export const useDevToolsPlugin = () => {
  const storesStore = useStoresStore();

  useEffect(() => {
    const allStore = DevToolsPlugin.getAllStore();
    storesStore.state.stores = Array.from(
      allStore,
      ([name, value]) => value
    ) as any;

    const subscription = DevToolsPlugin.subscribe((stores) => {
      console.log("store -- : ", stores);

      storesStore.state.stores = Array.from(
        stores,
        ([name, value]) => value
      ) as any;
    });

    return () => subscription.unsubscribe();
  }, []);

  return storesStore.state.stores;
};
