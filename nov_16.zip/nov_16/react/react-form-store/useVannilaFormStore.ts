import { FormStore, Store, TDeps } from "../../../vannila";
import { useVannilaStore } from "../react-store";

export const useVannilaFormStore = <
  TValue extends {} = {},
  TError extends {} = {},
  THandler extends {} = {}
>(
  formStore: FormStore<TValue, TError, THandler>,
  valueDeps?: TDeps<TValue>,
  errorDeps?: TDeps<TError>
) => {
  useVannilaStore<TValue, Store<TValue>>(
    formStore.valueStore as any,
    valueDeps
  );
  useVannilaStore<TError, Store<TError>>(
    formStore.errorStore as any,
    errorDeps
  );
  return formStore;
};
