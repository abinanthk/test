import {
  FormStore,
  TDeps,
  TFormStoreOptions,
  TFormStores,
} from "../../../vannila";
import { useVannilaFormStore } from "./useVannilaFormStore";

export const createFormStore = <
  TValue extends {} = {},
  TError extends {} = {},
  THandler extends {} = {}
>(
  stores: TFormStores<TValue, TError>,
  options?: TFormStoreOptions<TValue, TError, THandler>
) => {
  const formStore = new FormStore<TValue, TError, THandler>(stores, options);

  const hook = (valueDeps?: TDeps<TValue>, errorDeps?: TDeps<TError>) =>
    useVannilaFormStore<TValue, TError, THandler>(
      formStore,
      valueDeps,
      errorDeps
    );

  hook.formStore = formStore;

  return hook;
};
