import { Store } from "../vannila-store";
import type { IFormStore, TFormStoreOptions, TFormStores } from "./types";

export class FormStore<
  TValue extends {} = {},
  TError extends {} = {},
  THandler extends {} = {}
> implements IFormStore<THandler>
{
  private readonly _valueStore: Store<TValue>;
  private readonly _errorStore: Store<TError>;
  private readonly _handler: THandler;
  private readonly _options: TFormStoreOptions<TValue, TError, THandler>;

  constructor(
    stores: TFormStores<TValue, TError>,
    options?: TFormStoreOptions<TValue, TError, THandler>
  ) {
    const DEFAULT_FORM_STORE_OPTIONS: TFormStoreOptions<
      TValue,
      TError,
      THandler
    > = {
      handler: () => ({} as THandler),
      onLoad: () => {},
      onSubmit: () => {},
    };

    this._valueStore = stores.value;
    this._errorStore = stores.error;

    this._options = {
      ...DEFAULT_FORM_STORE_OPTIONS,
      ...options,
    };

    this._handler = this._options.handler({
      value: this.value,
      error: this.error,
    });
  }

  get valueStore() {
    return this._valueStore;
  }

  get errorStore() {
    return this._errorStore;
  }

  get value() {
    return this._valueStore.state;
  }

  get error() {
    return this._errorStore.state;
  }

  get handler() {
    return this._handler;
  }

  load() {
    this._options.onLoad?.({ value: this.value, error: this.error });
  }

  submit() {
    this._options.onSubmit?.({ value: this.value, error: this.error });
  }
}
