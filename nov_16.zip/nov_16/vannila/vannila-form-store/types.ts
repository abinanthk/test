import { Store } from "../vannila-store";

export type THandlerFn<TValue, TError, THandler> = ({
  value,
  error,
}: {
  value: TValue;
  error: TError;
}) => THandler;

export type TFormStoreOptions<
  TValue extends {} = {},
  TError extends {} = {},
  THandler extends {} = {}
> = {
  handler: THandlerFn<TValue, TError, THandler>;
  onLoad: THandlerFn<TValue, TError, void>;
  onSubmit: THandlerFn<TValue, TError, void>;
};

export type IFormStore<THandler extends {} = {}> = {
  handler: THandler;
  load: () => void;
  submit: () => void;
};

export type TFormStores<TValue extends {} = {}, TError extends {} = {}> = {
  value: Store<TValue>;
  error: Store<TError>;
};
