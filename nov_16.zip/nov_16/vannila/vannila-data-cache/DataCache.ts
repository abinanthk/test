import { TWatchSubscription } from "../vannila-utils";
import { Cache } from "../vannila-utils/vannila-cache";
import { TDataCacheItem } from "./types";

export class DataCache {
  static cache = new Cache<string, TDataCacheItem<any>>();
  private static _watchSubscriptions = new Map<string, TWatchSubscription>();

  static register(config: TDataCacheItem<any>) {
    DataCache.cache.set(config.key, config.fetch);
  }

  static fetch(key: string, options: object) {
    const dataCacheItem = DataCache.cache.get(key);

    if (!dataCacheItem) {
      return;
    }

    dataCacheItem.fetch(options);
  }
}
