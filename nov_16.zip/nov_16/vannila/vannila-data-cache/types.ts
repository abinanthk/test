export type TDataCacheItem<T> = {
  key: string;
  fetch: (options: object) => T;
  data: T | null;
  cacheTime: number;
  staleTime: number;
};
