import { StoreX } from "../../vannila-store-x";
import { Subject } from "../../vannila-utils";
import { HistoryPlugin } from "../vannila-history-plugin";

export class DevToolsPlugin {
  private static _subject$: Subject<any> = new Subject();
  private static _map = new Map();

  static getAllStore() {
    return DevToolsPlugin._map.entries();
  }

  static getStore(key: string) {
    return DevToolsPlugin._map.get(key);
  }

  static register<TState extends {}, TReducer extends {}>(
    store: StoreX<TState, TReducer>
  ) {
    console.log("register store : ", store.config.name);

    if (!store.config.name) {
      return;
    }

    DevToolsPlugin._map.set(store.config.name, store);

    DevToolsPlugin._subject$.next(this.getAllStore());
  }

  static subscribe(listener: (action: any) => void) {
    return DevToolsPlugin._subject$.subscribe(listener);
  }
}

export const devToolsPlugin = () => (store: any) => {
  DevToolsPlugin.register(store);

  return {
    history: new HistoryPlugin({ store }),
  };
};
