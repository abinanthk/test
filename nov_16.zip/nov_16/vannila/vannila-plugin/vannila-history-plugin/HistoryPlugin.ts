import type { IHistoryPlugin, THistoryPluginConfig } from "./types";
import { TDeps } from "../../vannila-api-store";
import { History, TSubscription } from "../../vannila-utils";
import { Store } from "../../vannila-store";

export class HistoryPlugin<TState extends {}>
  extends History<TState>
  implements IHistoryPlugin<TState>
{
  private readonly _store: Store<TState>;
  private historySubscription: TSubscription;

  constructor(config: THistoryPluginConfig<TState>) {
    super({ ...config.store.state }, config.max);
    this._store = config.store;

    this.historySubscription = config.store.subscribe((noti: any) => {
      this.push({ [noti.prop]: noti.value } as TState);
    });
  }

  get store() {
    return this._store;
  }

  private update() {
    if (!this.current) {
      return;
    }

    this.historySubscription?.unsubscribe();
    const _deps = Reflect.ownKeys(this.current as object) as TDeps<TState>;

    _deps?.forEach((key) => {
      if (!Reflect.has(this._store.state, key)) {
        return;
      }

      this._store.state[key] = this.current![key];
    });

    this.historySubscription = this._store.subscribe((noti) => {
      this.push({ [noti.prop]: noti.value } as TState);
    });
  }

  pop() {
    super.pop();
    this.update();
  }

  undo(n?: number) {
    super.undo(n);
    this.update();
  }

  redo(n?: number) {
    super.redo(n);
    this.update();
  }
}

export const historyPlugin = (max?: number) => (store: any) =>
  new HistoryPlugin({ store, max });
