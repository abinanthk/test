import { Store } from "../../vannila-store";

export type IHistoryPlugin<TState extends {}> = {
  // getUndoList(): (TState | undefined)[] | undefined;
  // getRedoList(): (TState | undefined)[] | undefined;
  // current: TState | undefined;
  undo(): void;
  redo(): void;
};

export type THistoryPluginConfig<TState extends {}> = {
  store: Store<TState>;
  max?: number;
};
