export type TApiStoreOptions = {
  prefetch?: boolean;
  staleTime?: number;
  cacheTime?: number;
  pollInterval?: number;
};

export type TApiStoreFetch<TState extends {} = {}> = (state: TState) => void;

export type TApiStoreConfig<TState extends {} = {}> = {
  fetch: TApiStoreFetch<TState>;
  options?: TApiStoreOptions;
};
