import { Store } from "../vannila-store/Store";
import { Interval } from "../vannila-utils/vannila-interval";
import { Timeout } from "../vannila-utils/vannila-timeout";
import { TApiStoreFetch, TApiStoreOptions } from "./types";

const DEFAULT_API_STORE_OPTIONS = {
  fetchOnMount: false,
  prefetch: false,
  staleTime: 0,
  cacheTime: -1,
  pollInterval: -1,
};

export class ApiStore<TState extends {} = {}> {
  private readonly _store: Store<TState>;
  private readonly _fetch: TApiStoreFetch<TState>;
  private readonly _options: Required<TApiStoreOptions>;

  private readonly _cacheTimer?: Timeout;
  private readonly _pollInterval?: Interval;

  private _lastUpdated: number = new Date().getTime();

  constructor(
    store: Store<TState>,
    fetch: TApiStoreFetch<TState>,
    options?: TApiStoreOptions
  ) {
    this._store = store;

    this._fetch = fetch;

    this._options = {
      ...DEFAULT_API_STORE_OPTIONS,
      ...options,
    };

    this._cacheTimer =
      this._options.cacheTime >= 0
        ? new Timeout(this._options.cacheTime)
        : undefined;

    this._pollInterval =
      this._options.pollInterval >= 0
        ? new Interval(this._options.pollInterval)
        : undefined;

    if (this._options.prefetch) {
      console.log("fetching (prefetch) ");
      this.fetch();
    }
  }

  get store() {
    return this._store;
  }

  fetch() {
    this._fetch(this.store.state);

    this._lastUpdated = new Date().getTime();
  }

  subscribe() {
    if (!this.store.observed) {
      return;
    }

    const currentDateTime = new Date().getTime();

    if (currentDateTime - this._lastUpdated >= this._options.staleTime) {
      console.log("fetching (staleTime) ");
      this.fetch();
    }

    this._pollInterval?.set(() => {
      console.log("fetching (pollInterval) ");
      this.fetch();
    });

    this._cacheTimer?.clear();
  }

  unsubscribe() {
    if (this.store.observed) {
      return;
    }

    this._pollInterval?.clear();
    this._cacheTimer?.set(() => {
      console.log("resetted ");
      this.store.reset();
    });
  }
}
