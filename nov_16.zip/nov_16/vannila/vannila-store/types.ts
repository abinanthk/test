import { TNoti } from "../vannila-core/types";
import { TSubscribe } from "../vannila-utils/vannila-subject";

export type TStoreOptions<
  TState extends {} = {},
  TReducer extends {} = {},
  TPlugins extends {} = {}
> = {
  key?: string;
  reducer?: (state: TState) => TReducer;
  plugins?: TPlugins;
};

export type IStore<TState extends {}> = {
  subscribe: TSubscribe<TNoti<TState>>;
};
