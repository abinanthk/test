export interface ITimer {
  set(callback: () => void): void;
  clear(): void;
}
