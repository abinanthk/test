import type { ITimer } from "./types";

export class Interval implements ITimer {
  private _id: number = -1;
  private _timeout: number = 0;

  constructor(timeout: number) {
    this._timeout = timeout;
  }

  set(callback: () => void): void {
    if (this._id !== -1) {
      clearInterval(this._id);
    }
    this._id = setInterval(callback, this._timeout);
  }

  clear(): void {
    clearInterval(this._id);
    this._id = -1;
  }
}
