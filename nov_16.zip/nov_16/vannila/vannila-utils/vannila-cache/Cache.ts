import type { ICache, TCacheConfig, TCacheConfig_, TCacheItem } from "./types";
import { Timeout } from "../vannila-timeout";
import { Interval } from "../vannila-interval";

const DEFAULT_CACHE_CONFIG: TCacheConfig_ = {
  maxSize: 50,
  cacheTime: 5000,
  staleTime: 2000,
};

export class Cache<K, V> implements ICache<K, V> {
  protected readonly _cache: Map<K, TCacheItem<V>>;
  private readonly _config: TCacheConfig_;

  constructor(config?: TCacheConfig) {
    this._cache = new Map<K, TCacheItem<V>>();
    this._config = {
      ...DEFAULT_CACHE_CONFIG,
      ...config,
    };
  }

  set(key: K, createItem: () => V, force: boolean = false) {
    // if (this._cache.size >= this._maxSize) {
    //   console.warn("Cache is full.");
    //   return false;
    // }

    if (!force && this._cache.has(key)) {
      return false;
    }

    this._cache.set(key, {
      createItem,
      item: createItem(),
      cacheTimer: new Timeout(),
      staleTimer: new Interval(),
    });

    return true;
  }

  get(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    if (!cacheItem.item) {
      cacheItem.item = cacheItem.createItem();
    }

    return cacheItem.item;
  }

  remove(key: K) {
    return this._cache.delete(key);
  }

  has(key: K) {
    return this._cache.has(key);
  }

  get size() {
    return this._cache.size;
  }

  clear() {
    this._cache.clear();
  }

  startCacheTimer(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    cacheItem.cacheTimer.set(() => {
      console.log("cache timer started...");
      cacheItem.item = null;
    }, this._config.cacheTime);
  }

  stopCacheTimer(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    console.log("cache timer cleared...");
    cacheItem.cacheTimer.clear();
  }

  startStaleTimer(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    cacheItem.staleTimer.set(() => {
      console.log("stale timer started...");
      cacheItem.item = cacheItem.createItem();
    }, this._config.staleTime);
  }

  stopStaleTimer(key: K) {
    const cacheItem = this._cache.get(key);

    if (!cacheItem) {
      return;
    }

    console.log("stale timer cleared...");
    cacheItem.staleTimer.clear();
  }
}
