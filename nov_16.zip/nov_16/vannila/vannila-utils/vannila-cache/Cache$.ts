import { Subject } from "../vannila-subject";
import { Cache } from "./Cache";
import type { ICache$, TCacheConfig, TCreate } from "./types";

export class Cache$<K, V> extends Cache<K, V> implements ICache$ {
  private readonly _subject$: Subject<any>;

  constructor(config?: TCacheConfig) {
    super(config);

    this._subject$ = new Subject();
  }

  private next() {
    this._subject$.next(this._cache);
  }

  setTimeout(key: K, callback: () => void, timeout: number) {
    super.setTimeout(key, callback, timeout);

    this.next();
    console.log("Timer is setted : ", key);
  }

  clearTimeout(key: K) {
    super.clearTimeout(key);

    this.next();
    console.log("Timer is cleared : ", key);
  }

  set(key: K, callback: TCreate<V>, force?: boolean) {
    const e = super.set(key, callback, force);

    this.next();
    console.log("Added : ", key);

    return e;
  }

  remove(key: K) {
    const e = super.remove(key);

    this.next();
    console.log("Removed : ", key);

    return e;
  }

  clear() {
    super.clear();
    this.next();
    console.log("Cleared : ");
  }

  subscribe(listener: (history: any) => void) {
    return this._subject$.subscribe(listener);
  }
}
