import { Timeout } from "../vannila-timeout";
import { Interval } from "../vannila-interval";

export type TCreate<T> = () => T;

export type TCacheItem<T> = {
  createItem: () => T;
  item: T | null;
  cacheTimer: Timeout;
  staleTimer: Interval;
};

export interface ICache<K, V> {
  size: number;
  set: (key: K, createItem: () => V, force?: boolean) => boolean;
  get: (key: K) => V | undefined;
  remove: (key: K) => void;
  has: (key: K) => boolean;
  clear: () => void;
}

export type TCacheConfig = {
  maxSize?: number;
  cacheTime?: number;
  staleTime?: number;
};

export type TCacheConfig_ = {
  maxSize: number;
  cacheTime: number;
  staleTime: number;
};

export interface ICache$ {
  subscribe: (e: any) => void;
}
