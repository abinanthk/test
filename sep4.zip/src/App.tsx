import { Select } from "./ui/Select";

const App = () => {
  return (
    <div className="m-5">
      <Select.Root
        defaultValue={"male"}
        name="gender"
        onChange={(value) => {
          console.log("select value", value);
        }}
      >
        <Select.Trigger>
          <Select.Label>select</Select.Label>
        </Select.Trigger>

        <Select.Content>
          <Select.Option value="male">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>male</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>male</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="female">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>female</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>female</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>

          <Select.Option value="others">
            <Select.Toggle
              style={{ display: "flex", alignItems: "center", gap: 2 }}
            >
              <Select.Selected style={{ backgroundColor: "green" }}>
                <Select.Label>others</Select.Label>
              </Select.Selected>
              <Select.UnSelected style={{ backgroundColor: "red" }}>
                <Select.Label>others</Select.Label>
              </Select.UnSelected>
            </Select.Toggle>
          </Select.Option>
        </Select.Content>
      </Select.Root>
    </div>
  );
};

export default App;
