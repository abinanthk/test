import { createContext, useContext, useEffect, useRef } from "react";
import {
  SelectStoreTypes,
  SelectStoreApiTypes,
  SelectOptionStoreTypes,
  SelectOptionStoreApiTypes,
  SelectHookTypes,
  SelectOptionHookTypes,
} from "./Select.types";
import { createStore, useStore } from "../../store";

// creates a Select store | internal & external use
export const useSelectOption = ({
  value,
  isSelected,
  onChange,
}: SelectOptionHookTypes) => {
  const storeRef = useRef<SelectOptionStoreApiTypes>();
  const _groupCtx = useSelectContext();

  if (!storeRef.current) {
    storeRef.current = createStore<SelectOptionStoreTypes>({
      value: value || "",
      isSelected: isSelected || false,
      select() {
        this.isSelected = true;
        onChange?.(this.isSelected);

        // group
        if (!_groupCtx) {
          return;
        }
        _groupCtx.value = this.value;
        _groupCtx.refresh();
      },
      unselect() {
        this.isSelected = false;
        onChange?.(this.isSelected);

        // group
        if (!_groupCtx) {
          return;
        }
        _groupCtx.value = "";
        _groupCtx.refresh();
      },
      toggle() {
        this.isSelected = !this.isSelected;
        onChange?.(this.isSelected);

        // group
        if (!_groupCtx) {
          return;
        }

        _groupCtx.value = this.isSelected ? this.value : "";
        _groupCtx.refresh();
      },
    });
    _groupCtx?.add(storeRef.current);
  }

  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const SelectOptionContext =
  createContext<SelectOptionStoreApiTypes | null>(null);

// use the Select store in the context (controlled/uncontrolled) | internal use
export const useSelectOptionContext = () => {
  return useContext(SelectOptionContext);
};

// use the Select store in the context (controlled/uncontrolled) | internal use
export const useSelectOptionStoreInContext = (selector?: string[]) => {
  const store = useContext(SelectOptionContext);
  if (!store) {
    throw new Error("Missing Select.Provider");
  }

  return useStore(store, selector);
};

export const useSelect = ({ defaultValue, onChange }: SelectHookTypes) => {
  const storeRef = useRef<SelectStoreApiTypes>();

  if (!storeRef.current) {
    storeRef.current = createStore<SelectStoreTypes>({
      value: defaultValue || "",
      isOpen: false,
      selectStores: [],
      add(selectStore) {
        this.selectStores = [...this.selectStores, selectStore];

        if (selectStore.value === this.value) {
          selectStore.isSelected = true;
        }
      },
      refresh() {
        this.selectStores.map((selectStore) => {
          if (selectStore.value !== this.value) {
            selectStore.isSelected = false;
          }
        });
        onChange?.(this.value);
      },
      select(value: string) {
        this.value = value;
      },
      unselect() {
        this.value = "";
      },
      toggle() {
        this.isOpen = !this.isOpen;
      },
    });
  }
  useEffect(() => {
    // return () => storeRef.current?.destroy();
    console.log('useSelect createStore', storeRef.current)
  }, []);
  return storeRef.current;
};

// context to avoid prop drilling | internal use
export const SelectContext = createContext<SelectStoreApiTypes | null>(null);

// use the Select store in the context (controlled/uncontrolled) | internal use
export const useSelectContext = () => {
  return useContext(SelectContext);
};

export const useSelectStoreInContext = (selector?: string[]) => {
  const store = useContext(SelectContext);
  if (!store) {
    throw new Error("Missing Select.Provider");
  }

  return useStore(store, selector);
};
