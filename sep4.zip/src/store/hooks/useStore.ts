import { useEffect } from "react";
import { useForceUpdate } from "./useForceUpdate";

export const useStore = (store: any, subscribeTo?: string[]) => {
    const forceUpdate = useForceUpdate();
  
    useEffect(() => {
      subscribeTo?.forEach((sub) => {
        store.__proto__.subjects?.[sub]?.subscribe(() => {
          forceUpdate();
        });
      });
    }, []);
  
    return store;
  };
  