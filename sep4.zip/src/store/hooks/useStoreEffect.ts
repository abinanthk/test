import { useEffect } from "react";

export const useStoreEffect = (
    callback: (state: any, label: string) => void,
    stores: any[],
    labels: string[]
  ) => {
    useEffect(() => {
      stores?.forEach((store, index) => {
        store.__proto__.subjects.$?.subscribe((state: any) => {
          callback?.(state, labels?.[index]);
        });
      });
    }, []);
  };