import { useRef } from "react";
import { createStore } from "..";

export const useCreateStore = <TState extends {}>(initState: TState) => {
  const storeRef = useRef(null);

  if (!storeRef.current) {
    // console.log("use create store not exists");
    storeRef.current = createStore<TState>(initState);
  }

  return storeRef.current;
};
