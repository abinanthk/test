import { createContext, useContext, useEffect } from "react";
import { useStore } from "../store";
import { useCreateStore } from "../store/hooks/useCreateStore";

type TOption = {
  isSelected: boolean;
  value: string;
};

type TSelectOptionStore = TOption & {
  onChange: (value: string) => void;
};

type TSelectStore = {
  open: boolean;
  value: string;
  onChange: (value: string) => void;
  options: TOption[];
  addOption: (option: TOption) => void;
};

export const SelectStoreContext = createContext(null);

const useSelectStoreContext = (selectors?: string[]) => {
  const store = useContext(SelectStoreContext);

  return useStore(store, selectors);
};

const SelectRoot = (props: any) => {
  const _selectStore = useCreateStore<TSelectStore>({
    open: true,
    value: props.defaultValue,
    onChange(value: string) {
      
    },
    options: [],
    addOption(option) {
      const optionFound = this.options.find(
        (opt) => opt.value === option.value
      );

      if (optionFound) {
        option.isSelected = optionFound.isSelected;
      } else {
        this.options.push({
          value: option.value,
          isSelected: this.value === option.value,
        });
        option.isSelected = this.value === option.value;
      }
    },
  });

  useEffect(() => {
    if (props.xRef) {
      props.xRef.current = _selectStore;
    }
  }, []);

  return (
    <SelectStoreContext.Provider value={_selectStore}>
      {props.children}
    </SelectStoreContext.Provider>
  );
};

const SelectLabel = (props: any) => {
  return <label {...props} />;
};

const SelectPlaceholder = (props: any) => {
  const _selectStore = useSelectStoreContext(["value"]);

  return (
    <span {...props}>
      {_selectStore.value ? _selectStore.value : props.children}
    </span>
  );
};

const SelectTrigger = (props: any) => {
  const _selectStore = useSelectStoreContext();

  const handleClick = (e: any) => {
    _selectStore.open = !_selectStore.open;
    props.onClick?.(e);
  };

  return <div {...props} onClick={handleClick} />;
};

const SelectContent = (props: any) => {
  const _selectStore = useSelectStoreContext(["open"]);

  return _selectStore.open ? <div>{props.children}</div> : null;
};

export const SelectOptionStoreContext = createContext(null);

const useSelectOptionStoreContext = (selectors?: string[]) => {
  const store = useContext(SelectOptionStoreContext);

  return useStore(store, selectors);
};

const SelectOption = (props: any) => {
  const _selectStore = useSelectStoreContext();

  const _selectOptionStore = useCreateStore<TSelectOptionStore>({
    isSelected: false,
    value: props.value,
    onChange() {},
  });

  useEffect(() => {
    _selectStore.addOption(_selectOptionStore);
  }, []);

  return (
    <SelectOptionStoreContext.Provider value={_selectOptionStore}>
      {props.children}
    </SelectOptionStoreContext.Provider>
  );
};

const SelectSelected = (props: any) => {
  const _selectOptionStore = useSelectOptionStoreContext(["isSelected"]);

  return _selectOptionStore.isSelected ? <div {...props} /> : null;
};

const SelectUnSelected = (props: any) => {
  const _selectOptionStore = useSelectOptionStoreContext(["isSelected"]);

  return _selectOptionStore.isSelected ? null : <div {...props} />;
};

const SelectToggle = (props: any) => {
  const _selectOptionStore = useSelectOptionStoreContext();
  const _selectStore = useSelectStoreContext();

  const handleClick = (e: any) => {
    _selectOptionStore.isSelected = !_selectOptionStore.isSelected;
    _selectStore.options.forEach((option: TOption) => {
      if (_selectOptionStore.value === option.value) {
        option.isSelected = _selectOptionStore.isSelected;
      }
    });
    props.onClick?.(e);
  };

  return <div {...props} onClick={handleClick} />;
};

export const Select = {
  Root: SelectRoot,
  Label: SelectLabel,
  Trigger: SelectTrigger,
  Content: SelectContent,
  Option: SelectOption,
  Selected: SelectSelected,
  UnSelected: SelectUnSelected,
  Toggle: SelectToggle,
};
