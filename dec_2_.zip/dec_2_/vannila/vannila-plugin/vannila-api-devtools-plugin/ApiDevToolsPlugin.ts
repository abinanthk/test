import { Api } from "../../vannila-api";
import { Subject } from "../../vannila-utils";

export class ApiDevToolsPlugin {
  private static _subject$: Subject<any> = new Subject();
  private static _map = new Map();

  static list() {
    return ApiDevToolsPlugin._map.entries();
  }

  static register<TData, TPayload>(key: string, api: Api<TData, TPayload>) {
    console.log("register api : ", key);

    if (!key) {
      return;
    }

    ApiDevToolsPlugin._map.set(key, api);

    ApiDevToolsPlugin._subject$.next(this.list());
  }

  static subscribe(listener: (action: any) => void) {
    return ApiDevToolsPlugin._subject$.subscribe(listener);
  }
}

export const apiDevToolsPlugin = (key: string) => (api: any) => {
  ApiDevToolsPlugin.register(key, api);
};
