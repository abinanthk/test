import { Store } from "../../vannila-store";
import { Subject } from "../../vannila-utils";
import { HistoryPlugin } from "../vannila-history-plugin";

export class DevToolsPlugin {
  private static _subject$: Subject<any> = new Subject();
  private static _map = new Map();

  static list() {
    return DevToolsPlugin._map.entries();
  }

  static getStore(key: string) {
    return DevToolsPlugin._map.get(key);
  }

  static register<TState extends {}, TReducer extends {}>(
    key: string,
    store: Store<TState, TReducer>
  ) {
    console.log("register store : ", key);

    if (!key) {
      return;
    }

    DevToolsPlugin._map.set(key, store);

    DevToolsPlugin._subject$.next(this.list());
  }

  static subscribe(listener: (action: any) => void) {
    return DevToolsPlugin._subject$.subscribe(listener);
  }
}

export const devToolsPlugin = (key: string) => (store: any) => {
  DevToolsPlugin.register(key, store);

  return {
    history: new HistoryPlugin({ store }),
  };
};
