import { Form } from "../../vannila-form-store";
import { HistoryPlugin } from "../vannila-history-plugin";

export interface IFormDevTool {
  register: <TValue extends {}, TypeError extends {}, THandler extends {}>(
    form: Form<TValue, TypeError, THandler>
  ) => void;
}

export interface TDevToolPlugin {
  history: HistoryPlugin<any>;
}
