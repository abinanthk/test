export type TEffect<TArg> = (arg: TArg) => void;
