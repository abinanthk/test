export type TApiOptions = {
  cacheTime?: number;
  staleTime?: number;
  pollTime?: number;

  plugins?: any;
};

export type TPollOptions = {
  time?: number;
  count?: number;
};

export interface IApi {
  fetch(payload?: any): any;
  poll(payload?: any, count?: number): void;
}
