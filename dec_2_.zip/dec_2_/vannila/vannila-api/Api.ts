import { TApiOptions } from "./types";
import { GlobalCache } from "../vannila-utils/vannila-cache";
import { apiEffect, TApiEffectArg } from "../vannila-core";
import { Interval, Subject, TObserver } from "../vannila-utils";

export class Api<TData, TPayload> {
  private readonly _key: string;
  private readonly _fetch: (
    payload?: TPayload
  ) => TApiEffectArg<TData> | Promise<TApiEffectArg<TData>>;
  private readonly _options: Required<TApiOptions>;

  private readonly _subject$: Subject<TApiEffectArg<any>>;
  private readonly _pollInterval: Interval;
  private _lastUpdated: number;
  // private _plugins: any;

  private static defaultApiOptions: Required<TApiOptions> = {
    cacheTime: 10000,
    staleTime: 5000,
    pollTime: -1,
    plugins: {},
  };

  constructor(
    key: string,
    fetchFn: (payload?: TPayload) => TData,
    options?: TApiOptions
  ) {
    this._options = {
      ...Api.defaultApiOptions,
      ...options,
    };
    this._key = key;
    this._lastUpdated = 0;

    this._pollInterval = new Interval({ timeout: this._options.pollTime });
    this._subject$ = new Subject<any>();

    this._fetch = apiEffect<TData, TPayload>(fetchFn, (arg) => {
      this._subject$.next(arg);
    });

    const plugins: any = {};
    Object.entries(this._options.plugins).map(
      ([key, plugin]: [key: any, plugin: any]) => {
        plugins[key] = plugin(this);
      }
    );
    // this._plugins = plugins;
  }

  get metaData() {
    return {
      lastUpdated: this._lastUpdated,
      cacheTime: this._options.cacheTime,
      staleTime: this._options.staleTime,
      pollTime: this._options.pollTime,
    };
  }

  private hash(payload?: TPayload) {
    return JSON.stringify({ key: this._key, payload });
  }

  async fetch(payload?: TPayload) {
    const currentDateTime = new Date().getTime();

    let data: any = GlobalCache.get(this.hash(payload));
    if (
      this._lastUpdated === 0 ||
      currentDateTime - this._lastUpdated >= this._options.staleTime
    ) {
      console.log("fetching (staleTime) ");

      data = await this._fetch(payload);
      GlobalCache.set(this.hash(payload), data, {
        cacheTime: this._options.cacheTime,
      });

      this._lastUpdated = currentDateTime;
    }

    return data;
  }

  poll(payload?: TPayload, count?: number) {
    this._pollInterval.set(
      () => {
        (async () => {
          const data = await this._fetch(payload);
          GlobalCache.set(this.hash(payload), data, {
            cacheTime: this._options.cacheTime,
          });
        })();
      },
      { count }
    );
  }

  clearPolling() {
    this._pollInterval.clear();
  }

  get observed() {
    return this._subject$.observed;
  }

  subscribe(observer: TObserver<TApiEffectArg<any>>) {
    return this._subject$.subscribe(observer);
  }
}
