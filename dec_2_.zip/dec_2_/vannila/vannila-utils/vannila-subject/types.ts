export type TObserver<T> = (value: T) => void;

export type TSubscription = {
  unsubscribe: () => void;
};

export type TSubscribe<T> = (observer: TObserver<T>) => TSubscription;

export interface ISubject<T> {
  subscribe(observer: TObserver<T>): TSubscription;
  next(value: T): void;
  unsubscribeAll(): void;
}

// ----------------
export type TWatchSubscription = {
  unwatch: () => void;
};

export interface ISubjectX<T> {
  watch(observer: TObserver<T>): TWatchSubscription;
  unwatch(): void;
}
