import { TProxyEffectArg } from "../vannila-core";
import { TSubscribe } from "../vannila-utils/vannila-subject";

export type TStoreOptions<
  TState extends {} = {},
  TReducer extends {} = {},
  TPlugins extends {} = {}
> = {
  reducer?: (state: TState) => TReducer;
  plugins?: TPlugins;
};

export type IStore<TState extends {}> = {
  subscribe: TSubscribe<TProxyEffectArg<TState>>;
};
