import { proxyEffect, TProxyEffectArg, TDeps } from "../vannila-core";
import { Subject, TObserver } from "../vannila-utils";
import { IStore, TStoreOptions } from "./types";

export class Store<
  TState extends {} = {},
  TReducer extends {} = {},
  TPlugins extends {} = {}
> implements IStore<TState>
{
  private readonly _subject$: Subject<TProxyEffectArg<TState>>;

  private readonly _initialState: TState;
  private readonly _state: TState;

  private readonly _options: Required<
    TStoreOptions<TState, TReducer, TPlugins>
  >;

  private readonly _reducer: TReducer;
  private readonly _plugins: TPlugins;

  constructor(
    state: TState,
    options?: TStoreOptions<TState, TReducer, TPlugins>
  ) {
    const DEFAULT_STORE_OPTIONS: Required<
      TStoreOptions<TState, TReducer, TPlugins>
    > = {
      reducer: () => ({} as TReducer),
      plugins: {} as TPlugins,
    };

    this._subject$ = new Subject<TProxyEffectArg<TState>>();

    this._initialState = { ...state };
    this._state = proxyEffect({ ...state }, (arg) => {
      this._subject$.next(arg);
    });

    this._options = {
      ...DEFAULT_STORE_OPTIONS,
      ...options,
    };

    this._reducer = this._options.reducer(this.state);

    const plugins: any = {};
    Object.entries(this._options.plugins).map(
      ([key, plugin]: [key: any, plugin: any]) => {
        plugins[key] = plugin(this);
      }
    );
    this._plugins = plugins;
  }

  get options() {
    return this._options;
  }

  get state() {
    return this._state;
  }

  get observed() {
    return this._subject$.observed;
  }

  subscribe(observer: TObserver<TProxyEffectArg<TState>>) {
    return this._subject$.subscribe(observer);
  }

  get reducer() {
    return this._reducer;
  }

  get plugins() {
    return this._plugins;
  }

  reset(deps?: TDeps<TState>) {
    const _deps =
      deps || (Reflect.ownKeys(this.state as object) as TDeps<TState>);

    _deps?.forEach((key) => {
      if (!Reflect.has(this._initialState, key)) {
        return;
      }

      this.state[key] = this._initialState[key];
    });
  }
}
