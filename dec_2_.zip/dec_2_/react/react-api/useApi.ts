import { Api, TApiOptions } from "../../../vannila/index.ts";
import { useSingleton } from "../react-utils/index.ts";

export const useApi = <TData, TPayload>(
  key: string,
  fetchFn: (payload?: TPayload) => TData,
  options?: TApiOptions
) => {
  return useSingleton(() => new Api(key, fetchFn, options));
};
