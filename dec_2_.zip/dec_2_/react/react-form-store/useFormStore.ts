import {
  FormStore,
  TDeps,
  TFormStoreOptions,
  TFormStores,
} from "../../../vannila";
import { useSingleton } from "../react-utils";
import { useVannilaFormStore } from "./useVannilaFormStore";

export const useFormStore = <
  TValue extends {},
  TError extends {},
  THandler extends {}
>(
  stores: TFormStores<TValue, TError>,
  options?: TFormStoreOptions<TValue, TError, THandler>,
  valueDeps?: TDeps<TValue>,
  errorDeps?: TDeps<TError>
) => {
  const formStore = useSingleton<FormStore<TValue, TError, THandler>>(
    () => new FormStore<TValue, TError, THandler>(stores, options)
  );

  return useVannilaFormStore<TValue, TError, THandler>(
    formStore,
    valueDeps,
    errorDeps
  );
};
