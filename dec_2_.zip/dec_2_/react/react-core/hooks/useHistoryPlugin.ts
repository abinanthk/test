import { useEffect } from "react";
import { useForceUpdate } from "../../react-utils";
import { HistoryPlugin } from "../../../../vannila";

export const useHistoryPluginEffect = <TState extends {}>(
  history: HistoryPlugin<TState>,
  effect: (e: any) => void
) => {
  useEffect(() => {
    const subscription = history.subscribe((e) => {
      effect(e);
      console.log('ddd', e);
      
    });

    return () => subscription.unsubscribe();
  }, []);
};

export const useHistoryPlugin = <TState extends {}>(
  history: HistoryPlugin<TState>
) => {
  const forceUpdate = useForceUpdate();

  useHistoryPluginEffect(history, () => forceUpdate());
};
