import { TSubscribe } from "../../../../vannila";

export type TTargetBase<TState> = {
  state: TState;
  subscribe: TSubscribe<TState>;
};
