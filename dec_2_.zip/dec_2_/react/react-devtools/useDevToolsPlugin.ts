import { useEffect } from "react";
import { DevToolsPlugin } from "../../../vannila";
import { useForceUpdate } from "../react-utils";

export const useDevToolsPlugin = () => {
  const forceUpdate = useForceUpdate();

  useEffect(() => {
    const subscription = DevToolsPlugin.subscribe((stores) => {
      console.log("store -- : ", stores);
      forceUpdate();
    });

    return () => subscription.unsubscribe();
  }, []);

  return Array.from(DevToolsPlugin.list(), ([key, store]) => ({
    key,
    store,
  }));
};
