import { useEffect } from "react";
import { ApiDevToolsPlugin } from "../../../vannila";
import { useForceUpdate } from "../react-utils";

export const useApiDevToolsPlugin = () => {
  const forceUpdate = useForceUpdate();

  useEffect(() => {
    const subscription = ApiDevToolsPlugin.subscribe((apis) => {
      console.log("apis -- : ", apis);
      forceUpdate();
    });

    return () => subscription.unsubscribe();
  }, []);

  return Array.from(ApiDevToolsPlugin.list(), ([key, api]) => ({
    key,
    api,
  }));
};
