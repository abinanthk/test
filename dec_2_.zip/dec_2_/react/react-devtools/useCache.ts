import { useEffect } from "react";
import { Cache, CacheItem } from "../../../vannila/src/vannila-utils";
import { useForceUpdate } from "../react-utils";

export const useCache = (cache: Cache) => {
  const forceUpdate = useForceUpdate();

  useEffect(() => {
    const subscription = cache.subscribe(() => {
      forceUpdate();
    });

    return () => subscription.unsubscribe();
  }, []);

  return Array.from(cache.list(), ([key, value]) => ({
    key,
    value,
  }));
};

export const useCacheItem = (item: CacheItem) => {
  const forceUpdate = useForceUpdate();

  useEffect(() => {
    const subscription = item.subscribe(() => {
      forceUpdate();
    });

    return () => subscription.unsubscribe();
  }, []);

  return item.data;
};
