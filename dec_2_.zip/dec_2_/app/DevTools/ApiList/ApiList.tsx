import { Api } from "@statez/vannila";
import { useApiDevToolsPlugin } from "../../../../../packages/react";

export type ApiItemProps = {
  item: { key: string; api: Api<any, any> };
};

const ApiItem = ({ item }: ApiItemProps) => {
  console.log("api  : ", item.api);

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          fontWeight: "bold",
          padding: 5,
          margin: 5,
          backgroundColor: "#333",
          color: "#eee",
        }}
      >
        {item.key}
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        <div>Meta Data: {JSON.stringify(item.api.metaData)}</div>
      </div>
    </div>
  );
};

export const ApiList = () => {
  const list = useApiDevToolsPlugin();

  console.log("apis : ", list);

  return (
    <div>
      <p>--- Api Dev Tools ---</p>
      <div>
        {list.map((item, i) => (
          <div key={i}>
            <ApiItem item={item} />
          </div>
        ))}
      </div>
    </div>
  );
};
