import { ReactNode } from "react";
import { createPortal } from "react-dom";
import { MainLayout } from "./MainLayout";
import { useStore } from "../../../../packages/react";

const Portal = ({ children }: { children: ReactNode }) => {
  return createPortal(children, document.body);
};

export const DevTools = () => {
  const store = useStore({ show: true });
  return (
    // <Portal>
    <div
      style={{
        //   backgroundColor: "red",
        //   position: "absolute",
        top: 10,
        left: 10,
      }}
    >
      <button onClick={() => (store.state.show = !store.state.show)}>
        devtools
      </button>
      {store.state.show && <MainLayout />}
    </div>
    // </Portal>
  );
};
