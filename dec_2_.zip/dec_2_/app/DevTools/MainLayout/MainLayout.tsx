import { useState } from "react";
import { StoreList } from "../StoreList";
import { HistoryList } from "../HistoryList";
import { ApiList } from "../ApiList";

export const MainLayout = () => {
  const [tab, setTab] = useState<"history" | "store" | "api">("history");
  return (
    <div>
      <div className="flex gap-2">
        <button onClick={() => setTab("history")}>History</button>
        <button onClick={() => setTab("store")}>Stores</button>
        <button onClick={() => setTab("api")}>Api</button>
      </div>
      <div>{tab === "history" && <HistoryList />}</div>
      <div>{tab === "store" && <StoreList />}</div>
      <div>{tab === "api" && <ApiList />}</div>
    </div>
  );
};
