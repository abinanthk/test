import { useCache, useCacheItem } from "../../../../../packages/react";
import {
  CacheItem,
  GlobalCache,
} from "../../../../../packages/vannila/src/vannila-utils";

export type CacheItemProps = {
  item: { key: string; value: CacheItem };
};

const CacheItemC = ({ item }: CacheItemProps) => {
  const data = useCacheItem(item.value);

  console.log("Cache data : ", data);

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          fontWeight: "bold",
          padding: 5,
          margin: 5,
          backgroundColor: "#333",
          color: "#eee",
        }}
      >
        {item.key}
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        {JSON.stringify(data)}
      </div>
    </div>
  );
};

export const CacheList = () => {
  const list = useCache(GlobalCache);

  console.log("Caches : ", list);

  return (
    <div>
      <p>--- Cache Dev Tools ---</p>
      <div>
        {list.map((item, i) => (
          <div key={i}>
            <CacheItemC item={item} />
          </div>
        ))}
      </div>
    </div>
  );
};
