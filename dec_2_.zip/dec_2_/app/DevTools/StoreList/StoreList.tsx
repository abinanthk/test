import { useDevToolsPlugin } from "../../../../../packages/react";
import { Store } from "../../../../../packages/vannila";

export type StoreItemProps = {
  item: { key: string; store: Store<any, any> };
};
const StoreItem = ({ item }: StoreItemProps) => {
  console.log("store : ", item);

  const fields = Object.entries(item.store.state).map(([key, value]) => {
    return (
      <div key={key}>
        <p>
          {key} : {JSON.stringify(value)}
        </p>
      </div>
    );
  });

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          fontWeight: "bold",
          padding: 5,
          margin: 5,
          backgroundColor: "#333",
          color: "#eee",
        }}
      >
        {item.key}
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        {fields}
      </div>
    </div>
  );
};

export const StoreList = () => {
  const list = useDevToolsPlugin();

  console.log("stores : ", list);

  return (
    <div>
      <p>--- Dev Tools ---</p>
      <div>
        {list.map((item, i) => (
          <div key={i}>
            <StoreItem item={item} />
          </div>
        ))}
      </div>
    </div>
  );
};
