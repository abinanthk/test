import {
  useDevToolsPlugin,
  useHistoryPlugin,
} from "../../../../../packages/react";
import { Store, TDevToolPlugin } from "../../../../../packages/vannila";

export type HistoryItemProps = {
  item: {
    key: string;
    store: Store<
      any,
      any,
      {
        devtools: TDevToolPlugin;
      }
    >;
  };
};

export const HistoryItem = (props: HistoryItemProps) => {
  const store = props.item.store;
  const history = store.plugins.devtools.history;
  const undos = history.getUndos();
  const redos = history.getRedos();

  useHistoryPlugin(history);
  // useHistoryPluginEffect(history, (e) => {
  //   console.log("effect : ", e);
  // });

  console.log("re render");

  const handleUndo = () => {
    history.undo();
  };

  const handleRedo = () => {
    history.redo();
  };

  const handleClearHistory = () => {
    history.clear();
  };

  const handlePop = () => {
    history.pop();
  };

  return (
    <div style={{ border: "1px solid #444", padding: 5, margin: 5 }}>
      <div
        style={{
          fontWeight: "bold",
          padding: 5,
          margin: 5,
          backgroundColor: "#333",
          color: "#eee",
        }}
      >
        {props.item.key}
      </div>
      <div
        style={{
          border: "1px solid #444",
          padding: 5,
          margin: 5,
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div>Current state : {JSON.stringify(store.state)}</div>
          <div>
            <button onClick={handleUndo}>undo</button>
            <button onClick={handleRedo}>redo</button>
            <button onClick={handleClearHistory}>clear history</button>
            <button onClick={handlePop}>pop</button>
          </div>

          <div style={{ display: "flex", gap: 20 }}>
            <div>
              <p>--- current ---</p>
              <div>{JSON.stringify(history.current)}</div>
            </div>

            <div>
              <p>--- undos ---</p>
              {undos.map((undo, index) => {
                return <div key={index}>{JSON.stringify(undo)}</div>;
              })}
            </div>
            <div>
              <p>--- redos ---</p>
              {redos.map((redo, index) => {
                return <div key={index}>{JSON.stringify(redo)}</div>;
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const HistoryList = () => {
  const list = useDevToolsPlugin();

  console.log("list : ", list);

  return (
    <div>
      <p>--- History ---</p>
      <div>
        {list.map((item, i) => (
          <div key={i}>
            <HistoryItem item={item} />
          </div>
        ))}
      </div>
    </div>
  );
};
