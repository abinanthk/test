import { NavLink } from "react-router-dom";

export const NavBar = () => {
  return (
    <div>
      <NavLink to={"login"}>Login</NavLink>
    </div>
  );
};
