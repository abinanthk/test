import { useStore, useVannilaStore } from "../../../../packages/react";
import {
  useMountEffect,
  useUnMountEffect,
} from "../../../../packages/react/src/react-utils";

import { Api, apiDevToolsPlugin, devToolsPlugin, Store } from "../../../../packages/vannila";
import { TaskForm } from "./TaskForm";
import { TaskList } from "./TaskList";
import {
  Cache,
  GlobalCache,
  TCacheOptions,
} from "../../../../packages/vannila/src/vannila-utils";

type TUserData = {
  name: string;
  age: number;
};

type TApiError = {
  message: string;
};

const userData: TUserData = {
  name: "abi",
  age: 22,
};

type TUserStoreState = {
  data: TUserData;
  error: TApiError;
};

const getUser = () => {
  console.log("fetching from api");

  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(userData);
      // reject({ message: "Something went wrong" });
    }, 1000);
  });
};

// const globalCache = new Cache();

// const createApi = (
//   key: any,
//   fetch: (payload?: any) => any,
//   options?: TCacheOptions
// ) => {
//   globalCache.register(key, fetch, options);

//   return  (payload?: any) => {

//     if(!globalCache.has({key, payload})){

//       globalCache.register({key, payload}, fetch, options);
//     }

//     return globalCache.fetch({key, payload}, payload);
//   }
// };

const getUserApi = new Api("data1", getUser, {
  pollTime: 2000,
  plugins: {
    devtools: apiDevToolsPlugin("api-store-1"),
  },
});

getUserApi.fetch(10);

const apiuserStore = new Store<
  {
    status: string;
    data: {
      name: string;
      age: number;
    };
    error: {
      message: string;
    };
  },
  {
    // getData: () => void;
  }
>(
  {
    status: "idle",
    data: {
      name: "",
      age: 0,
    },
    error: {
      message: "",
    },
  },
  {
    reducer: (state) => ({
      // getData: async () => {
      //   const res = await getUserApi.fetch();
      //   console.log("res : ", res);
      //   state.status = res.status;
      //   if (res.status === "error") {
      //     state.error = res.error;
      //     return;
      //   }
      //   state.data = res.data;
      // },
    }),

    plugins: {
      devtools: devToolsPlugin("api-store"),
    },
  }
);

getUserApi.subscribe((res) => {
  console.log("res : ", res);

  if (res.status === "completed") {
    return;
  }

  apiuserStore.state.status = res.status;

  if (res.status === "error") {
    apiuserStore.state.error = res.error;
    return;
  }

  apiuserStore.state.data = res.data;
});

const Child = () => {
  const dataStore = useVannilaStore(apiuserStore);

  // useMountEffect(() => {
  //   apiuserStore.reducer.getData();
  // });

  useMountEffect(() => {
    getUserApi.fetch();
  });

  console.log("d : ", dataStore.state);

  if (dataStore.state.status === "pending") {
    return (
      <div>
        <div>Loading...</div>
      </div>
    );
  }

  if (dataStore.state.status === "error") {
    return (
      <div>
        <div>{dataStore.state.error.message}</div>
      </div>
    );
  }

  return (
    <div>
      <div>{dataStore.state.data?.name}</div>
      <div>{dataStore.state.data?.age}</div>
    </div>
  );
};

export const TodoList = () => {
  // return (
  //   <div>
  //     <TaskForm />
  //     <TaskList />
  //   </div>
  // );

  const showStore1 = useStore({ show: false });
  const showStore2 = useStore({ show: false });

  return (
    <div>
      <button onClick={() => console.log(" cache list : ", GlobalCache.list())}>
        list
      </button>
      <br />
      <button onClick={() => getUserApi.clearPolling()}>clear polling</button>
      <div>
        <button
          onClick={() => (showStore1.state.show = !showStore1.state.show)}
        >
          show
        </button>
        {showStore1.state.show && <Child />}
      </div>
      <div>
        <button
          onClick={() => (showStore2.state.show = !showStore2.state.show)}
        >
          show2
        </button>
        {showStore2.state.show && <Child />}
      </div>
    </div>
  );
};
