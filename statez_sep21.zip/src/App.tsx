import SampleQueryStore from "./sample/SampleQueryStore";
import SampleStore from "./sample/SampleStore";

const App = () => {
  // return <SampleQueryStore />;
  return <SampleStore />;
};

export default App;
