import { useEffect } from "react";
import { useQuery } from "../../packages/react-query";

type Props = {};

type TMyData = { name: string; description: string };

type TMyError = {
  code: string;
  description: string;
};

type TMyStatus = {
  type: string;
  message: string;
  error: TMyError;
};

type TMyResponse = {
  result: {
    records: TMyData[];
  };
  status: TMyStatus;
};

const response: TMyResponse = {
  result: {
    records: [
      {
        name: "Title 1",
        description: "This is post 1",
      },
      {
        name: "Title 2",
        description: "This is post 2",
      },
    ],
  },
  status: {
    type: "S",
    message: "Success",
    error: {
      code: "E1234",
      description: "bad request",
    },
  },
};

const getMyData = () => {
  console.log("fetching data");
  // throw new Error("error occured");
  return new Promise<TMyResponse>((resolve, reject) => {
    setTimeout(() => {
      // reject({message: 'Something went wrong...'});
      resolve(response);
    }, 1000);
  });
};

const SampleQueryStore = (props: Props) => {
  const query = useQuery<TMyResponse, TMyData[], TMyStatus, TMyError, string>({
    queryKey: "myQuery",
    queryFn: getMyData,
    extract: {
      data: (response) => response.result.records,
      status: (response) => response.status,
      error: (response) => response.status.error,
    },
  });

  console.log("query", query);

  useEffect(() => {
    // query.subscribe(s => {
    //   console.log('s', s)
    // })

    query.fetch();
  }, []);

  if (query.isFetching) {
    return <div>Fetching...</div>;
  }

  if (query.error) {
    return <div>Error: {query.error.description}</div>;
  }

  return (
    <div>
      {query.data?.map((d: any, i: any) => {
        return <p key={i}>{d.name}</p>;
      })}
    </div>
  );
};

export default SampleQueryStore;
