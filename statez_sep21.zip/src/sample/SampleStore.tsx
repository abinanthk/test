import { useStore, useStoreEffect } from "../../packages/react-store";

type Props = {};

type TCount = {
  count: number;
  increment10: () => void;
  count2: number;
  increment102: () => void;
};

const SampleStore = (props: Props) => {
  const _count2StoreState = useStore<TCount>(
    {
      count: 0,
      increment10() {
        this.count = this.count + 10;
      },
      count2: 100,
      increment102() {
        this.count2 = this.count2 + 10;
      },
    },
    ["count", "count2"]
  );

  useStoreEffect<TCount>(_count2StoreState, (s) => {
    console.log("s", s);
  });

  const handleClick = () => {
    _count2StoreState.state.count++;
  };

  const handleClick10 = () => {
    _count2StoreState.state.increment10();
  };

  const handleClick2 = () => {
    _count2StoreState.state.count2++;
  };

  return (
    <div>
      <div>Count: {_count2StoreState.state.count}</div>
      <div>Count2: {_count2StoreState.state.count2}</div>
      <button onClick={handleClick}>click</button>
      <button onClick={handleClick2}>click2</button>
      <button onClick={handleClick10}>inc 10</button>
      <button onClick={() => _count2StoreState.reset(["count"])}>reset</button>
      <button onClick={() => _count2StoreState.revert()}>
        revert
      </button>
    </div>
  );
};

export default SampleStore;
