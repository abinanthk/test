import { createContext, useContext, useRef } from "react";
import { useStore } from "../react-store";
import { useMountEffect } from "../react-utils/hooks";

type TOption = {
  isSelected: boolean;
  value: string;
};

type TSelectOptionStore = TOption & {
  onChange: (value: string) => void;
};

type TSelectStore = {
  open: boolean;
  values: string[];
  options: TOption[];
  addOption: (option: TOption) => void;
  addValue: (value: string) => void;
  removeValue: (value: string) => void;
};

export const useSelectRef = () => {
  return useRef<TSelectStore>();
};

export const SelectStoreContext = createContext(null);

const useSelectStoreContext = (selectors?: string[]) => {
  const store = useContext(SelectStoreContext);

  return useStore(store, selectors);
};

const SelectRoot = (props: any) => {
  const _selectStore = useStore<TSelectStore>({
    open: true,
    values: props.defaultValue || [],
    options: [],
    addOption(option) {
      const optionFound = this.options.find(
        (opt) => opt.value === option.value
      );

      if (optionFound) {
        option.isSelected = optionFound.isSelected;
      } else {
        this.options.push({
          value: option.value,
          isSelected: this.values.includes(option.value),
        });
        option.isSelected = this.values.includes(option.value);
      }
    },
    addValue(value) {
      const valueFound = this.values.find((val: string) => val === value);

      if (!valueFound) {
        this.values = [...this.values, value];
        props.onChange?.(this.values);
      }
    },
    removeValue(value) {
      const valueFound = this.values.find((val: string) => val === value);

      if (valueFound) {
        this.values = this.values?.filter((val) => val !== value);
        props.onChange?.(this.values);
      }
    },
  });

  useMountEffect(() => {
    if (props.zRef) {
      props.zRef.current = _selectStore;
    }
  });

  return (
    <SelectStoreContext.Provider value={_selectStore}>
      {props.children}
    </SelectStoreContext.Provider>
  );
};

const SelectLabel = (props: any) => {
  return <label {...props} />;
};

const SelectPlaceholder = (props: any) => {
  const _selectStore = useSelectStoreContext(["values"]);

  return (
    <span {...props}>
      {_selectStore.values?.[0] ? _selectStore.values[0] : props.children}
    </span>
  );
};

const SelectTrigger = (props: any) => {
  const _selectStore = useSelectStoreContext();

  const handleClick = (e: any) => {
    _selectStore.open = !_selectStore.open;
    props.onClick?.(e);
  };

  return <div {...props} onClick={handleClick} />;
};

const SelectContent = (props: any) => {
  const _selectStore = useSelectStoreContext(["open"]);

  return _selectStore.open ? <div>{props.children}</div> : null;
};

export const SelectOptionStoreContext = createContext(null);

const useSelectOptionStoreContext = (selectors?: string[]) => {
  const store = useContext(SelectOptionStoreContext);

  return useStore(store, selectors);
};

const SelectOption = (props: any) => {
  const _selectStore = useSelectStoreContext();

  const _selectOptionStore = useStore<TSelectOptionStore>({
    isSelected: false,
    value: props.value,
    onChange() {},
  });

  useMountEffect(() => {
    _selectStore.addOption(_selectOptionStore);
  });

  return (
    <SelectOptionStoreContext.Provider value={_selectOptionStore}>
      {props.children}
    </SelectOptionStoreContext.Provider>
  );
};

const SelectSelected = (props: any) => {
  const _selectOptionStore = useSelectOptionStoreContext(["isSelected"]);

  return _selectOptionStore.isSelected ? <div {...props} /> : null;
};

const SelectUnSelected = (props: any) => {
  const _selectOptionStore = useSelectOptionStoreContext(["isSelected"]);

  return _selectOptionStore.isSelected ? null : <div {...props} />;
};

const SelectToggle = (props: any) => {
  const _selectOptionStore = useSelectOptionStoreContext();
  const _selectStore = useSelectStoreContext();

  const handleClick = (e: any) => {
    _selectOptionStore.isSelected = !_selectOptionStore.isSelected;

    _selectStore.options.forEach((option: TOption) => {
      if (_selectOptionStore.value === option.value) {
        option.isSelected = _selectOptionStore.isSelected;

        if (_selectOptionStore.isSelected) {
          _selectStore.addValue(_selectOptionStore.value);
        } else {
          _selectStore.removeValue(_selectOptionStore.value);
        }
      }
    });
    props.onClick?.(e);
  };

  return <div {...props} onClick={handleClick} />;
};

export const Select = {
  Root: SelectRoot,
  Label: SelectLabel,
  Placeholder: SelectPlaceholder,
  Trigger: SelectTrigger,
  Content: SelectContent,
  Option: SelectOption,
  Selected: SelectSelected,
  UnSelected: SelectUnSelected,
  Toggle: SelectToggle,
};
