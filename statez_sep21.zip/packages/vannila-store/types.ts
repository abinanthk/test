export type TKey<T> = keyof T;
export type TOptions<T> = (options?: TKey<T>[]) => void;

export type TListener<TState> = (noti: TNoti<TState>) => void;
export type TSubscribe<T> = (listener: TListener<T>) => TSubscription;
export type TSubscription = {
  unsubscribe: () => void;
};

export type TNoti<TState> = {
  state: TState;
  prevState: TState;
  change: TKey<TState>;
};

export type IStore<TState> = {
  state: TState;
  initState: TState;
  prevState: TState;
  reset: TOptions<TState>;
  revert: TOptions<TState>;
  subscribe: TSubscribe<TState>;
};
