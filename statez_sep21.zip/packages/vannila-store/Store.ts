import { Subject } from "rxjs";
import type { IStore, TKey, TListener, TNoti } from "./types";

export class Store<TState extends {}> implements IStore<TState> {
  private readonly _state: TState;
  private readonly _initState: TState;
  private readonly _prevState: TState;
  private readonly subject$: Subject<TNoti<TState>>;

  constructor(initState: TState) {
    const _state = { ...initState };
    const _initState = { ...initState };
    const _prevState = { ...initState };
    const _subject$ = new Subject<TNoti<TState>>();

    this._initState = _initState;
    this._prevState = _prevState;
    this.subject$ = _subject$;

    this._state = new Proxy(_state, {
      get(target, prop) {
        return Reflect.get(target, prop);
      },
      set(target, prop, value) {
        const prevValue = Reflect.get(target, prop);

        if (!Reflect.has(target, prop)) {
          console.error(
            `Property ${String(prop)} is not presented in state's blueprint.
            State's blueprints are immutable.
            `
          );
          return false;
        }

        if (typeof prevValue === "function") {
          console.error(
            `Property ${String(prop)} is a function in state's blueprint.
            Functions are immutable in Store's state.
            `
          );
          return false;
        }

        if (prevValue === value) {
          return true;
        }

        if (!Reflect.set(target, prop, value)) {
          return false;
        }

        Reflect.set(_prevState, prop, prevValue);

        _subject$.next({
          state: { ...target },
          prevState: { ..._prevState },
          change: prop as any,
        });

        return true;
      },
    });
  }

  get state() {
    return this._state;
  }

  get initState() {
    return this._initState;
  }

  get prevState() {
    return this._prevState;
  }

  private commit(state: TState, options?: TKey<TState>[]) {
    const _options =
      options || (Reflect.ownKeys(state as object) as TKey<TState>[]);

    _options?.forEach((key) => {
      if (!Reflect.has(state, key) || typeof state[key] === "function") {
        return;
      }

      (this.state as any)[key] = state[key];
    });
  }

  revert(options?: TKey<TState>[]) {
    this.commit(this.prevState, options);
  }

  reset(options?: TKey<TState>[]) {
    this.commit(this.initState, options);
  }

  subscribe(listener: TListener<TState>) {
    return this.subject$.subscribe(listener);
  }
}
