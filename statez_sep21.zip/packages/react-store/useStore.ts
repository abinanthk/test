import { useRef } from "react";
import { Store } from "../vannila-store";
import { useSyncStore } from ".";
import type { TSync, IStore } from "../vannila-store/types";

export const useStore = <TState extends {}>(
  initState: TState,
  sync?: TSync<TState>[]
) => {
  const storeRef = useRef<IStore<TState> | null>(null);

  if (!storeRef.current) {
    storeRef.current = new Store<TState>(initState);
  }

  return useSyncStore<TState>(storeRef.current, sync);
};
