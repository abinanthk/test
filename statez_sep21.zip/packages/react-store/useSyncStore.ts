import { useStoreEffect } from ".";
import { useForceUpdate } from "../react-utils/hooks";
import type { TSync, IStore } from "../vannila-store/types";

export const useSyncStore = <TState>(
  store: IStore<TState>,
  sync?: TSync<TState>[]
) => {
  const forceUpdate = useForceUpdate();

  useStoreEffect<TState>(store, () => forceUpdate(), sync);

  return store;
};
