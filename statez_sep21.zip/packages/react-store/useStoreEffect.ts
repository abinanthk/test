import { useEffect } from "react";
import type { TKey, IStore, TNoti } from "../vannila-store/types";

export const useStoreEffect = <TState>(
  store: IStore<TState>,
  fn: (noti: TNoti<TState>) => void,
  sync?: TKey<TState>[]
) => {
  useEffect(() => {
    const _sync =
      sync || (Reflect.ownKeys(store.state as object) as TKey<TState>[]);

    const subscription = store.subscribe((noti: TNoti<TState>) => {
      if (_sync?.includes(noti.change)) {
        fn(noti);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);
};
