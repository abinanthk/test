import { Store } from "../vannila-store";
import type { IStore } from "../vannila-store/types";
import type { ICache } from "../vannila-cache/types";
import type { TQueryConfig, IQuery, TQueryState } from "./types";

export class Query<TResponse, TData, TStatus, TError, TQueryKey>
  implements IQuery<TResponse, TData, TStatus, TError, TQueryKey>
{
  private readonly _config: TQueryConfig<
    TResponse,
    TData,
    TStatus,
    TError,
    TQueryKey
  >;
  private readonly _store: IStore<TQueryState<TData, TStatus, TError>>;
  private readonly _cache?: ICache<
    string,
    IStore<TQueryState<TData, TStatus, TError>>
  >;

  constructor(
    config: TQueryConfig<TResponse, TData, TStatus, TError, TQueryKey>,
    cache?: ICache<string, IStore<TQueryState<TData, TStatus, TError>>>
  ) {
    const initState: TQueryState<TData, TStatus, TError> = {
      queryStatus: "idle",
      data: undefined,
      error: undefined,
      status: undefined,
    };

    this._config = config;
    this._store = new Store<TQueryState<TData, TStatus, TError>>(initState);
    this._cache = cache;
  }

  get config() {
    return this._config;
  }

  get store() {
    return this._store;
  }

  get cache() {
    return this._cache;
  }

  async fetch() {
    if (this._store.state.queryStatus === "pending") {
      return;
    }

    this._store.state.queryStatus = "pending";

    try {
      const response = await this.config?.queryFn?.();
      this._store.state.data = this.config?.extract?.data?.(response);
      this._store.state.status = this.config?.extract?.status?.(response);
      this._store.state.error = this.config?.extract?.error?.(response);
      this._store.state.queryStatus = "resolved";
    } catch (err: any) {
      this._store.state.error = err;
      this._store.state.data = undefined;
      this._store.state.queryStatus = "rejected";
    } finally {
    }
  }
}
