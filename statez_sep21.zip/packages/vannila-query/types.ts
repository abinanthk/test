import { IStore } from "../vannila-store/types";
import { ICache } from "../vannila-cache/types";

export type TQueryConfig<TResponse, TData, TStatus, TError, TQueryKey> = {
  queryKey: TQueryKey;
  queryFn: () => Promise<TResponse>;
  extract?: {
    data?: (response: TResponse) => TData;
    status?: (response: TResponse) => TStatus;
    error?: (response: TResponse) => TError;
  };
};

export type TQueryState<TData, TStatus, TError> = {
  queryStatus: "idle" | "pending" | "resolved" | "rejected";
  data?: TData;
  status?: TStatus;
  error?: TError;
};

export interface IQuery<TResponse, TData, TStatus, TError, TQueryKey> {
  config: TQueryConfig<TResponse, TData, TStatus, TError, TQueryKey>;
  store: IStore<TQueryState<TData, TStatus, TError>>;
  cache?: ICache<string, IStore<TQueryState<TData, TStatus, TError>>>;
  fetch: () => void;
}
