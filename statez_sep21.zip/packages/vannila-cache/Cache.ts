import type { ICache } from "./types";

const DEFAULT_CACHE_MAX_SIZE = 3;

export class Cache<K, V> implements ICache<K, V> {
  map: Map<K, V>;
  maxSize: number;

  constructor(maxSize: number = DEFAULT_CACHE_MAX_SIZE) {
    this.map = new Map<K, V>();
    this.maxSize = maxSize;
  }

  set(key: K, value: V) {
    if (this.map.size >= this.maxSize) {
      console.warn("Cache is full.");
      return false;
    }

    this.map.set(key, value);

    return true;
  }

  get(key: K) {
    return this.map.get(key);
  }

  remove(key: K) {
    return this.map.delete(key);
  }

  has(key: K) {
    return this.map.has(key);
  }

  get size() {
    return this.map.size;
  }

  clear() {
    this.map.clear();
  }
}
