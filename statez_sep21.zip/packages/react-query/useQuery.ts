import { useRef } from "react";
import { Query } from "../vannila-query";
import { useSyncStore } from "../react-store";
import type { TQueryConfig, TQueryState } from "../vannila-query/types";
import type { TSync } from "../vannila-store/types";

type TQueryHookOut<TData, TStatus, TError> = TQueryState<
  TData,
  TStatus,
  TError
> & {
  fetch: Function;
  isFetching: boolean;
};

export const useQuery = <TResponse, TData, TStatus, TError, TQueryKey>(
  config: TQueryConfig<TResponse, TData, TStatus, TError, TQueryKey>,
  sync?: TSync<TQueryState<TData, TStatus, TError>>[]
): TQueryHookOut<TData, TStatus, TError> => {
  const storeRef = useRef<Query<
    TResponse,
    TData,
    TStatus,
    TError,
    TQueryKey
  > | null>(null);

  if (!storeRef.current) {
    storeRef.current = new Query<TResponse, TData, TStatus, TError, TQueryKey>(
      config
    );
  }

  useSyncStore<TQueryState<TData, TStatus, TError>>(
    storeRef.current.store,
    sync
  );

  return {
    ...storeRef.current.store.state,
    fetch: () => storeRef.current?.fetch(),
    isFetching: storeRef.current.store.state.queryStatus === "pending",
  };
};
